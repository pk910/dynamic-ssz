package tests

import (
	"bytes"
	"encoding/hex"
	"reflect"
	"testing"

	dynssz "github.com/pk910/dynamic-ssz"
)

type TestPayload struct {
	Name    string         // Test name
	Payload any            // Test payload
	Specs   map[string]any // Dynamic specifications
	Hash    string         // Expected hash root
}

var testMatrix = []TestPayload{
	{
		Name:    "SimpleTypes1",
		Payload: SimpleTypes1_Payload,
		Specs:   map[string]any{},
		Hash:    "b528ffea01ddd484a9c1e6d16063512f9ec3097803dbf50dcdfa68effb1508df",
	},
	{
		Name:    "SimpleTypes2",
		Payload: SimpleTypes2_Payload,
		Specs:   map[string]any{},
		Hash:    "8026899f40abd06e808372e98a47af2d87cd60ed4d9b44a495a029b825ef2b34",
	},
	{
		Name:    "SimpleTypes3",
		Payload: SimpleTypes3_Payload,
		Specs:   map[string]any{},
		Hash:    "dea6e96a178704df1f792e0374fa60301d5fab10699687c4a395ecbfa9b78cc4",
	},
	{
		Name:    "SimpleTypesWithSpecs",
		Payload: SimpleTypesWithSpecs_Payload,
		Specs:   SimpleTypesWithSpecs_Specs,
		Hash:    "893aca6e960e166d2bde84c27e39db72ad85e271e40a92160b017ebf551334a8",
	},
	{
		Name:    "SimpleTypesWithSpecs2",
		Payload: SimpleTypesWithSpecs2_Payload,
		Specs:   SimpleTypesWithSpecs_Specs,
		Hash:    "966912b4d9e6b44fbebce56369fa255b76cd777d76e4dac2d396df93916ac077",
	},
	{
		Name:    "ProgressiveTypes",
		Payload: ProgressiveTypes_Payload,
		Specs:   map[string]any{},
		Hash:    "317f412cd2d042f367c4f2fb6447828ef9524396428eb2ed0837524bcc70433c",
	},
}

func TestCodegenGeneration(t *testing.T) {
	for _, payload := range testMatrix {
		t.Run(payload.Name, func(t *testing.T) {
			testCodegenPayload(t, payload)
		})
	}
}

func TestCodegenExtendedTypes(t *testing.T) {
	payloads := []struct {
		name    string
		payload ExtendedTypes1
	}{
		{"WithOptionals", ExtendedTypes1_Payload1},
		{"NilOptionals", ExtendedTypes1_Payload2},
	}

	for _, tc := range payloads {
		t.Run(tc.name, func(t *testing.T) {
			// Use reflection-only dynssz for reference
			ds := dynssz.NewDynSsz(nil,
				dynssz.WithExtendedTypes(),
				dynssz.WithNoFastSsz(),
				dynssz.WithNoFastHash(),
			)

			// Compare hash tree root: reflection vs generated
			refHash, err := ds.HashTreeRoot(tc.payload)
			if err != nil {
				t.Fatalf("reflection HashTreeRoot failed: %v", err)
			}
			genHash, err := tc.payload.HashTreeRoot()
			if err != nil {
				t.Fatalf("generated HashTreeRoot failed: %v", err)
			}
			if refHash != genHash {
				t.Fatalf("HashTreeRoot mismatch: ref=%x gen=%x", refHash, genHash)
			}

			// Compare size: reflection vs generated
			refSize, err := ds.SizeSSZ(tc.payload)
			if err != nil {
				t.Fatalf("reflection SizeSSZ failed: %v", err)
			}
			genSize := tc.payload.SizeSSZ()
			if refSize != genSize {
				t.Fatalf("SizeSSZ mismatch: ref=%d gen=%d", refSize, genSize)
			}

			// Compare marshal: reflection vs generated
			refBytes, err := ds.MarshalSSZ(tc.payload)
			if err != nil {
				t.Fatalf("reflection MarshalSSZ failed: %v", err)
			}
			genBytes, err := tc.payload.MarshalSSZTo(nil)
			if err != nil {
				t.Fatalf("generated MarshalSSZTo failed: %v", err)
			}
			if !bytes.Equal(refBytes, genBytes) {
				t.Fatalf("MarshalSSZ mismatch:\n  ref=%x\n  gen=%x", refBytes, genBytes)
			}

			// Unmarshal roundtrip with generated code
			var unmarshaled ExtendedTypes1
			err = unmarshaled.UnmarshalSSZ(genBytes)
			if err != nil {
				t.Fatalf("generated UnmarshalSSZ failed: %v", err)
			}
			roundtripHash, err := unmarshaled.HashTreeRoot()
			if err != nil {
				t.Fatalf("roundtrip HashTreeRoot failed: %v", err)
			}
			if roundtripHash != genHash {
				t.Fatalf("roundtrip hash mismatch: expected=%x got=%x", genHash, roundtripHash)
			}

			// Streaming marshal
			var streamBuf bytes.Buffer
			err = ds.MarshalSSZWriter(tc.payload, &streamBuf)
			if err != nil {
				t.Fatalf("MarshalSSZWriter failed: %v", err)
			}
			if !bytes.Equal(streamBuf.Bytes(), genBytes) {
				t.Fatalf("streaming marshal mismatch:\n  ref=%x\n  gen=%x", streamBuf.Bytes(), genBytes)
			}

			// Streaming unmarshal
			var streamUnmarshaled ExtendedTypes1
			err = ds.UnmarshalSSZReader(&streamUnmarshaled, bytes.NewReader(genBytes), len(genBytes))
			if err != nil {
				t.Fatalf("UnmarshalSSZReader failed: %v", err)
			}
			streamHash, err := streamUnmarshaled.HashTreeRoot()
			if err != nil {
				t.Fatalf("stream roundtrip HashTreeRoot failed: %v", err)
			}
			if streamHash != genHash {
				t.Fatalf("stream roundtrip hash mismatch: expected=%x got=%x", genHash, streamHash)
			}
		})
	}
}

func testCodegenPayload(t *testing.T, payload TestPayload) {
	ds := dynssz.NewDynSsz(payload.Specs)

	hashRoot, err := ds.HashTreeRoot(payload.Payload)
	if err != nil {
		t.Fatalf("Failed to hash tree root: %v", err)
	}
	hashRootHex := hex.EncodeToString(hashRoot[:])
	if hashRootHex != payload.Hash {
		t.Fatalf("Hash root mismatch 1: expected %s, got %s", payload.Hash, hashRootHex)
	}

	sszBytes, err := ds.MarshalSSZ(payload.Payload)
	if err != nil {
		t.Fatalf("Failed to marshal payload: %v", err)
	}

	obj := &struct {
		Data any
	}{}
	reflect.ValueOf(obj).Elem().Field(0).Set(reflect.New(reflect.TypeOf(payload.Payload)))

	err = ds.UnmarshalSSZ(obj.Data, sszBytes)
	if err != nil {
		t.Fatalf("Failed to unmarshal payload: %v", err)
	}

	hashRoot, err = ds.HashTreeRoot(obj.Data)
	if err != nil {
		t.Fatalf("Failed to hash tree root: %v", err)
	}
	hashRootHex = hex.EncodeToString(hashRoot[:])
	if hashRootHex != payload.Hash {
		t.Fatalf("Hash root mismatch 2: expected %s, got %s", payload.Hash, hashRootHex)
	}

	memBuf := make([]byte, 0, len(sszBytes))
	memWriter := bytes.NewBuffer(memBuf)
	err = ds.MarshalSSZWriter(payload.Payload, memWriter)
	if err != nil {
		t.Fatalf("Failed to marshal payload: %v", err)
	}
	memBuf = memWriter.Bytes()
	if !bytes.Equal(memBuf, sszBytes) {
		t.Fatalf("MarshalSSZWriter mismatch: expected %x, got %x", sszBytes, memBuf)
	}

	reflect.ValueOf(obj).Elem().Field(0).Set(reflect.New(reflect.TypeOf(payload.Payload)))

	err = ds.UnmarshalSSZReader(obj.Data, bytes.NewReader(sszBytes), len(sszBytes))
	if err != nil {
		t.Fatalf("Failed to unmarshal payload: %v", err)
	}

	hashRoot, err = ds.HashTreeRoot(obj.Data)
	if err != nil {
		t.Fatalf("Failed to hash tree root: %v", err)
	}
	hashRootHex = hex.EncodeToString(hashRoot[:])
	if hashRootHex != payload.Hash {
		t.Fatalf("Hash root mismatch 2: expected %s, got %s", payload.Hash, hashRootHex)
	}
}
