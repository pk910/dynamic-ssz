package tests

import (
	"encoding/binary"
	"errors"
	"math/big"
	"sync/atomic"
	"time"

	dynssz "github.com/pk910/dynamic-ssz"
	"github.com/pk910/dynamic-ssz/sszutils"
)

type SimpleBool bool
type SimpleUint8 uint8
type SimpleUint16 uint16
type SimpleUint32 uint32
type SimpleUint64 uint64

// Standalone fixed-size vector types generated as top-level -types entries;
// their generated decoders receive the raw outer buffer and must enforce
// exact consumption themselves.
type SimpleByteVec32 [32]byte
type SimpleUint64Vec4 [4]uint64

type SimpleTypes1 struct {
	B1       bool
	I8       uint8
	I16      uint16
	I32      uint32
	I64      uint64
	I128     [16]byte
	I256     [4]uint64
	Vec8     []uint8     `ssz-size:"4"`
	Vec32    []uint32    `ssz-size:"4"`
	Vec128   [][2]uint64 `ssz-type:"?,uint128" ssz-size:"4"`
	BitVec   [8]byte     `ssz-type:"bitvector"`
	BitVec2  [8]byte     `ssz-type:"bitvector" ssz-bitsize:"12"`
	Lst8     []uint8     `ssz-max:"4"`
	Lst32    []uint32    `ssz-max:"4"`
	Lst128   [][2]uint64 `ssz-type:"?,uint128" ssz-max:"4"`
	BigLst8  []uint8     `ssz-max:"35"`
	BitLst   []byte      `ssz-max:"16"`
	F1       [2][]uint16 `ssz-max:"?,64"`
	F2       [10]uint8   `ssz-size:"5"`
	Str      string      `ssz-max:"8"`
	Wrapper1 dynssz.TypeWrapper[struct {
		Data []byte `ssz-size:"32"`
	}, []byte] `ssz-type:"wrapper"`
	Wrapper2 dynssz.TypeWrapper[struct {
		Data []uint16 `ssz-size:"2"`
	}, []uint16] `ssz-type:"wrapper"`
	S1  *SimpleTypes1_S1
	S2  [4][]*SimpleTypes1_S2 `ssz-max:"?,64"`
	C1  *SimpleTypes1_C1
	C2  SimpleTypes1_C1
	LC1 []SimpleTypes1_C1    `ssz-max:"64"`
	LC2 [][]*SimpleTypes1_C1 `ssz-max:"64,64"`
}

var SimpleTypes1_Payload = SimpleTypes1{
	B1:      true,
	I8:      1,
	I16:     2,
	I32:     3,
	I64:     4,
	I128:    [16]byte{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16},
	I256:    [4]uint64{1, 2, 3, 4},
	Vec8:    []uint8{1, 2, 3, 4},
	Vec32:   []uint32{1, 2, 3, 4},
	Vec128:  [][2]uint64{{1, 2}, {3, 4}},
	BitVec:  [8]byte{1, 2, 3, 4, 5, 6, 7, 8},
	BitVec2: [8]byte{0xff, 0x07},
	Lst8:    []uint8{1, 2, 3, 4},
	Lst32:   []uint32{1, 2, 3, 4},
	Lst128:  [][2]uint64{{1, 2}, {3, 4}},
	BigLst8: []uint8{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35},
	BitLst:  []byte{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16},
	F1:      [2][]uint16{{1, 2}, {3, 4}},
	F2:      [10]uint8{1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
	Str:     "hello",
	Wrapper1: dynssz.TypeWrapper[struct {
		Data []byte `ssz-size:"32"`
	}, []byte]{
		Data: []byte{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16},
	},
	Wrapper2: dynssz.TypeWrapper[struct {
		Data []uint16 `ssz-size:"2"`
	}, []uint16]{
		Data: []uint16{1, 2},
	},
	S1: &SimpleTypes1_S1{
		F1: []uint16{1, 2, 3, 4},
	},
	S2: [4][]*SimpleTypes1_S2{
		{
			&SimpleTypes1_S2{
				F1: []uint16{1, 2, 3, 4},
			},
		},
	},
	C1: &SimpleTypes1_C1{
		F1: 1,
	},
	C2: SimpleTypes1_C1{
		F1: 2,
	},
	LC1: []SimpleTypes1_C1{{F1: 1}},
	LC2: [][]*SimpleTypes1_C1{
		{
			&SimpleTypes1_C1{F1: 1},
		},
	},
}

type SimpleTypes1_S1 struct {
	Data []byte   `ssz-size:"32"`
	F1   []uint16 `ssz-max:"64"`
}

type SimpleTypes1_S2 struct {
	F1 []uint16 `ssz-max:"64"`
}

type SimpleTypes1_C1 struct {
	F1 uint16
}

type SimpleTypes2 struct {
	F1 uint16
	F2 []*SimpleTypes2_C1 `ssz-size:"4"`
}

type SimpleTypes2_C1 struct {
	F1 []uint16   `ssz-size:"4"`
	F2 [][]uint16 `ssz-max:"4,4"`
}

var SimpleTypes2_Payload = SimpleTypes2{
	F1: 1,
	F2: []*SimpleTypes2_C1{
		{F1: []uint16{1, 2, 3, 4}},
	},
}

type TestBool bool
type TestUint8 uint8
type TestUint16 uint16
type TestUint32 uint32
type TestUint64 uint64

type SimpleTypes3 struct {
	B1       *bool
	B2       *TestBool
	I8       *uint8
	I82      *TestUint8
	I16      *uint16
	I162     *TestUint16
	I32      *uint32
	I322     *TestUint32
	I64      *uint64
	I642     *TestUint64
	I128     *[16]byte
	I256     *[4]uint64
	Vec8     []*uint8     `ssz-size:"4"`
	Vec32    []*uint32    `ssz-size:"4"`
	Vec128   []*[2]uint64 `ssz-type:"?,uint128" ssz-size:"4"`
	BitVec   [8]*byte     `ssz-type:"bitvector"`
	BitVec2  [8]*byte     `ssz-type:"bitvector" ssz-bitsize:"12"`
	Lst8     []*uint8     `ssz-max:"4"`
	Lst32    []*uint32    `ssz-max:"4"`
	Lst128   []*[2]uint64 `ssz-type:"?,uint128" ssz-max:"4"`
	BigLst8  []*uint8     `ssz-max:"35"`
	BitLst   []*byte      `ssz-max:"16"`
	F1       [2][]*uint16 `ssz-max:"?,64"`
	F2       [10]*uint8   `ssz-size:"5"`
	Str      *string      `ssz-max:"8"`
	Wrapper1 *dynssz.TypeWrapper[struct {
		Data []*byte `ssz-size:"32"`
	}, []*byte] `ssz-type:"wrapper"`
	Wrapper2 dynssz.TypeWrapper[struct {
		Data []*uint16 `ssz-size:"2"`
	}, []*uint16] `ssz-type:"wrapper"`
	Wrapper3 *SimpleTypes3_Wrapper3 `ssz-type:"wrapper"`
}

type SimpleTypes3_Wrapper3 struct {
	Test bool
}

var (
	b1   = true
	i8   = uint8(1)
	i16  = uint16(2)
	i32  = uint32(3)
	i64  = uint64(4)
	str  = "hello"
	i128 = [16]byte{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16}
	v128 = [2]uint64{1, 2}
	i256 = [4]uint64{1, 2, 3, 4}
)

var SimpleTypes3_Payload = SimpleTypes3{
	B1:      &b1,
	B2:      (*TestBool)(&b1),
	I8:      &i8,
	I82:     (*TestUint8)(&i8),
	I16:     &i16,
	I162:    (*TestUint16)(&i16),
	I32:     &i32,
	I322:    (*TestUint32)(&i32),
	I64:     &i64,
	I642:    (*TestUint64)(&i64),
	I128:    &i128,
	I256:    &i256,
	Vec8:    []*uint8{&i8, &i8, &i8, &i8},
	Vec32:   []*uint32{&i32, &i32, &i32, &i32},
	Vec128:  []*[2]uint64{&v128, &v128},
	BitVec:  [8]*byte{&i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8},
	BitVec2: [8]*byte{&i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8},
	Lst8:    []*uint8{&i8, &i8, &i8, &i8},
	Lst32:   []*uint32{&i32, &i32, &i32, &i32},
	Lst128:  []*[2]uint64{&v128, &v128},
	BigLst8: []*uint8{&i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8},
	BitLst:  []*byte{&i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8},
	F1:      [2][]*uint16{{&i16, &i16}, {&i16, &i16}},
	F2:      [10]*uint8{&i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8},
	Str:     &str,
	Wrapper1: &dynssz.TypeWrapper[struct {
		Data []*byte `ssz-size:"32"`
	}, []*byte]{
		Data: []*byte{&i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8, &i8},
	},
	Wrapper3: &SimpleTypes3_Wrapper3{
		Test: true,
	},
}

type SimpleTypesWithSpecs struct {
	Vec8    []uint8     `ssz-size:"4" dynssz-size:"VEC8_SIZE"`
	Vec32   []uint32    `ssz-size:"4" dynssz-size:"VEC32_SIZE"`
	Vec128  [][2]uint64 `ssz-type:"?,uint128" ssz-size:"4" dynssz-size:"VEC128_SIZE"`
	Vec2    [8]uint16   `ssz-size:"8" dynssz-size:"VEC2_SIZE"`
	BitVec  []byte      `ssz-type:"bitvector" ssz-size:"8" dynssz-size:"BITVEC_SIZE"`
	BitVec2 []byte      `ssz-type:"bitvector" ssz-bitsize:"12" dynssz-bitsize:"BITVEC2_SIZE"`
	Lst8    []uint8     `ssz-max:"4" dynssz-max:"LST8_MAX"`
	Lst32   []uint32    `ssz-max:"4" dynssz-max:"LST32_MAX"`
	Lst128  [][2]uint64 `ssz-type:"?,uint128" ssz-max:"4" dynssz-max:"LST128_MAX"`
	Lst2    [][]uint16  `ssz-max:"4,8" dynssz-max:"LST2_MAX"`
	BitLst  []byte      `ssz-max:"16" dynssz-max:"BITLST_MAX"`
	Str1    string      `ssz-max:"8" dynssz-max:"STR_MAX"`
	Str2    string      `ssz-size:"10" dynssz-size:"STR_SIZE"`
	C1      SimpleTypesWithSpecs_C1
	C2      []SimpleTypesWithSpecs_C2     `ssz-max:"64"`
	VC1     [2][]*SimpleTypesWithSpecs_C1 `ssz-max:"?,64"`
}

type SimpleTypesWithSpecs_C1 struct {
	F1 []uint16   `ssz-size:"4" dynssz-size:"F1_MAX"`
	F2 [][]uint16 `ssz-max:"4,4" dynssz-max:"F2_MAX,F2_MAX"`
	// C1 []*SimpleTypesWithSpecs_C2 `ssz-size:"4" dynssz-size:"F1_MAX"`
}

type SimpleTypesWithSpecs_C2 struct {
	F1 []uint16   `ssz-size:"4" dynssz-size:"F1_MAX"`
	F2 [][]uint16 `ssz-max:"4,4" dynssz-max:"F2_MAX,F2_MAX"`
}

type SimpleTypesWithSpecs2 struct {
	C3  [][4]*SimpleTypesWithSpecs_C3 `ssz-max:"64"`
	VC1 [2][]*SimpleTypesWithSpecs_C1 `ssz-max:"?,64"`
}

type SimpleTypesWithSpecs_C3 struct {
	F1 []uint16 `ssz-size:"4" dynssz-size:"F1_MAX"`
	F2 uint16
}

var SimpleTypesWithSpecs_Payload = SimpleTypesWithSpecs{
	Vec8:    []uint8{1, 2, 3, 4, 5, 6},
	Vec32:   []uint32{1, 2, 3, 4, 5, 6, 7, 8},
	Vec128:  [][2]uint64{{1, 2}, {3, 4}},
	Vec2:    [8]uint16{1, 2, 3},
	BitVec:  []byte{1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
	BitVec2: []byte{0xff, 0x07},
	Lst8:    []uint8{1, 2, 3, 4, 5, 6},
	Lst32:   []uint32{1, 2, 3, 4, 5, 6, 7, 8},
	Lst128:  [][2]uint64{{1, 2}, {3, 4}},
	Lst2:    [][]uint16{{1, 2}, {3, 4}},
	BitLst:  []byte{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20},
	Str1:    "hello",
	Str2:    "hello2",
	C1:      SimpleTypesWithSpecs_C1{F1: []uint16{1, 2, 3, 4}},
	C2:      []SimpleTypesWithSpecs_C2{{F1: []uint16{1, 2, 3, 4}}},
	VC1: [2][]*SimpleTypesWithSpecs_C1{
		{
			&SimpleTypesWithSpecs_C1{F1: []uint16{1, 2, 3, 4}},
		},
		{
			&SimpleTypesWithSpecs_C1{F1: []uint16{1, 2, 3, 6}},
		},
	},
}
var SimpleTypesWithSpecs2_Payload = SimpleTypesWithSpecs2{
	C3: [][4]*SimpleTypesWithSpecs_C3{{{F1: []uint16{1, 2, 3, 4}}}},
	VC1: [2][]*SimpleTypesWithSpecs_C1{
		{
			&SimpleTypesWithSpecs_C1{F1: []uint16{1, 2, 3, 4}},
		},
	},
}
var SimpleTypesWithSpecs_Specs = map[string]any{
	"VEC8_SIZE":    6,
	"VEC32_SIZE":   8,
	"VEC128_SIZE":  2,
	"VEC2_SIZE":    4,
	"BITVEC_SIZE":  10,
	"BITVEC2_SIZE": 12,
	"LST8_MAX":     6,
	"LST32_MAX":    8,
	"LST128_MAX":   2,
	"LST2_MAX":     8,
	"BITLST_MAX":   20,
	"STR_MAX":      16,
	"STR_SIZE":     11,
	"F1_MAX":       4,
	"F2_MAX":       8,
}

// SpecMatrix is a multi-dimensional fixed vector whose inner dimension size is
// itself dynssz-resolved. It exercises the outer-row zero-padding, which must
// pad each missing row with the runtime-resolved inner byte size, not the
// static fallback.
type SpecMatrix struct {
	M [][]byte `ssz-size:"2,4" dynssz-size:"MATRIX_OUTER,MATRIX_INNER"`
}

var SpecMatrix_Payload = SpecMatrix{
	// Under-filled on both dimensions: 3 of MATRIX_OUTER rows, each shorter than
	// MATRIX_INNER, so both per-row and missing-row padding are exercised.
	M: [][]byte{{1, 2, 3}, {4, 5}, {6}},
}

var SpecMatrix_Specs = map[string]any{
	"MATRIX_OUTER": 8,
	"MATRIX_INNER": 16,
}

// OptU32 is a variable-size container ending in an optional field. Trailing
// bytes after its encoding must be rejected by both engines.
type OptU32 struct {
	Pre uint32
	Opt *uint32 `ssz-type:"optional"`
}

var OptU32_Payload = OptU32{Pre: 1, Opt: func() *uint32 { v := uint32(7); return &v }()}

// ListOfList and Bytes2D are variable-size containers ending in a list of
// variable-length elements, used to confirm trailing-data rejection.
type ListOfList struct {
	L [][]uint32 `ssz-max:"4,4"`
}

var ListOfList_Payload = ListOfList{L: [][]uint32{{1, 2}, {3}}}

type Bytes2D struct {
	B [][]byte `ssz-max:"4,8"`
}

var Bytes2D_Payload = Bytes2D{B: [][]byte{{1, 2}, {3}}}

// VecOfList is a fixed-size vector of variable-size elements, exercising the
// inner offset-table validation distinct from a dynamic list.
type VecOfList struct {
	V [3][]uint16 `ssz-max:"?,64"`
}

var VecOfList_Payload = VecOfList{V: [3][]uint16{{1, 2}, {3}, {4, 5}}}

// ProgIndexOnly is a progressive container detected purely from ssz-index tags
// (no explicit ssz-type:"progressive-container"), exercising codegen auto-detection.
type ProgIndexOnly struct {
	A uint8 `ssz-index:"0"`
	B uint8 `ssz-index:"5"`
	C uint8 `ssz-index:"7"`
}

var ProgIndexOnly_Payload = ProgIndexOnly{A: 1, B: 2, C: 3}

// ZeroMaxList exercises ssz-max:"0", which is a "no limit" placeholder rather
// than a limit of zero -- the real limit is expected from dynssz-max. A list
// with no limit has no SSZ hash tree root, so the type needs extended types,
// and it is generated in the extended-types batch alongside UnboundedList.
type ZeroMaxList struct {
	X []uint64 `ssz-max:"0"`
}

// UnboundedList and UnboundedBitlist carry no limit at all. SSZ has no root for
// them -- List[T, N] and Bitlist[N] need N to merkleize -- so they are only
// analyzable with extended types, and their roots mix in the length so the root
// still identifies the value. Nothing else will agree on those roots.
type UnboundedList struct {
	X []uint64
}

type UnboundedBitlist struct {
	B []byte `ssz-type:"bitlist"`
}

var UnboundedList_Payload = UnboundedList{X: []uint64{1, 2, 3}}

var UnboundedBitlist_Payload = UnboundedBitlist{B: []byte{0x0f}}

var ZeroMaxList_Payload = ZeroMaxList{X: []uint64{1, 2, 3}}

// VecSpecLen is a Go array whose SSZ length comes from a spec value. The static
// ssz-size is the fallback used when the spec does not define the expression,
// so the resolved length may exceed it -- the array's own length is the real
// bound. Both a word array and a byte array, which take different paths.
type VecSpecLen struct {
	V [8]uint64 `ssz-size:"4" dynssz-size:"VECSPEC_LEN"`
	B [8]byte   `ssz-size:"4" dynssz-size:"VECSPEC_LEN"`
}

var VecSpecLen_Payload = VecSpecLen{
	V: [8]uint64{1, 2, 3, 4, 5, 6, 7, 8},
	B: [8]byte{1, 2, 3, 4, 5, 6, 7, 8},
}

// The resolved length is twice the static fallback, so anything bounding by the
// fallback truncates.
var VecSpecLen_Specs = map[string]any{"VECSPEC_LEN": 8}

// SpecSizedElem is a dynamic element whose fixed section a spec value
// decides. A list of them generated in a later batch (SpecSizedList) describes
// the element without its subtree and must not bound the list by the static
// fallback, which a preset can shrink below.
type SpecSizedElem struct {
	V [8]uint64 `ssz-size:"4" dynssz-size:"VECSPEC_LEN"`
	L []uint64  `ssz-max:"4"`
}

type SpecSizedList struct {
	Items []*SpecSizedElem `ssz-max:"4"`
}

// SpecPairElem is a dynamic element with three spec-decided widths. A list of
// them generated in a later batch (SpecPairList) resolves each on its own, as
// the element's code does, so a spec that defines only some of them, or sets
// a bit count the byte count rounds up, still decodes.
type SpecPairElem struct {
	A    []byte    `ssz-size:"32" dynssz-size:"SPEC_A"`
	B    [8]uint64 `ssz-size:"4" dynssz-size:"SPEC_B"`
	Bits []byte    `ssz-type:"bitvector" ssz-bitsize:"20" dynssz-bitsize:"SPEC_BITS"`
	L    []uint64  `ssz-max:"4"`
}

type SpecPairList struct {
	Items []*SpecPairElem `ssz-max:"4"`
}

// SpecPairVec holds children generated in an earlier batch: a vector of
// SpecPairElem, a dynamic field whose body is not part of the fixed section,
// and a VecSpecLen, a static child whose declared, spec-decided size the
// declaration imports. A list of SpecPairVec generated later is bounded by
// that declaration.
type SpecPairVec struct {
	Pair [2]*SpecPairElem
	V    VecSpecLen
	L    []uint64 `ssz-max:"4"`
}

// SpecPairVecList is generated in-process by the codegen tests only; it
// lists SpecPairVec elements, whose declaration imports SpecPairElem's.
type SpecPairVecList struct {
	Items []*SpecPairVec `ssz-max:"4"`
}

// SpecOnlyElem is a dynamic element whose vector has no static fallback: its
// declared floor part (VLEN):0 is nothing until VLEN is defined, so a list of
// them generated later (SpecOnlyList) decodes an empty list without VLEN and
// is bounded once it is defined.
type SpecOnlyElem struct {
	V []byte   `dynssz-size:"VLEN"`
	L []uint64 `ssz-max:"4"`
}

type SpecOnlyList struct {
	Items []*SpecOnlyElem `ssz-max:"4"`
}

// OneByteLists holds lists whose elements hold at least one byte, a bit list's
// termination bit or a union's selector, so their offset tables are bounded
// by one byte per element.
type OneByteLists struct {
	Bits   [][]byte `ssz-type:"list,bitlist" ssz-max:"4,64"`
	Unions []dynssz.CompatibleUnion[struct {
		A uint32
		B uint64
	}] `ssz-max:"4"`
}

var SpecSizedList_Payload = SpecSizedList{
	Items: []*SpecSizedElem{
		{V: [8]uint64{1, 2, 3, 4, 5, 6, 7, 8}},
		{V: [8]uint64{9}, L: []uint64{10}},
		{},
		{},
	},
}

// WrappedElemLists holds lists whose elements are type wrappers around basic
// values, alongside the plain lists they must hash identically to. A wrapper is
// transparent to SSZ: the list packs the wrapped values and merkleizes them
// under the packed chunk count. Reading the wrapper as the element instead
// makes it look composite, giving one chunk per element -- a different tree
// depth, and so a different root at every length.
type WrappedElemLists struct {
	W []dynssz.TypeWrapper[struct {
		Data uint64
	}, uint64] `ssz-max:"16" ssz-type:"?,wrapper"`
	B []dynssz.TypeWrapper[struct {
		Data byte
	}, byte] `ssz-max:"64" ssz-type:"?,wrapper"`
}

// PlainElemLists is WrappedElemLists with the wrappers removed. Both types
// describe the same SSZ types, so they must produce the same root.
type PlainElemLists struct {
	W []uint64 `ssz-max:"16"`
	B []byte   `ssz-max:"64"`
}

var WrappedElemLists_Payload = func() WrappedElemLists {
	var v WrappedElemLists
	v.W = make([]dynssz.TypeWrapper[struct {
		Data uint64
	}, uint64], 5)
	for i := range v.W {
		v.W[i].Set(uint64(i + 1))
	}
	v.B = make([]dynssz.TypeWrapper[struct {
		Data byte
	}, byte], 5)
	for i := range v.B {
		v.B[i].Set(byte(i + 1))
	}

	return v
}()

var PlainElemLists_Payload = PlainElemLists{
	W: []uint64{1, 2, 3, 4, 5},
	B: []byte{1, 2, 3, 4, 5},
}

// SpecShrunkList is a dynamic list whose element carries a spec-driven fixed
// section. The generator only sees the static tag values, so it cannot know the
// element's minimum size: a preset that resolves SHRUNK_SIZE below the tag
// default makes every element smaller than the generator's view of it, and a
// decoder bounding the declared count by the generated constant would reject
// valid input.
type SpecShrunkList struct {
	Items []SpecShrunkElem `ssz-max:"64"`
}

type SpecShrunkElem struct {
	Fixed []uint16 `ssz-size:"4" dynssz-size:"SHRUNK_SIZE"`
	Tail  []uint8  `ssz-max:"8"`
}

var SpecShrunkList_Payload = SpecShrunkList{
	Items: []SpecShrunkElem{
		{Fixed: []uint16{1}},
		{Fixed: []uint16{2}},
		{Fixed: []uint16{3}},
		{Fixed: []uint16{4}},
	},
}

// SpecVecList's element is a vector of dynamic containers, so the element's
// minimum is its offset table plus every entry's own fixed section -- and the
// vector's length is spec-driven, which the tag alone does not state. A decoder
// reading the vector's declared length as a byte count would bound the region
// twelve times too loosely.
type SpecVecList struct {
	Items [][]SpecVecElem `ssz-size:"?,2" dynssz-size:"?,VEC_COUNT" ssz-max:"64"`
}

type SpecVecElem struct {
	Tail []uint8 `ssz-max:"8"`
}

var SpecVecList_Payload = SpecVecList{
	Items: [][]SpecVecElem{
		{{}, {}, {}},
		{{Tail: []uint8{1}}, {}, {}},
		{{}, {}, {Tail: []uint8{2, 3}}},
	},
}

// SHRUNK_SIZE resolves to a quarter of the static ssz-size, so each element is
// 6 bytes where the generator sees 12. VEC_COUNT likewise exceeds its tag, so
// each SpecVecList item holds three entries, not two.
var SpecShrunkList_Specs = map[string]any{"SHRUNK_SIZE": 1, "VEC_COUNT": 3}

// ProgBitlistZeroTop reproduces the EIP-7916 progressive-bitlist HTR bug: a
// bitlist whose highest data bits are zero leaves the top 256-bit chunk all-zero.
// The progressive tree shape is defined by the chunk count (ceil(size/256)), so
// the all-zero top chunk must NOT be dropped. The golden root in
// TestCodegenProgressiveBitlistGolden is cross-checked against
// ethereum/remerkleable and an independent raw-SHA256 implementation; the
// reflection and codegen paths share the hasher, so only a golden (not a
// differential) test catches a regression here.
type ProgBitlistZeroTop struct {
	X []byte `ssz-type:"progressive-bitlist" ssz-max:"2000"`
}

// progBitlistZeroTopBits builds a 257-bit bitlist with only bit 0 set, so bit 256
// (the single data bit of the 2nd chunk) is zero and the top chunk is all-zero.
func progBitlistZeroTopBits() []byte {
	b := make([]byte, 257/8+1) // 33 bytes
	b[0] = 0x01                // bit 0 set
	b[257/8] |= 1 << (257 % 8) // termination bit at position 257
	return b
}

var ProgBitlistZeroTop_Payload = ProgBitlistZeroTop{X: progBitlistZeroTopBits()}

type ProgressiveTypes struct {
	C1 struct {
		F1 uint64      `ssz-index:"0"`
		F3 uint64      `ssz-index:"2"`
		F7 uint8       `ssz-index:"6"`
		F8 [2][]uint16 `ssz-size:"2,5" ssz-index:"9"`
	} `ssz-type:"progressive-container"`
	L1 []uint64 `ssz-type:"progressive-list"`
	L2 []byte   `ssz-type:"progressive-bitlist"`
	U1 dynssz.CompatibleUnion[struct {
		F1 uint32
		F2 [2][]uint8 `ssz-size:"2,5"`
		F3 [4]*SimpleTypesWithSpecs_C1
	}]
}

var ProgressiveTypes_Payload = ProgressiveTypes{
	C1: struct {
		F1 uint64      `ssz-index:"0"`
		F3 uint64      `ssz-index:"2"`
		F7 uint8       `ssz-index:"6"`
		F8 [2][]uint16 `ssz-size:"2,5" ssz-index:"9"`
	}{
		F1: 12345,
		F3: 67890,
		F7: 123,
		F8: [2][]uint16{{1, 2}, {3, 4, 5}},
	},
	L1: []uint64{12345, 67890},
	L2: []byte{1, 2, 3, 4, 5, 6, 7, 8, 9, 10},
	U1: dynssz.CompatibleUnion[struct {
		F1 uint32
		F2 [2][]uint8 `ssz-size:"2,5"`
		F3 [4]*SimpleTypesWithSpecs_C1
	}]{
		Variant: 1,
		Data:    uint32(0x12345678),
	},
}

// ClassicUnionTypes exercises classic spec unions (dynssz.Union) through the
// generated code: a None-declaring union with the empty option selected (U1),
// the same union type with its dynamic variant selected (U2), and a union
// without None whose selector 0 carries a value (U3).
type ClassicUnionTypes struct {
	U1 dynssz.Union[struct {
		N  dynssz.None
		F1 uint32
		F2 []uint8 `ssz-max:"16"`
	}]
	U2 dynssz.Union[struct {
		N  dynssz.None
		F1 uint32
		F2 []uint8 `ssz-max:"16"`
	}]
	U3 dynssz.Union[struct {
		F1 uint64
		F2 [2][]uint16 `ssz-size:"2,5"`
	}]
}

var ClassicUnionTypes_Payload = ClassicUnionTypes{
	// U1 stays zero-valued: Variant 0 with nil Data is the None option.
	U2: dynssz.Union[struct {
		N  dynssz.None
		F1 uint32
		F2 []uint8 `ssz-max:"16"`
	}]{
		Variant: 2,
		Data:    []uint8{1, 2, 3},
	},
	U3: dynssz.Union[struct {
		F1 uint64
		F2 [2][]uint16 `ssz-size:"2,5"`
	}]{
		Variant: 0,
		Data:    uint64(0x1122334455667788),
	},
}

type CustomTypes1 struct {
	F1 CustomType1 `ssz-type:"custom"`
}

var CustomTypes1_Payload = CustomTypes1{
	F1: CustomType1(12345),
}

type CustomType1 uint64

var _ = sszutils.FastsszMarshaler(new(CustomType1))
var _ = sszutils.FastsszUnmarshaler(new(CustomType1))
var _ = sszutils.FastsszHashRoot(new(CustomType1))

func (c *CustomType1) MarshalSSZ() ([]byte, error) {
	buf := make([]byte, 8)
	return c.MarshalSSZTo(buf)
}

func (c *CustomType1) MarshalSSZTo(buf []byte) ([]byte, error) {
	return sszutils.MarshalUint64(buf, uint64(*c)), nil
}

func (c *CustomType1) SizeSSZ() int {
	return 8
}

func (c *CustomType1) UnmarshalSSZ(data []byte) error {
	*c = CustomType1(sszutils.UnmarshallUint64(data))
	return nil
}

func (c *CustomType1) HashTreeRoot() ([32]byte, error) {
	buf := make([]byte, 32)
	sszutils.MarshalUint64(buf, uint64(*c))
	return [32]byte(buf), nil
}

type ViewTypes1_Base struct {
	F1 uint64
	F2 []uint64    `ssz-max:"64"`
	F3 [2][]uint64 `ssz-max:"?,64"`
	C1 *ViewTypes1_C1
}

type ViewTypes1_C1 struct {
	F1 uint64
	F2 []uint64 `ssz-max:"64"`
}

type ViewTypes1_View1 struct {
	F1 uint64
	F3 [2][]uint64 `ssz-size:"2,5"`
	C1 *ViewTypes1_View1_C1
}

type ViewTypes1_View1_C1 struct {
	F1 uint64
}

type ViewTypes1_View2 struct {
	F1 uint64
	F2 []uint64 `ssz-max:"64"`
	C1 *ViewTypes1_View2_C1
}

type ViewTypes1_View2_C1 struct {
	F2 []uint64 `ssz-max:"64"`
}

var ViewTypes1_Payload = ViewTypes1_Base{
	F1: 12345,
	F2: []uint64{12345, 67890},
	F3: [2][]uint64{{12345, 67890}, {12345, 67890}},
	C1: &ViewTypes1_C1{
		F1: 12345,
		F2: []uint64{12345, 67890},
	},
}

// ViewList_Base holds a list of ViewTypes1_Base served through the dynamic
// ViewTypes1_View2. The elements are generated in an earlier batch, so the
// ViewList batch describes them without their subtree and bounds the list's
// offset table by the fixed section their structure guarantees: 20 bytes for
// the data type, 16 for the view.
type ViewList_Base struct {
	Items []*ViewTypes1_Base `ssz-max:"4"`
	Tail  uint8
}

type ViewList_View struct {
	Items []*ViewTypes1_View2 `ssz-max:"4"`
	Tail  uint8
}

var ViewList_Payload = ViewList_Base{
	Items: []*ViewTypes1_Base{
		{F1: 1, F2: []uint64{2, 3}, F3: [2][]uint64{{4}, {5, 6}}, C1: &ViewTypes1_C1{F1: 7, F2: []uint64{8}}},
		{F1: 9, C1: &ViewTypes1_C1{F1: 10}},
		{},
	},
	Tail: 11,
}

// OptionalListTypes exercises ssz-type:"optional-list" — pointers encoded as
// canonical List[T, 1]. Static and dynamic element pointers are covered, and
// optional-list works without extended types.
type OptionalListTypes struct {
	StaticOpt  *uint32                  `ssz-type:"optional-list"`
	DynamicOpt *OptionalListTypes_Inner `ssz-type:"optional-list"`
}

type OptionalListTypes_Inner struct {
	Tag  uint16
	Data []byte `ssz-max:"16"`
}

var optListInner = &OptionalListTypes_Inner{
	Tag:  0xbeef,
	Data: []byte{1, 2, 3, 4, 5},
}

var optListU32 = uint32(1337)

// Both pointers populated.
var OptionalListTypes_Payload1 = OptionalListTypes{
	StaticOpt:  &optListU32,
	DynamicOpt: optListInner,
}

// OptionalListSliceVector exercises ssz-type:"optional-list" over a pointer to a
// SLICE whose fixed length comes from ssz-size (a vector), plus the byte-vector
// form. These are spec-identical to an optional-list over a Go array
// (*[2]uint16 / *[4]byte): the optional-list frames the pointer as List[T, 1]
// where T is the fixed-size inner vector. The slice spelling only stays correct
// if the element's ssz-size survives into the element descriptor — otherwise the
// inner vector degrades to a variable list (wrong marshal + wrong root).
type OptionalListSliceVector struct {
	VecU16  *[]uint16 `ssz-size:"2" ssz-type:"optional-list"`
	VecByte *[]byte   `ssz-size:"4" ssz-type:"optional-list"`
}

var (
	optSliceVecU16  = []uint16{0x1234, 0x5678}
	optSliceVecByte = []byte{0xaa, 0xbb, 0xcc, 0xdd}
)

// Both optional vectors present.
var OptionalListSliceVector_Payload1 = OptionalListSliceVector{
	VecU16:  &optSliceVecU16,
	VecByte: &optSliceVecByte,
}

// Both nil.
var OptionalListSliceVector_Payload2 = OptionalListSliceVector{}

// Only the uint16 vector present.
var OptionalListSliceVector_Payload3 = OptionalListSliceVector{
	VecU16: &optSliceVecU16,
}

// UnionExprVariantSize is a regression type for the generated union size code.
// The union variant is a vector whose length comes from a dynssz-size
// expression, so its size is computed purely from that expression and never
// reads the type-asserted variant value. Without an explicit `_ = v`, the
// generated size code left `v` declared-and-unused and failed to compile.
type UnionExprVariantSize struct {
	U dynssz.CompatibleUnion[struct {
		F0 []uint16 `ssz-size:"4" dynssz-size:"UNION_VEC_SIZE"`
	}]
}

var UnionExprVariantSize_Specs = map[string]any{
	"UNION_VEC_SIZE": uint64(4),
}

var UnionExprVariantSize_Payload = UnionExprVariantSize{
	U: dynssz.CompatibleUnion[struct {
		F0 []uint16 `ssz-size:"4" dynssz-size:"UNION_VEC_SIZE"`
	}]{Variant: 1, Data: []uint16{1, 2, 3, 4}},
}

// VecDynElemExprSize_Inner is the variable-size element of VecDynElemExprSize.
type VecDynElemExprSize_Inner struct {
	D []byte `ssz-max:"8"`
}

// VecDynElemExprSize is a regression type for the generated stream decoder: a
// vector of dynamic-size elements whose length comes from a dynssz-size
// expression. The decoder's first-offset check compares the uint32 offset
// against `<len-expr>*4`; when the length is a typed int expression the RHS must
// be cast to uint32, otherwise the generated code failed to compile.
type VecDynElemExprSize struct {
	V []VecDynElemExprSize_Inner `ssz-size:"2" dynssz-size:"VDE_SIZE"`
}

var VecDynElemExprSize_Specs = map[string]any{
	"VDE_SIZE": uint64(2),
}

var VecDynElemExprSize_Payload = VecDynElemExprSize{
	V: []VecDynElemExprSize_Inner{
		{D: []byte{1, 2, 3}},
		{D: []byte{4, 5}},
	},
}

// Both pointers nil.
var OptionalListTypes_Payload2 = OptionalListTypes{
	StaticOpt:  nil,
	DynamicOpt: nil,
}

// Mixed: static populated, dynamic nil.
var OptionalListTypes_Payload3 = OptionalListTypes{
	StaticOpt:  &optListU32,
	DynamicOpt: nil,
}

type ExtendedTypes1 struct {
	I8   int8
	I16  int16
	I32  int32
	I64  int64
	F32  float32
	F64  float64
	Opt1 *uint64 `ssz-type:"optional"`
	Opt2 *int32  `ssz-type:"optional"`
	Big1 big.Int
}

var (
	extOpt1 = uint64(12345)
	extOpt2 = int32(-42)
)

var ExtendedTypes1_Payload1 = ExtendedTypes1{
	I8:   -42,
	I16:  -1337,
	I32:  817482215,
	I64:  -848028848028,
	F32:  3.14,
	F64:  2.718281828,
	Opt1: &extOpt1,
	Opt2: &extOpt2,
	Big1: *big.NewInt(123456789),
}

var ExtendedTypes1_Payload2 = ExtendedTypes1{
	I8:   0,
	I16:  0,
	I32:  0,
	I64:  0,
	F32:  0,
	F64:  0,
	Opt1: nil,
	Opt2: nil,
	Big1: *big.NewInt(0),
}

// ExtendedBigIntMax carries a limit-bearing big.Int, exercising the ssz-max
// enforcement on the encode and decode paths of both engines.
type ExtendedBigIntMax struct {
	B big.Int `ssz-max:"5"`
}

var ExtendedBigIntMax_Payload = ExtendedBigIntMax{B: *big.NewInt(0x11223344)}

// CoverageTypes1 covers: regular bitlists, bitlists with spec max,
// dynamic vectors/lists (slice-based with zero-padding), bool vectors.
type CoverageTypes1 struct {
	BitLst1 []byte                     `ssz-type:"bitlist" ssz-max:"16"`                         // regular bitlist with static max
	BitLst2 []byte                     `ssz-type:"bitlist" ssz-max:"16" dynssz-max:"BITLST_MAX"` // regular bitlist with spec max
	DynVec1 []*CoverageTypes1_DynChild `ssz-size:"4"`                                            // slice vector of dynamic ptrs
	DynLst1 []*CoverageTypes1_DynChild `ssz-max:"4"`                                             // list of dynamic ptrs
	DynVec2 []CoverageTypes1_DynChild  `ssz-size:"2"`                                            // slice vector of dynamic values
	DynLst2 []CoverageTypes1_DynChild  `ssz-max:"4"`                                             // list of dynamic values
	VecBool [4]bool                    // array vector of bools (hash pack mode)
	LstBool []bool                     `ssz-max:"8"`  // list of bools
	VecU16  []uint16                   `ssz-size:"4"` // slice vector of uint16 (hash pack mode)
	LstU16  []uint16                   `ssz-max:"8"`  // list of uint16
}

type CoverageTypes1_DynChild struct {
	F1 uint32
	F2 []byte `ssz-max:"8"` // makes it dynamic
}

var CoverageTypes1_Payload = CoverageTypes1{
	BitLst1: []byte{0x03},
	BitLst2: []byte{0x07},
	DynVec1: []*CoverageTypes1_DynChild{
		{F1: 1, F2: []byte{1, 2}},
		{F1: 2, F2: []byte{3, 4, 5}},
	},
	DynLst1: []*CoverageTypes1_DynChild{
		{F1: 3, F2: []byte{6}},
	},
	DynVec2: []CoverageTypes1_DynChild{
		{F1: 4, F2: []byte{7, 8}},
	},
	DynLst2: []CoverageTypes1_DynChild{
		{F1: 5, F2: []byte{9, 10, 11}},
	},
	VecBool: [4]bool{true, false, true, false},
	LstBool: []bool{true, true, false},
	VecU16:  []uint16{100, 200, 300, 400},
	LstU16:  []uint16{500, 600},
}

// CoverageTypes2 covers: time.Time, pointer extended types, pointer big.Int,
// vectors/lists of extended types (pack-mode hashing, sizeType paths).
type CoverageTypes2 struct {
	T1     time.Time
	I8p    *int8
	I16p   *int16
	I32p   *int32
	I64p   *int64
	F32p   *float32
	F64p   *float64
	Bigp   *big.Int
	VecI8  [4]int8    // vector of int8 (hash pack mode)
	LstI16 []int16    `ssz-max:"8"`  // list of int16
	VecI32 []int32    `ssz-size:"4"` // vector of int32 (slice)
	LstI64 []int64    `ssz-max:"4"`  // list of int64
	VecF32 [2]float32 // vector of float32
	LstF64 []float64  `ssz-max:"4"` // list of float64
}

var (
	covI8  = int8(-42)
	covI16 = int16(-1337)
	covI32 = int32(817482215)
	covI64 = int64(-848028848028)
	covF32 = float32(3.14)
	covF64 = float64(2.718281828)
)

var CoverageTypes2_Payload1 = CoverageTypes2{
	T1:     time.Unix(1234567890, 0),
	I8p:    &covI8,
	I16p:   &covI16,
	I32p:   &covI32,
	I64p:   &covI64,
	F32p:   &covF32,
	F64p:   &covF64,
	Bigp:   big.NewInt(42),
	VecI8:  [4]int8{-1, 2, -3, 4},
	LstI16: []int16{100, -200, 300},
	VecI32: []int32{1000, -2000, 3000, -4000},
	LstI64: []int64{100000, -200000},
	VecF32: [2]float32{1.5, -2.5},
	LstF64: []float64{3.14, -2.718},
}

var CoverageTypes2_Payload2 = CoverageTypes2{
	T1:     time.Time{},
	I8p:    nil,
	I16p:   nil,
	I32p:   nil,
	I64p:   nil,
	F32p:   nil,
	F64p:   nil,
	Bigp:   nil,
	VecI8:  [4]int8{},
	LstI16: nil,
	VecI32: []int32{0, 0, 0, 0},
	LstI64: nil,
	VecF32: [2]float32{},
	LstF64: nil,
}

// Annotated non-struct types for testing sszutils.Annotate-based SSZ annotations.

// AnnotatedList is a basic annotated list of uint32 with max 20.
type AnnotatedList []uint32

var _ = sszutils.Annotate[AnnotatedList](`ssz-max:"20"`)

// AnnotatedList2 is a basic annotated list of uint64 with max 10.
type AnnotatedList2 []uint64

var _ = sszutils.Annotate[AnnotatedList2](`ssz-max:"10"`)

// AnnotatedByteList is an annotated byte list with max 32.
type AnnotatedByteList []byte

var _ = sszutils.Annotate[AnnotatedByteList](`ssz-max:"32"`)

// AnnotatedWithSpecs uses a dynamic spec expression for the max size.
type AnnotatedWithSpecs []uint32

var _ = sszutils.Annotate[AnnotatedWithSpecs](`ssz-max:"10" dynssz-max:"ANNOTATED_MAX"`)

// AnnotatedZeroStaticMax has only a placeholder static ssz-max (0); its real
// limit must come from the dynssz expression. When that expression resolves to 0
// there is no positive fallback, so both engines must error.
type AnnotatedZeroStaticMax []uint32

var _ = sszutils.Annotate[AnnotatedZeroStaticMax](`ssz-max:"0" dynssz-max:"ZEROSTATIC_MAX"`)

// AnnotatedFixedVec is an annotated FIXED-size byte vector. As a container
// field it is a static type and must be embedded inline without an offset.
type AnnotatedFixedVec []byte

var _ = sszutils.Annotate[AnnotatedFixedVec](`ssz-size:"8"`)

// AnnotatedFixedContainer embeds an annotated fixed-size type; wire layout
// must match the reflection descriptor (B inline, no offset).
type AnnotatedFixedContainer struct {
	A uint32
	B AnnotatedFixedVec
}

var AnnotatedFixedContainer_Payload = AnnotatedFixedContainer{
	A: 1,
	B: AnnotatedFixedVec{1, 2, 3, 4, 5, 6, 7, 8},
}

// AnnotatedContainer uses annotated types as fields WITHOUT field tags.
// The reflection path must resolve limits from the annotation registry;
// the codegen path delegates to each field's generated methods.
type AnnotatedContainer struct {
	F1 uint32
	L1 AnnotatedList     // limit 20 from annotation
	L2 AnnotatedList2    // limit 10 from annotation
	B1 AnnotatedByteList // limit 32 from annotation
}

var AnnotatedContainer_Payload = AnnotatedContainer{
	F1: 42,
	L1: AnnotatedList{1, 2, 3},
	L2: AnnotatedList2{100, 200},
	B1: AnnotatedByteList{0xaa, 0xbb, 0xcc, 0xdd},
}

// AnnotatedOverrideContainer has a field tag that overrides the annotation.
// AnnotatedList has ssz-max:"20" from its annotation, but the field tag
// narrows it to ssz-max:"5".
type AnnotatedOverrideContainer struct {
	F1 uint32
	L1 AnnotatedList `ssz-max:"5"`
}

var AnnotatedOverrideContainer_Payload = AnnotatedOverrideContainer{
	F1: 7,
	L1: AnnotatedList{10, 20, 30},
}

// AnnotatedSpecsContainer uses an annotated type with dynamic spec expressions.
type AnnotatedSpecsContainer struct {
	F1 uint32
	L1 AnnotatedWithSpecs // limit from ANNOTATED_MAX spec
}

var AnnotatedSpecsContainer_Payload = AnnotatedSpecsContainer{
	F1: 99,
	L1: AnnotatedWithSpecs{1, 2, 3, 4, 5},
}

var AnnotatedSpecs = map[string]any{
	"ANNOTATED_MAX": 20,
}

// AnnotatedNestedContainer uses annotated types at multiple nesting levels.
type AnnotatedNestedContainer struct {
	F1   uint32
	L1   AnnotatedList                // direct annotated field
	Lst  []AnnotatedList              `ssz-max:"4"` // list of annotated lists
	Sub  AnnotatedNestedContainer_S   // nested struct with annotated fields
	Subs []AnnotatedNestedContainer_S `ssz-max:"3"`
}

type AnnotatedNestedContainer_S struct {
	V1 uint16
	L1 AnnotatedByteList // annotated field inside nested struct
}

var AnnotatedNestedContainer_Payload = AnnotatedNestedContainer{
	F1: 1,
	L1: AnnotatedList{10, 20},
	Lst: []AnnotatedList{
		{1, 2, 3},
		{4, 5},
	},
	Sub: AnnotatedNestedContainer_S{
		V1: 100,
		L1: AnnotatedByteList{0x01, 0x02, 0x03},
	},
	Subs: []AnnotatedNestedContainer_S{
		{V1: 200, L1: AnnotatedByteList{0x0a}},
		{V1: 300, L1: AnnotatedByteList{0x0b, 0x0c}},
	},
}

// AnnotatedRoots is a list of 32-byte roots declared through Annotate.
type AnnotatedRoots [][]byte

var _ = sszutils.Annotate[AnnotatedRoots](`ssz-size:"?,32" ssz-max:"8"`)

// AnnotatedRootsField lowers the limit and keeps the root size from the
// annotation. It also describes the wrapper and unions below.
type AnnotatedRootsField struct {
	Data AnnotatedRoots `ssz-max:"4"`
}

// AnnotatedRootsHolder holds the same field as a container, a TypeWrapper, a
// Union and a CompatibleUnion.
type AnnotatedRootsHolder struct {
	C  AnnotatedRootsField
	W  dynssz.TypeWrapper[AnnotatedRootsField, AnnotatedRoots]
	U  dynssz.Union[AnnotatedRootsField]
	CU dynssz.CompatibleUnion[AnnotatedRootsField]
}

// InitAnnotatedList tests Annotate calls inside init() functions.
type InitAnnotatedList []uint16

func init() {
	sszutils.Annotate[InitAnnotatedList](`ssz-max:"8"`)
}

// CoverageTypes7 exercises getStaticSizeVar's container recursion path:
// SC1 is a static container with a dynssz-size field, used before
// a dynamic field L1, forcing offset computation via getStaticSizeVar.
type CoverageTypes7 struct {
	SC1 CoverageTypes7_SC
	L1  []uint16 `ssz-max:"8"`
}

type CoverageTypes7_SC struct {
	F1 []uint8 `ssz-size:"4" dynssz-size:"SC_SIZE"`
	F2 uint32
}

var CoverageTypes7_Payload = CoverageTypes7{
	SC1: CoverageTypes7_SC{
		F1: []uint8{1, 2, 3, 4, 5, 6},
		F2: 42,
	},
	L1: []uint16{100, 200, 300},
}

var CoverageTypes7_Specs = map[string]any{
	"SC_SIZE": 6,
}

// NoDynExprTypes mirrors common SSZ patterns but is generated with
// -without-dynamic-expressions to exercise the expression-stripping
// branches in every generator.
type NoDynExprTypes struct {
	Vec8   []uint8  `ssz-size:"4" dynssz-size:"VEC8_SIZE"`
	Vec32  []uint32 `ssz-size:"4" dynssz-size:"VEC32_SIZE"`
	BitVec []byte   `ssz-type:"bitvector" ssz-size:"8" dynssz-size:"BITVEC_SIZE"`
	Lst8   []uint8  `ssz-max:"4" dynssz-max:"LST8_MAX"`
	Lst32  []uint32 `ssz-max:"4" dynssz-max:"LST32_MAX"`
	BitLst []byte   `ssz-max:"16" dynssz-max:"BITLST_MAX"`
	Str1   string   `ssz-max:"8" dynssz-max:"STR_MAX"`
}

var NoDynExprTypes_Payload = NoDynExprTypes{
	Vec8:   []uint8{1, 2, 3, 4},
	Vec32:  []uint32{1, 2, 3, 4},
	BitVec: []byte{1, 2, 3, 4, 5, 6, 7, 8},
	Lst8:   []uint8{1, 2, 3, 4},
	Lst32:  []uint32{1, 2, 3, 4},
	BitLst: []byte{1, 2, 3, 4},
	Str1:   "hello",
}

// NoDynWrapped is a type wrapper around a uint64 generated without dynamic
// expressions.
type NoDynWrapped struct {
	Data uint64
}

var _ = sszutils.Annotate[NoDynWrapped](`ssz-type:"wrapper"`)

// NoDynWrappedDyn is a type wrapper whose only hash method is the dynamic
// one; static generation inlines its structure instead.
type NoDynWrappedDyn struct {
	Data uint64
}

var _ = sszutils.Annotate[NoDynWrappedDyn](`ssz-type:"wrapper"`)

var _ sszutils.DynamicHashRoot = (*NoDynWrappedDyn)(nil)

func (w *NoDynWrappedDyn) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint64(w.Data)
	return nil
}

// NoDynWrappedHolder places both wrappers where the static hasher packs them
// and as fields.
type NoDynWrappedHolder struct {
	L  []NoDynWrapped    `ssz-max:"8" ssz-type:"?,wrapper"`
	V  [4]NoDynWrapped   `ssz-type:"?,wrapper"`
	F  NoDynWrapped      `ssz-type:"wrapper"`
	DL []NoDynWrappedDyn `ssz-max:"8" ssz-type:"?,wrapper"`
	DF NoDynWrappedDyn   `ssz-type:"wrapper"`
}

// NoDynWrappedPlain is the twin with the wrappers removed.
type NoDynWrappedPlain struct {
	L  []uint64 `ssz-max:"8"`
	V  [4]uint64
	F  uint64
	DL []uint64 `ssz-max:"8"`
	DF uint64
}

var NoDynWrappedHolder_Payload = NoDynWrappedHolder{
	L:  []NoDynWrapped{{1}, {2}, {3}},
	V:  [4]NoDynWrapped{{4}, {5}, {6}, {7}},
	F:  NoDynWrapped{8},
	DL: []NoDynWrappedDyn{{9}, {10}},
	DF: NoDynWrappedDyn{11},
}

var NoDynWrappedPlain_Payload = NoDynWrappedPlain{
	L:  []uint64{1, 2, 3},
	V:  [4]uint64{4, 5, 6, 7},
	F:  8,
	DL: []uint64{9, 10},
	DF: 11,
}

// NoDynDualCustom is a custom type carrying both the static fastssz surface
// and the spec-aware dynssz surface.
type NoDynDualCustom struct{ V uint32 }

func (c *NoDynDualCustom) SizeSSZ() int { return 4 }

func (c *NoDynDualCustom) MarshalSSZ() ([]byte, error) { return c.MarshalSSZTo(nil) }

func (c *NoDynDualCustom) MarshalSSZTo(buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint32(buf, c.V), nil
}

func (c *NoDynDualCustom) UnmarshalSSZ(buf []byte) error {
	if len(buf) != 4 {
		return sszutils.ErrUnexpectedEOF
	}
	c.V = binary.LittleEndian.Uint32(buf)
	return nil
}

func (c *NoDynDualCustom) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	binary.LittleEndian.PutUint32(root[:], c.V)
	return root, nil
}

func (c *NoDynDualCustom) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return 4 }

func (c *NoDynDualCustom) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return c.MarshalSSZTo(buf)
}

func (c *NoDynDualCustom) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	return c.UnmarshalSSZ(buf)
}

func (c *NoDynDualCustom) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint32(c.V)
	return nil
}

// NoDynCustomHolder nests a dual-surface custom type and a static-only one;
// static generation reaches both through their static methods.
type NoDynCustomHolder struct {
	D NoDynDualCustom `ssz-type:"custom" ssz-size:"4"`
	S CustomType1     `ssz-type:"custom"`
	N uint64
}

// noDynStreamCustom carries a static surface and a spec-aware streaming one
// that agree on the encoding and the root.
type noDynStreamCustom struct{ A uint32 }

func (c *noDynStreamCustom) SizeSSZ() int                { return 4 }
func (c *noDynStreamCustom) MarshalSSZ() ([]byte, error) { return c.MarshalSSZTo(nil) }
func (c *noDynStreamCustom) MarshalSSZTo(buf []byte) ([]byte, error) {
	return sszutils.MarshalUint32(buf, c.A), nil
}
func (c *noDynStreamCustom) UnmarshalSSZ(buf []byte) error {
	if len(buf) != 4 {
		return sszutils.ErrUnexpectedEOF
	}
	c.A = sszutils.UnmarshallUint32(buf)
	return nil
}
func (c *noDynStreamCustom) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	binary.LittleEndian.PutUint32(root[:], c.A)
	return root, nil
}
func (c *noDynStreamCustom) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return 4 }
func (c *noDynStreamCustom) MarshalSSZEncoder(_ sszutils.DynamicSpecs, enc sszutils.Encoder) error {
	enc.EncodeUint32(c.A)
	return nil
}
func (c *noDynStreamCustom) UnmarshalSSZDecoder(_ sszutils.DynamicSpecs, dec sszutils.Decoder) error {
	v, err := dec.DecodeUint32()
	c.A = v
	return err
}
func (c *noDynStreamCustom) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint32(c.A)
	return nil
}

// NoDynStreamCustomHolder holds a custom type with both a static and a
// spec-aware streaming surface; generated statically, the buffer methods use
// the static one and the stream is written and read through the streaming one.
type NoDynStreamCustomHolder struct {
	C noDynStreamCustom `ssz-type:"custom" ssz-size:"4"`
	N uint64
}

var NoDynStreamCustomHolder_Payload = NoDynStreamCustomHolder{C: noDynStreamCustom{A: 0x01020304}, N: 5}

var NoDynCustomHolder_Payload = NoDynCustomHolder{D: NoDynDualCustom{7}, S: 8, N: 9}

// noDynStreamSpecCustom is a byte list whose limit is a spec value. Its static
// methods baked the limit of 4; its streaming methods resolve the spec.
type noDynStreamSpecCustom struct{ B []byte }

func (c *noDynStreamSpecCustom) SizeSSZ() int                { return len(c.B) }
func (c *noDynStreamSpecCustom) MarshalSSZ() ([]byte, error) { return c.MarshalSSZTo(nil) }
func (c *noDynStreamSpecCustom) MarshalSSZTo(buf []byte) ([]byte, error) {
	if len(c.B) > 4 {
		return nil, sszutils.ErrListTooBig
	}
	return append(buf, c.B...), nil
}
func (c *noDynStreamSpecCustom) UnmarshalSSZ(buf []byte) error {
	if len(buf) > 4 {
		return sszutils.ErrListTooBig
	}
	c.B = append([]byte{}, buf...)
	return nil
}
func (c *noDynStreamSpecCustom) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	if len(c.B) > 4 {
		return root, sszutils.ErrListTooBig
	}
	copy(root[:], c.B)
	return root, nil
}
func (c *noDynStreamSpecCustom) limit(ds sszutils.DynamicSpecs) (int, error) {
	limit, err := sszutils.ResolveSpecValueWithDefault(ds, "NODYN_CUSTOM_MAX", 4)
	return sszutils.CapToInt(limit), err
}
func (c *noDynStreamSpecCustom) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return len(c.B) }
func (c *noDynStreamSpecCustom) MarshalSSZEncoder(ds sszutils.DynamicSpecs, enc sszutils.Encoder) error {
	limit, err := c.limit(ds)
	if err != nil {
		return err
	}
	if len(c.B) > limit {
		return sszutils.ErrListTooBig
	}
	enc.EncodeBytes(c.B)
	return nil
}
func (c *noDynStreamSpecCustom) UnmarshalSSZDecoder(ds sszutils.DynamicSpecs, dec sszutils.Decoder) error {
	limit, err := c.limit(ds)
	if err != nil {
		return err
	}
	buf, err := dec.DecodeRemaining(limit)
	if err != nil {
		return err
	}
	c.B = append([]byte{}, buf...)
	return nil
}
func (c *noDynStreamSpecCustom) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutBytes(c.B)
	return nil
}

// NoDynStreamSpecCustomHolder holds the custom type as a variable-size value
// next to a second one. The custom type carries spec-aware methods, so it
// counts as depending on the spec: the holder's static methods, which reach
// it through its static ones, do not answer for an instance. The holder's
// stream methods carry the spec set and reach it through its spec-aware ones.
type NoDynStreamSpecCustomHolder struct {
	C noDynStreamSpecCustom `ssz-type:"custom"`
	B []byte                `ssz-max:"4"`
}

var (
	NoDynStreamSpecCustomHolder_Payload = NoDynStreamSpecCustomHolder{C: noDynStreamSpecCustom{B: []byte{1, 2, 3}}, B: []byte{9}}
	// NoDynStreamSpecCustomHolder_SpecPayload is valid where the spec resolves
	// the custom type's limit to 8.
	NoDynStreamSpecCustomHolder_SpecPayload = NoDynStreamSpecCustomHolder{C: noDynStreamSpecCustom{B: []byte{1, 2, 3, 4, 5, 6}}, B: []byte{9}}
)

// NoDynStreamSpecChild carries a spec-sized field. Generated in the static
// streaming batch, it has a static sizer that baked the tag value and a
// streaming encoder that resolves the spec.
type NoDynStreamSpecChild struct {
	V []byte   `ssz-size:"8" dynssz-size:"NODYN_STREAM_WIDTH"`
	L []uint16 `ssz-max:"6"`
}

// NoDynStreamSpecParent needs the size of every child ahead of writing it on a
// stream that cannot seek, so its streaming encoder sizes the children first.
// That size has to be the one the child's streaming encoder then writes.
type NoDynStreamSpecParent struct {
	A []*NoDynStreamSpecChild `ssz-max:"3"`
	B []byte                  `ssz-max:"4"`
}

var (
	NoDynStreamSpecParent_Payload = NoDynStreamSpecParent{
		A: []*NoDynStreamSpecChild{
			{V: []byte{1, 2, 3, 4, 5, 6, 7, 8}, L: []uint16{7}},
			{V: []byte{8, 7, 6, 5, 4, 3, 2, 1}, L: []uint16{}},
		},
		B: []byte{9},
	}
	// NoDynStreamSpecParent_SpecPayload is valid where the spec resolves the
	// width to 3.
	NoDynStreamSpecParent_SpecPayload = NoDynStreamSpecParent{
		A: []*NoDynStreamSpecChild{
			{V: []byte{1, 2, 3}, L: []uint16{7}},
			{V: []byte{4, 5, 6}, L: []uint16{}},
		},
		B: []byte{9},
	}
)

// NoDynNestChild is a variable-size container nested by the NoDynNest* parents.
// Generated with -with-streaming -without-fastssz -without-dynamic-expressions,
// its parents must reach it through its static MarshalSSZTo/UnmarshalSSZ/SizeSSZ/
// HashTreeRootWith methods — never the *Dyn buffer variants and never by wrapping
// the streaming encoder into the static buffer path.
type NoDynNestChild struct {
	A []byte `ssz-max:"8"`
	B uint8
}

// NoDynNestProg nests the child as a progressive-list.
type NoDynNestProg struct {
	L []NoDynNestChild `ssz-type:"progressive-list" ssz-max:"100"`
}

// NoDynNestList nests the child as a bounded list.
type NoDynNestList struct {
	L []NoDynNestChild `ssz-max:"100"`
}

// NoDynNestVec nests the child as a fixed vector.
type NoDynNestVec struct {
	V [3]NoDynNestChild
}

// NoDynNestField nests the child as a plain container field.
type NoDynNestField struct {
	C NoDynNestChild
	N uint16
}

var (
	NoDynNestProg_Payload = NoDynNestProg{L: []NoDynNestChild{
		{A: []byte{1, 2, 3}, B: 7},
		{A: nil, B: 0},
		{A: []byte{9}, B: 255},
	}}
	NoDynNestList_Payload = NoDynNestList{L: []NoDynNestChild{
		{A: []byte{4, 5}, B: 1},
		{A: []byte{6, 7, 8}, B: 2},
	}}
	NoDynNestVec_Payload = NoDynNestVec{V: [3]NoDynNestChild{
		{A: []byte{1}, B: 10},
		{A: []byte{2, 2}, B: 20},
		{A: nil, B: 30},
	}}
	NoDynNestField_Payload = NoDynNestField{
		C: NoDynNestChild{A: []byte{3, 3, 3}, B: 42},
		N: 1234,
	}
)

// InterpretedAnnotatedList tests Annotate with an interpreted (double-quoted) string literal.
type InterpretedAnnotatedList []uint32

var _ = sszutils.Annotate[InterpretedAnnotatedList]("ssz-max:\"12\"")

// ViewTypes2_Base tests nested view dispatch: its Child field has
// view dispatch methods (from ViewTypes1_Base). When generating
// ViewTypes2's views, the Child field triggers the isView code path
// in all generators (marshal, unmarshal, encoder, decoder, size, hash).
type ViewTypes2_Base struct {
	F1    uint64
	Child *ViewTypes1_Base
}

// ViewTypes2_View1 is a view where Child is viewed through ViewTypes1_View1.
type ViewTypes2_View1 struct {
	F1    uint64
	Child *ViewTypes1_View1
}

// ViewTypes2_View2 is a view where Child is viewed through ViewTypes1_View2.
type ViewTypes2_View2 struct {
	F1    uint64
	Child *ViewTypes1_View2
}

var ViewTypes2_Payload = ViewTypes2_Base{
	F1: 42,
	Child: &ViewTypes1_Base{
		F1: 12345,
		F2: []uint64{12345, 67890},
		F3: [2][]uint64{{12345, 67890}, {12345, 67890}},
		C1: &ViewTypes1_C1{
			F1: 12345,
			F2: []uint64{12345, 67890},
		},
	},
}

// ViewTypes5_Base carries no SSZ tags at all: its layout lives entirely in the
// view schema, which is how a view's data type is normally written (the
// consensus spec fixtures are shaped this way). Its lists therefore look
// limit-less, but that is not a missing limit -- the view supplies it -- so
// analyzing and generating for the type must not require extended types. Only
// hashing the data type directly, outside any view, has no definition.
type ViewTypes5_Base struct {
	F1 uint64
	F2 []uint64
	C1 *ViewTypes5_Base_C1
}

type ViewTypes5_Base_C1 struct {
	F1 []uint64
}

// ViewTypes5_View1 supplies the limits its data type omits.
type ViewTypes5_View1 struct {
	F1 uint64
	F2 []uint64 `ssz-max:"64"`
	C1 *ViewTypes5_View1_C1
}

type ViewTypes5_View1_C1 struct {
	F1 []uint64 `ssz-max:"32"`
}

var ViewTypes5_Payload = ViewTypes5_Base{
	F1: 7,
	F2: []uint64{1, 2, 3},
	C1: &ViewTypes5_Base_C1{F1: []uint64{4, 5}},
}

// ViewTypes3_Base tests the view-only generation mode.
// It only generates view dispatch methods, no data methods.
type ViewTypes3_Base struct {
	F1 uint64
	F2 []uint64 `ssz-max:"64"`
}

// ViewTypes3_View1 is a view for ViewTypes3_Base.
type ViewTypes3_View1 struct {
	F1 uint64
}

var ViewTypes3_Payload = ViewTypes3_Base{
	F1: 42,
	F2: []uint64{1, 2, 3},
}

// CoverageTypes3 covers: uint256 type (both [32]byte and [4]uint64 forms),
// pointer bitlist, and string vector with dynssz-size.
type CoverageTypes3 struct {
	U256_1    [32]byte  `ssz-type:"uint256"`
	U256_2    [4]uint64 `ssz-type:"uint256"`
	StrVec    string    `ssz-size:"10" dynssz-size:"STR_VEC_SIZE"`
	PtrBool   *bool
	PtrStrVec *string `ssz-size:"8"`
	PtrStrLst *string `ssz-max:"16"`
}

var (
	covBool = true
	covStr1 = "teststr1"
	covStr2 = "hello"
)

var CoverageTypes3_Payload = CoverageTypes3{
	U256_1:    [32]byte{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32},
	U256_2:    [4]uint64{1, 2, 3, 4},
	StrVec:    "helloworld",
	PtrBool:   &covBool,
	PtrStrVec: &covStr1,
	PtrStrLst: &covStr2,
}

var CoverageTypes3_Specs = map[string]any{
	"STR_VEC_SIZE": 12,
}

// EncoderOnlyType implements only dynamic encoder/decoder/sizer/hashroot
// interfaces (not FastSSZ or DynamicMarshaler/Unmarshaler). This exercises
// the DynamicEncoder/DynamicDecoder dispatch branches in codegen.
type EncoderOnlyType struct {
	Val uint64
}

var _ sszutils.DynamicEncoder = (*EncoderOnlyType)(nil)
var _ sszutils.DynamicDecoder = (*EncoderOnlyType)(nil)
var _ sszutils.DynamicSizer = (*EncoderOnlyType)(nil)
var _ sszutils.DynamicHashRoot = (*EncoderOnlyType)(nil)

func (e *EncoderOnlyType) MarshalSSZEncoder(ds sszutils.DynamicSpecs, enc sszutils.Encoder) error {
	enc.EncodeUint64(e.Val)
	return nil
}

func (e *EncoderOnlyType) UnmarshalSSZDecoder(_ sszutils.DynamicSpecs, dec sszutils.Decoder) error {
	var err error
	e.Val, err = dec.DecodeUint64()
	return err
}

func (e *EncoderOnlyType) SizeSSZDyn(_ sszutils.DynamicSpecs) int {
	return 8
}

func (e *EncoderOnlyType) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint64(e.Val)
	return nil
}

// CoverageTypes5 wraps EncoderOnlyType as a field to trigger the
// DynamicEncoder/DynamicDecoder dispatch branches in all generators.
type CoverageTypes5 struct {
	F1 uint64
	E1 EncoderOnlyType
}

var CoverageTypes5_Payload = CoverageTypes5{
	F1: 42,
	E1: EncoderOnlyType{Val: 12345},
}

// MarshalerOnlyType implements only DynamicMarshaler/Unmarshaler (not FastSSZ).
// This exercises the DynamicMarshaler/DynamicUnmarshaler dispatch branches.
type MarshalerOnlyType struct {
	Val uint64
}

var _ sszutils.DynamicMarshaler = (*MarshalerOnlyType)(nil)
var _ sszutils.DynamicUnmarshaler = (*MarshalerOnlyType)(nil)
var _ sszutils.DynamicSizer = (*MarshalerOnlyType)(nil)
var _ sszutils.DynamicHashRoot = (*MarshalerOnlyType)(nil)

func (m *MarshalerOnlyType) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return sszutils.MarshalUint64(buf, m.Val), nil
}

func (m *MarshalerOnlyType) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	m.Val = sszutils.UnmarshallUint64(buf)
	return nil
}

func (m *MarshalerOnlyType) SizeSSZDyn(_ sszutils.DynamicSpecs) int {
	return 8
}

func (m *MarshalerOnlyType) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint64(m.Val)
	return nil
}

// SizerOnlyType implements DynamicSizer but no marshaler or encoder. A
// defined sizer is consulted even though the bytes come from the inlined
// walk; the sizer is correct and counts its calls.
type SizerOnlyType struct {
	A     uint64
	B     []byte `ssz-max:"8"`
	Calls int    `ssz-type:"-"`
}

var _ sszutils.DynamicSizer = (*SizerOnlyType)(nil)

func (s *SizerOnlyType) SizeSSZDyn(_ sszutils.DynamicSpecs) int {
	s.Calls++
	return 8 + 4 + len(s.B)
}

// SizerOnlyHolder nests SizerOnlyType so the generated sizer meets a child
// with a sizer but no marshaler.
type SizerOnlyHolder struct {
	S SizerOnlyType
	T uint32
}

var SizerOnlyHolder_Payload = SizerOnlyHolder{
	S: SizerOnlyType{A: 7, B: []byte{1, 2, 3}},
	T: 9,
}

// BasicWithMethods is a named uint64 that carries the dynamic and the fastssz
// method sets; its hash methods put the value.
type BasicWithMethods uint64

var _ sszutils.DynamicMarshaler = (*BasicWithMethods)(nil)
var _ sszutils.DynamicUnmarshaler = (*BasicWithMethods)(nil)
var _ sszutils.DynamicSizer = (*BasicWithMethods)(nil)
var _ sszutils.DynamicHashRoot = (*BasicWithMethods)(nil)

func (b *BasicWithMethods) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return b.MarshalSSZTo(buf)
}

func (b *BasicWithMethods) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	return b.UnmarshalSSZ(buf)
}

func (b *BasicWithMethods) SizeSSZDyn(_ sszutils.DynamicSpecs) int {
	return 8
}

func (b *BasicWithMethods) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint64(uint64(*b))
	return nil
}

func (b *BasicWithMethods) MarshalSSZ() ([]byte, error) {
	return b.MarshalSSZTo(nil)
}

func (b *BasicWithMethods) MarshalSSZTo(buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint64(buf, uint64(*b)), nil
}

func (b *BasicWithMethods) SizeSSZ() int {
	return 8
}

func (b *BasicWithMethods) UnmarshalSSZ(buf []byte) error {
	if len(buf) != 8 {
		return sszutils.ErrUnexpectedEOF
	}
	*b = BasicWithMethods(binary.LittleEndian.Uint64(buf))
	return nil
}

func (b *BasicWithMethods) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	binary.LittleEndian.PutUint64(root[:], uint64(*b))
	return root, nil
}

// BasicByteWithMethods is the uint8 counterpart: 32 values share one chunk.
type BasicByteWithMethods uint8

var _ sszutils.DynamicMarshaler = (*BasicByteWithMethods)(nil)
var _ sszutils.DynamicUnmarshaler = (*BasicByteWithMethods)(nil)
var _ sszutils.DynamicSizer = (*BasicByteWithMethods)(nil)
var _ sszutils.DynamicHashRoot = (*BasicByteWithMethods)(nil)

func (b *BasicByteWithMethods) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return append(buf, byte(*b)), nil
}

func (b *BasicByteWithMethods) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	if len(buf) != 1 {
		return sszutils.ErrUnexpectedEOF
	}
	*b = BasicByteWithMethods(buf[0])
	return nil
}

func (b *BasicByteWithMethods) SizeSSZDyn(_ sszutils.DynamicSpecs) int {
	return 1
}

func (b *BasicByteWithMethods) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint8(uint8(*b))
	return nil
}

// PackedCustom is a struct-backed uint16 with custom SSZ methods. Its hash
// method appends only the packed two bytes: as a field the engines pad it to a
// leaf, inside a list or vector they pack it with its neighbours.
type PackedCustom struct{ V uint16 }

func (p *PackedCustom) MarshalSSZ() ([]byte, error) {
	return p.MarshalSSZTo(nil)
}

func (p *PackedCustom) MarshalSSZTo(buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint16(buf, p.V), nil
}

func (p *PackedCustom) SizeSSZ() int { return 2 }

func (p *PackedCustom) UnmarshalSSZ(buf []byte) error {
	if len(buf) != 2 {
		return sszutils.ErrUnexpectedEOF
	}
	p.V = binary.LittleEndian.Uint16(buf)
	return nil
}

func (p *PackedCustom) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	binary.LittleEndian.PutUint16(root[:], p.V)
	return root, nil
}

func (p *PackedCustom) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.AppendUint16(p.V)
	return nil
}

// OddCustom is a 3-byte custom type whose hash method appends only its bytes.
// No basic type has that size, so inside a list each value is padded to a leaf
// of its own, like a Vector[byte, 3] element.
type OddCustom struct{ B [3]byte }

func (o *OddCustom) MarshalSSZ() ([]byte, error) {
	return o.MarshalSSZTo(nil)
}

func (o *OddCustom) MarshalSSZTo(buf []byte) ([]byte, error) {
	return append(buf, o.B[:]...), nil
}

func (o *OddCustom) SizeSSZ() int { return 3 }

func (o *OddCustom) UnmarshalSSZ(buf []byte) error {
	if len(buf) != 3 {
		return sszutils.ErrUnexpectedEOF
	}
	copy(o.B[:], buf)
	return nil
}

func (o *OddCustom) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	copy(root[:], o.B[:])
	return root, nil
}

func (o *OddCustom) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.Append(o.B[:])
	return nil
}

// PackedCustomHolder places the append-only custom types as a field, in a
// list and in a vector; PackedCustomPlain is the twin built from the types
// they stand for.
type PackedCustomHolder struct {
	A PackedCustom    `ssz-type:"custom" ssz-size:"2"`
	L []PackedCustom  `ssz-type:"?,custom" ssz-size:"?,2" ssz-max:"8"`
	V [4]PackedCustom `ssz-type:"?,custom" ssz-size:"4,2"`
	O []OddCustom     `ssz-type:"?,custom" ssz-size:"?,3" ssz-max:"8"`
}

type PackedCustomPlain struct {
	A uint16
	L []uint16 `ssz-max:"8"`
	V [4]uint16
	O [][3]byte `ssz-max:"8"`
}

var PackedCustomHolder_Payload = PackedCustomHolder{
	A: PackedCustom{V: 0x1234},
	L: []PackedCustom{{V: 1}, {V: 2}, {V: 3}},
	V: [4]PackedCustom{{V: 4}, {V: 5}, {V: 6}, {V: 7}},
	O: []OddCustom{{B: [3]byte{8, 9, 10}}, {B: [3]byte{11, 12, 13}}},
}

var PackedCustomPlain_Payload = PackedCustomPlain{
	A: 0x1234,
	L: []uint16{1, 2, 3},
	V: [4]uint16{4, 5, 6, 7},
	O: [][3]byte{{8, 9, 10}, {11, 12, 13}},
}

// BulkElems holds byte-array elements whose Go width differs from the encoded
// width, or that carry padding bits, next to one that is laid out exactly as
// encoded: only the last may be copied in bulk.
type BulkElems struct {
	A [][48]byte `ssz-size:"?,32" ssz-max:"8"`
	B [][48]byte `ssz-size:"?,48" dynssz-size:"?,BULK_LEN" ssz-max:"8"`
	C [][2]byte  `ssz-type:"?,bitvector" ssz-bitsize:"?,12" ssz-max:"8"`
	D [][32]byte `ssz-max:"8"`
}

var BulkElems_Specs = map[string]any{
	"BULK_LEN": uint64(32),
}

var BulkElems_Payload = func() BulkElems {
	var v BulkElems
	for i := range 3 {
		var a, b [48]byte
		for j := range a {
			a[j] = byte(i*48 + j)
			b[j] = byte(255 - i*48 - j)
		}
		var d [32]byte
		for j := range d {
			d[j] = byte(i + j)
		}
		v.A = append(v.A, a)
		v.B = append(v.B, b)
		v.C = append(v.C, [2]byte{0xff, 0x0f})
		v.D = append(v.D, d)
	}
	return v
}()

// NamedBit is a named uint8 used as a bitlist element: the engines view the
// slice as bytes without copying.
type NamedBit uint8

// NamedBitlists backs plain and progressive bitlists with a named uint8
// element; NamedBitlistsPlain is the []byte twin.
type NamedBitlists struct {
	B []NamedBit `ssz-type:"bitlist" ssz-max:"16"`
	P []NamedBit `ssz-type:"progressive-bitlist"`
	E []NamedBit `ssz-type:"bitlist" ssz-max:"16"`
}

type NamedBitlistsPlain struct {
	B []byte `ssz-type:"bitlist" ssz-max:"16"`
	P []byte `ssz-type:"progressive-bitlist"`
	E []byte `ssz-type:"bitlist" ssz-max:"16"`
}

var NamedBitlists_Payload = NamedBitlists{
	B: []NamedBit{0xa5, 0x01},
	P: []NamedBit{0x0f, 0xf0, 0x81},
}

var NamedBitlistsPlain_Payload = NamedBitlistsPlain{
	B: []byte{0xa5, 0x01},
	P: []byte{0x0f, 0xf0, 0x81},
}

// foreignHasher stands for a third-party hasher type.
type foreignHasher struct{ N int }

// ForeignHashWith carries the fastssz method set with a HashTreeRootWith that
// takes a concrete foreign hasher: that method cannot be called with the
// engines' hash walker, so both fall back to HashTreeRoot().
type ForeignHashWith struct{ A uint64 }

func (f *ForeignHashWith) MarshalSSZ() ([]byte, error) {
	return f.MarshalSSZTo(nil)
}

func (f *ForeignHashWith) MarshalSSZTo(buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint64(buf, f.A), nil
}

func (f *ForeignHashWith) SizeSSZ() int { return 8 }

func (f *ForeignHashWith) UnmarshalSSZ(buf []byte) error {
	if len(buf) != 8 {
		return sszutils.ErrUnexpectedEOF
	}
	f.A = binary.LittleEndian.Uint64(buf)
	return nil
}

// HashTreeRoot is the root of a container with one uint64 field: its single
// leaf.
func (f *ForeignHashWith) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	binary.LittleEndian.PutUint64(root[:], f.A)
	return root, nil
}

func (f *ForeignHashWith) HashTreeRootWith(h *foreignHasher) error {
	h.N++
	return nil
}

type ForeignHashWithHolder struct {
	F ForeignHashWith
	Y uint8
}

var ForeignHashWithHolder_Payload = ForeignHashWithHolder{F: ForeignHashWith{A: 0x0102030405060708}, Y: 9}

// FastsszTagged uses the plain fastssz `ssz` tag; both engines read it as
// ssz-type, so the bitlist is a bitlist and the excluded field is skipped.
type FastsszTagged struct {
	Bits   []byte `ssz:"bitlist" ssz-max:"16"`
	Skip   uint64 `ssz:"-"`
	Filler uint8
}

// FastsszTaggedPlain is the dynamic-ssz spelling of the same type.
type FastsszTaggedPlain struct {
	Bits   []byte `ssz-type:"bitlist" ssz-max:"16"`
	Skip   uint64 `ssz-type:"-"`
	Filler uint8
}

var FastsszTagged_Payload = FastsszTagged{Bits: []byte{0xa5, 0x01}, Skip: 99, Filler: 7}

var FastsszTaggedPlain_Payload = FastsszTaggedPlain{Bits: []byte{0xa5, 0x01}, Skip: 99, Filler: 7}

// AliasAnnotated is annotated through an alias of itself: the annotation
// belongs to the named type in both engines, so both fields of the holder are
// lists of at most six elements.
type AliasAnnotated []uint64

type AliasAnnotatedAlias = AliasAnnotated

var _ = sszutils.Annotate[AliasAnnotatedAlias](`ssz-max:"6"`)

type AliasAnnotatedHolder struct {
	B AliasAnnotated
	C AliasAnnotatedAlias
}

var AliasAnnotatedHolder_Payload = AliasAnnotatedHolder{B: AliasAnnotated{1, 2, 3}, C: AliasAnnotatedAlias{4, 5}}

// SurplusTags names more tag dimensions than its fields have; the surplus is
// dropped by both engines and the remaining limits are enforced.
type SurplusTags struct {
	F SimpleTypes1_C1 `ssz-max:"10"`
	G []uint64        `ssz-type:"list,uint64,uint32" ssz-max:"8"`
	H []uint64        `ssz-max:"64,128"`
}

var SurplusTags_Payload = SurplusTags{F: SimpleTypes1_C1{F1: 1}, G: []uint64{1, 2, 3}, H: []uint64{4, 5}}

// ElemBitvectors stores bit-sized bitvectors element-wise: pointer elements, a
// named uint8 slice and the plain byte twin. The padding bits of the last
// element are checked on every path, as for the byte-backed form.
type ElemBitvectors struct {
	P [2]*byte   `ssz-type:"bitvector" ssz-bitsize:"12"`
	N []NamedBit `ssz-type:"bitvector" ssz-bitsize:"12"`
	Q []*byte    `ssz-type:"bitvector" ssz-bitsize:"12"`
	S []*byte    `ssz-type:"bitvector" ssz-bitsize:"12" dynssz-bitsize:"ELEM_BITS"`
	B [2]byte    `ssz-type:"bitvector" ssz-bitsize:"12"`
	Z uint8
}

var ElemBitvectors_Specs = map[string]any{
	"ELEM_BITS": uint64(12),
}

var ElemBitvectors_Payload = func() ElemBitvectors {
	a, b := byte(0xff), byte(0x0f)
	c, d := byte(0xa5), byte(0x05)
	e, f := byte(0x11), byte(0x01)
	return ElemBitvectors{
		P: [2]*byte{&a, &b},
		N: []NamedBit{0x3c, 0x0c},
		Q: []*byte{&c, &d},
		S: []*byte{&e, &f},
		B: [2]byte{0x81, 0x08},
		Z: 9,
	}
}()

// BasicMethodsHolder places the method-carrying basic types where the engines
// pack them: a list, a vector and a byte-sized list.
type BasicMethodsHolder struct {
	L []BasicWithMethods `ssz-max:"8"`
	V [4]BasicWithMethods
	B []BasicByteWithMethods `ssz-max:"64"`
}

// BasicMethodsPlain is the twin built from plain basic types; it must produce
// the same bytes and root as BasicMethodsHolder.
type BasicMethodsPlain struct {
	L []uint64 `ssz-max:"8"`
	V [4]uint64
	B []uint8 `ssz-max:"64"`
}

var BasicMethodsHolder_Payload = BasicMethodsHolder{
	L: []BasicWithMethods{1, 2, 3},
	V: [4]BasicWithMethods{4, 5, 6, 7},
	B: []BasicByteWithMethods{8, 9, 10},
}

var BasicMethodsPlain_Payload = BasicMethodsPlain{
	L: []uint64{1, 2, 3},
	V: [4]uint64{4, 5, 6, 7},
	B: []uint8{8, 9, 10},
}

// WrappedWithMethods is a type wrapper around a uint64 with hand-written hash
// methods that put the wrapped value.
type WrappedWithMethods struct {
	Data uint64
}

var _ = sszutils.Annotate[WrappedWithMethods](`ssz-type:"wrapper"`)

var _ sszutils.DynamicHashRoot = (*WrappedWithMethods)(nil)

func (w *WrappedWithMethods) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint64(w.Data)
	return nil
}

func (w *WrappedWithMethods) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	binary.LittleEndian.PutUint64(root[:], w.Data)
	return root, nil
}

// WrappedGenerated is the same shape with generated methods.
type WrappedGenerated struct {
	Data uint64
}

var _ = sszutils.Annotate[WrappedGenerated](`ssz-type:"wrapper"`)

// WrappedMethodsHolder places both wrapper types in a list and a vector, and
// WrappedGenerated as a field.
type WrappedMethodsHolder struct {
	L  []WrappedWithMethods  `ssz-max:"8" ssz-type:"?,wrapper"`
	V  [4]WrappedWithMethods `ssz-type:"?,wrapper"`
	GL []WrappedGenerated    `ssz-max:"8" ssz-type:"?,wrapper"`
	GV [4]WrappedGenerated   `ssz-type:"?,wrapper"`
	F  WrappedGenerated      `ssz-type:"wrapper"`
}

// WrappedMethodsPlain is the twin with the wrappers removed; it must produce
// the same bytes and root as WrappedMethodsHolder.
type WrappedMethodsPlain struct {
	L  []uint64 `ssz-max:"8"`
	V  [4]uint64
	GL []uint64 `ssz-max:"8"`
	GV [4]uint64
	F  uint64
}

var WrappedMethodsHolder_Payload = WrappedMethodsHolder{
	L:  []WrappedWithMethods{{1}, {2}, {3}, {4}, {5}},
	V:  [4]WrappedWithMethods{{6}, {7}, {8}, {9}},
	GL: []WrappedGenerated{{10}, {11}, {12}, {13}, {14}},
	GV: [4]WrappedGenerated{{15}, {16}, {17}, {18}},
	F:  WrappedGenerated{19},
}

var WrappedMethodsPlain_Payload = WrappedMethodsPlain{
	L:  []uint64{1, 2, 3, 4, 5},
	V:  [4]uint64{6, 7, 8, 9},
	GL: []uint64{10, 11, 12, 13, 14},
	GV: [4]uint64{15, 16, 17, 18},
	F:  19,
}

// BasicSizedCustom is a custom type of a basic size (8 bytes) with the fastssz
// method set; its walker method puts the value and its root is the padded
// value.
type BasicSizedCustom uint64

func (c *BasicSizedCustom) MarshalSSZ() ([]byte, error) {
	return c.MarshalSSZTo(nil)
}

func (c *BasicSizedCustom) MarshalSSZTo(buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint64(buf, uint64(*c)), nil
}

func (c *BasicSizedCustom) SizeSSZ() int { return 8 }

func (c *BasicSizedCustom) UnmarshalSSZ(buf []byte) error {
	if len(buf) != 8 {
		return sszutils.ErrUnexpectedEOF
	}
	*c = BasicSizedCustom(binary.LittleEndian.Uint64(buf))
	return nil
}

func (c *BasicSizedCustom) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	binary.LittleEndian.PutUint64(root[:], uint64(*c))
	return root, nil
}

func (c *BasicSizedCustom) HashTreeRootWith(hh sszutils.HashWalker) error {
	hh.PutUint64(uint64(*c))
	return nil
}

// RootOnlyCustom is a custom type of a basic size (2 bytes) whose only hash
// method returns its root, the padded value.
type RootOnlyCustom struct{ V uint16 }

func (c *RootOnlyCustom) MarshalSSZ() ([]byte, error) {
	return c.MarshalSSZTo(nil)
}

func (c *RootOnlyCustom) MarshalSSZTo(buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint16(buf, c.V), nil
}

func (c *RootOnlyCustom) SizeSSZ() int { return 2 }

func (c *RootOnlyCustom) UnmarshalSSZ(buf []byte) error {
	if len(buf) != 2 {
		return sszutils.ErrUnexpectedEOF
	}
	c.V = binary.LittleEndian.Uint16(buf)
	return nil
}

func (c *RootOnlyCustom) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	binary.LittleEndian.PutUint16(root[:], c.V)
	return root, nil
}

// BasicSizedCustomHolder places the basic-sized custom types in lists and
// vectors.
type BasicSizedCustomHolder struct {
	L  []BasicSizedCustom  `ssz-type:"?,custom" ssz-size:"?,8" ssz-max:"4"`
	V  [4]BasicSizedCustom `ssz-type:"?,custom" ssz-size:"4,8"`
	R  []RootOnlyCustom    `ssz-type:"?,custom" ssz-size:"?,2" ssz-max:"8"`
	RV [4]RootOnlyCustom   `ssz-type:"?,custom" ssz-size:"4,2"`
}

// BasicSizedCustomPlain is the twin built from the basic types the custom
// types stand in for; it must produce the same bytes and root.
type BasicSizedCustomPlain struct {
	L  []uint64 `ssz-max:"4"`
	V  [4]uint64
	R  []uint16 `ssz-max:"8"`
	RV [4]uint16
}

var BasicSizedCustomHolder_Payload = BasicSizedCustomHolder{
	L:  []BasicSizedCustom{1, 2, 3},
	V:  [4]BasicSizedCustom{4, 5, 6, 7},
	R:  []RootOnlyCustom{{8}, {9}, {10}},
	RV: [4]RootOnlyCustom{{11}, {12}, {13}, {14}},
}

var BasicSizedCustomPlain_Payload = BasicSizedCustomPlain{
	L:  []uint64{1, 2, 3},
	V:  [4]uint64{4, 5, 6, 7},
	R:  []uint16{8, 9, 10},
	RV: [4]uint16{11, 12, 13, 14},
}

// LeafCustom is a custom type of a basic size (8 bytes) whose walker method
// merkleizes a leaf of its own.
type LeafCustom struct{ V uint64 }

func (c *LeafCustom) MarshalSSZ() ([]byte, error) {
	return c.MarshalSSZTo(nil)
}

func (c *LeafCustom) MarshalSSZTo(buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint64(buf, c.V), nil
}

func (c *LeafCustom) SizeSSZ() int { return 8 }

func (c *LeafCustom) UnmarshalSSZ(buf []byte) error {
	if len(buf) != 8 {
		return sszutils.ErrUnexpectedEOF
	}
	c.V = binary.LittleEndian.Uint64(buf)
	return nil
}

func (c *LeafCustom) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	binary.LittleEndian.PutUint64(root[:], c.V)
	return root, nil
}

func (c *LeafCustom) HashTreeRootWith(hh sszutils.HashWalker) error {
	idx := hh.StartTree(sszutils.TreeTypeNone)
	hh.PutUint64(c.V)
	hh.Merkleize(idx)
	return nil
}

// LeafCustomHolder lists LeafCustom under a packed limit.
type LeafCustomHolder struct {
	L []LeafCustom `ssz-type:"?,custom" ssz-size:"?,8" ssz-max:"4"`
}

var LeafCustomHolder_Payload = LeafCustomHolder{L: []LeafCustom{{1}, {2}, {3}}}

// ViewNum is a basic type whose view hash method puts the value through a
// uint16 view.
type ViewNum uint16

func (v *ViewNum) HashTreeRootWithDynView(view any) func(sszutils.DynamicSpecs, sszutils.HashWalker) error {
	if _, ok := view.(*uint16); !ok {
		return nil
	}
	return func(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
		hh.PutUint16(uint16(*v))
		return nil
	}
}

// LeafViewNum is a basic type whose view hash method merkleizes a leaf of its
// own.
type LeafViewNum uint16

func (v *LeafViewNum) HashTreeRootWithDynView(view any) func(sszutils.DynamicSpecs, sszutils.HashWalker) error {
	if _, ok := view.(*uint16); !ok {
		return nil
	}
	return func(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
		idx := hh.StartTree(sszutils.TreeTypeNone)
		hh.PutUint16(uint16(*v))
		hh.Merkleize(idx)
		return nil
	}
}

// ViewNumTypes_Base holds the basic-typed views; its layout lives in the view.
type ViewNumTypes_Base struct {
	V []ViewNum
	F ViewNum
}

// ViewNumTypes_View1 is the schema: a packed list and a field of uint16.
type ViewNumTypes_View1 struct {
	V []uint16 `ssz-max:"4"`
	F uint16
}

// ViewNumTypes_Plain is the twin built from plain uint16 values.
type ViewNumTypes_Plain struct {
	V []uint16 `ssz-max:"4"`
	F uint16
}

var ViewNumTypes_Payload = ViewNumTypes_Base{V: []ViewNum{1, 2, 3}, F: 4}

var ViewNumTypes_Plain_Payload = ViewNumTypes_Plain{V: []uint16{1, 2, 3}, F: 4}

// ViewLeafTypes_Base lists LeafViewNum under a packed limit.
type ViewLeafTypes_Base struct {
	L []LeafViewNum
}

// ViewLeafTypes_View1 is its schema.
type ViewLeafTypes_View1 struct {
	L []uint16 `ssz-max:"4"`
}

var ViewLeafTypes_Payload = ViewLeafTypes_Base{L: []LeafViewNum{1, 2, 3}}

// BitCfg has a bit-sized vector whose bit count comes from a spec value with
// no static bit size; the array's own length is the fallback.
type BitCfg struct {
	Flags [4]byte `ssz-type:"bitvector" dynssz-bitsize:"FLAG_BITS"`
	Num   uint64
}

// BitCfgDyn adds a trailing dynamic field so the offsets depend on the
// resolved width.
type BitCfgDyn struct {
	Flags [4]byte `ssz-type:"bitvector" dynssz-bitsize:"FLAG_BITS"`
	Num   uint64
	List  []uint64 `ssz-max:"16"`
}

var BitCfg_Payload = BitCfg{Flags: [4]byte{0x01, 0x02, 0x03, 0x04}, Num: 7}

var BitCfgDyn_Payload = BitCfgDyn{Flags: [4]byte{0x01, 0x02, 0x03, 0x04}, Num: 7, List: []uint64{1, 2}}

// HandRecursiveChild is a recursive type with hand-written spec-aware
// methods, which walk the value by reflection with delegation off.
type HandRecursiveChild struct {
	Value    uint64
	Children []*HandRecursiveChild `ssz-max:"4"`
}

var handRecursiveDs = dynssz.NewDynSsz(nil, dynssz.WithNoDelegation(), dynssz.WithNoFastSsz())

func (c *HandRecursiveChild) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return handRecursiveDs.MarshalSSZTo(c, buf)
}

func (c *HandRecursiveChild) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	return handRecursiveDs.UnmarshalSSZ(c, buf)
}

func (c *HandRecursiveChild) SizeSSZDyn(_ sszutils.DynamicSpecs) int {
	size, err := handRecursiveDs.SizeSSZ(c)
	if err != nil {
		return 0
	}
	return size
}

func (c *HandRecursiveChild) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	return handRecursiveDs.HashTreeRootWith(c, hh)
}

// HandRecursiveHolder is generated and nests the hand-written recursive type
// as a field and as list elements.
type HandRecursiveHolder struct {
	C HandRecursiveChild
	L []HandRecursiveChild `ssz-max:"2"`
}

var HandRecursiveHolder_Payload = HandRecursiveHolder{
	C: HandRecursiveChild{Value: 1, Children: []*HandRecursiveChild{{Value: 2, Children: []*HandRecursiveChild{{Value: 3}}}}},
	L: []HandRecursiveChild{{Value: 4}, {Value: 5, Children: []*HandRecursiveChild{{Value: 6}}}},
}

// OnlyWith is a container whose only hash method is HashTreeRootWith; it
// hashes its value masked so delegation shows in the root.
type OnlyWith struct{ Data uint64 }

func (o *OnlyWith) HashTreeRootWith(hh sszutils.HashWalker) error {
	idx := hh.StartTree(sszutils.TreeTypeNone)
	hh.PutUint64(o.Data ^ 0xffff)
	hh.Merkleize(idx)
	return nil
}

// OnlyWithNum is a uint64 whose only hash method is HashTreeRootWith.
type OnlyWithNum uint64

func (o *OnlyWithNum) HashTreeRootWith(hh sszutils.HashWalker) error {
	hh.PutUint64(uint64(*o) ^ 0xffff)
	return nil
}

// OnlyWithHolder places both as a field, a composite list and a packed list.
type OnlyWithHolder struct {
	F OnlyWith
	L []OnlyWith    `ssz-max:"4"`
	N []OnlyWithNum `ssz-max:"8"`
}

// OnlyWithReflection is the twin outside the generation set.
type OnlyWithReflection struct {
	F OnlyWith
	L []OnlyWith    `ssz-max:"4"`
	N []OnlyWithNum `ssz-max:"8"`
}

// OnlyWithPlain is the twin built from plain values.
type OnlyWithPlain struct {
	F struct{ Data uint64 }
	L []struct{ Data uint64 } `ssz-max:"4"`
	N []uint64                `ssz-max:"8"`
}

var OnlyWithHolder_Payload = OnlyWithHolder{F: OnlyWith{1}, L: []OnlyWith{{2}, {3}}, N: []OnlyWithNum{4, 5, 6}}

var OnlyWithReflection_Payload = OnlyWithReflection{F: OnlyWith{1}, L: []OnlyWith{{2}, {3}}, N: []OnlyWithNum{4, 5, 6}}

// OnlyWithPlainPayload builds the plain twin, masked as the hash methods do
// or unmasked as the structure is.
func OnlyWithPlainPayload(mask uint64) OnlyWithPlain {
	return OnlyWithPlain{
		F: struct{ Data uint64 }{1 ^ mask},
		L: []struct{ Data uint64 }{{2 ^ mask}, {3 ^ mask}},
		N: []uint64{4 ^ mask, 5 ^ mask, 6 ^ mask},
	}
}

// WrappedU256 is a tagged wrapper around a uint256 whose hash method puts
// the 32 bytes of its value.
type WrappedU256 struct {
	Data [32]byte `ssz-type:"uint256"`
}

var _ = sszutils.Annotate[WrappedU256](`ssz-type:"wrapper"`)

func (w *WrappedU256) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutBytes(w.Data[:])
	return nil
}

// NarrowWrappedU256 is the same wrapper whose hash method puts only a uint64,
// which is not the packed form of a uint256.
type NarrowWrappedU256 struct {
	Data [32]byte `ssz-type:"uint256"`
}

var _ = sszutils.Annotate[NarrowWrappedU256](`ssz-type:"wrapper"`)

func (w *NarrowWrappedU256) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint64(binary.LittleEndian.Uint64(w.Data[:8]))
	return nil
}

// WrappedU256Holder lists the well-behaved wrapper and NarrowWrappedU256Holder
// the narrow one; the Reflection twins sit outside the generation set and
// WrappedU256Plain is the plain twin.
type WrappedU256Holder struct {
	L []WrappedU256 `ssz-max:"4" ssz-type:"?,wrapper"`
}

type WrappedU256Reflection struct {
	L []WrappedU256 `ssz-max:"4" ssz-type:"?,wrapper"`
}

type WrappedU256Plain struct {
	L [][32]byte `ssz-max:"4" ssz-type:"?,uint256"`
}

type NarrowWrappedU256Holder struct {
	L []NarrowWrappedU256 `ssz-max:"4" ssz-type:"?,wrapper"`
}

type NarrowWrappedU256Reflection struct {
	L []NarrowWrappedU256 `ssz-max:"4" ssz-type:"?,wrapper"`
}

var WrappedU256Holder_Payload = WrappedU256Holder{L: []WrappedU256{{Data: [32]byte{1}}, {Data: [32]byte{2, 0, 0, 0, 0, 0, 0, 0, 3}}}}

var WrappedU256Reflection_Payload = WrappedU256Reflection{L: []WrappedU256{{Data: [32]byte{1}}, {Data: [32]byte{2, 0, 0, 0, 0, 0, 0, 0, 3}}}}

var WrappedU256Plain_Payload = WrappedU256Plain{L: [][32]byte{{1}, {2, 0, 0, 0, 0, 0, 0, 0, 3}}}

var NarrowWrappedU256Holder_Payload = NarrowWrappedU256Holder{L: []NarrowWrappedU256{{Data: [32]byte{1}}, {Data: [32]byte{2}}}}

var NarrowWrappedU256Reflection_Payload = NarrowWrappedU256Reflection{L: []NarrowWrappedU256{{Data: [32]byte{1}}, {Data: [32]byte{2}}}}

// HugeBitlistHolder holds a bitlist whose limit exceeds the 32-bit int range
// in bits.
type HugeBitlistHolder struct {
	B []byte `ssz-type:"bitlist" ssz-max:"2147483648"`
}

// WalkerOnlyInner exposes only HashTreeRootWith; WalkerOnlyOuter is generated
// and WalkerOnlyReflection is its twin outside the generation set, both
// inheriting the method next to a sibling field.
type WalkerOnlyInner struct{ A uint64 }

func (v *WalkerOnlyInner) HashTreeRootWith(hh sszutils.HashWalker) error {
	hh.PutUint64(v.A)
	return nil
}

type WalkerOnlyOuter struct {
	WalkerOnlyInner
	B uint64
}

type WalkerOnlyReflection struct {
	WalkerOnlyInner
	B uint64
}

var WalkerOnlyOuter_Payload = WalkerOnlyOuter{WalkerOnlyInner: WalkerOnlyInner{A: 1}, B: 2}

var WalkerOnlyReflection_Payload = WalkerOnlyReflection{WalkerOnlyInner: WalkerOnlyInner{A: 1}, B: 2}

// CycleBatchA and CycleBatchB form one cycle whose members are generated
// together, so each member's code reaches the other through its depth twins.
type CycleBatchA struct {
	V  uint64
	Bs []CycleBatchB `ssz-max:"4"`
}

type CycleBatchB struct {
	W  uint32
	As []CycleBatchA `ssz-max:"4"`
}

// CycleBatchChain builds an A -> B -> A -> ... chain n hops deep;
// CycleBatchChainB starts the same chain at B.
func CycleBatchChain(n int) CycleBatchA {
	if n <= 0 {
		return CycleBatchA{V: 1}
	}
	return CycleBatchA{V: uint64(n), Bs: []CycleBatchB{{W: uint32(n), As: []CycleBatchA{CycleBatchChain(n - 1)}}}}
}

func CycleBatchChainB(n int) CycleBatchB {
	return CycleBatchB{W: uint32(n), As: []CycleBatchA{CycleBatchChain(n)}}
}

// RecursiveLeafNode is a recursive type whose view leaves the recursive field
// out, so the view's methods carry no depth while the data type's do.
type RecursiveLeafNode struct {
	Value    uint64
	Children []*RecursiveLeafNode `ssz-max:"4"`
}

type RecursiveLeafNode_View1 struct {
	Value uint64
}

var RecursiveLeafNode_Payload = RecursiveLeafNode{Value: 7, Children: []*RecursiveLeafNode{{Value: 8}}}

// EOFMatrixInner is the nested container of EOFMatrix.
type EOFMatrixInner struct {
	A uint64
	L []uint64 `ssz-max:"4"`
	C uint32
}

// EOFMatrix holds the shapes whose decoding depends on how a reader splits
// its bytes around EOF: nested variable-size lists and a nested container.
type EOFMatrix struct {
	LL [][]uint16 `ssz-max:"4,8"`
	BL [][]byte   `ssz-max:"4,8"`
	X  uint16
	D  EOFMatrixInner
}

// SinglePlain, SingleViewBase and SingleCustomHolder are generated one type
// per output file, so each file has to compile on the imports its own code
// uses: a plain container, a view-only type and a custom-typed field.
type SinglePlain struct {
	A uint64
	B uint32
}

type SingleViewBase struct {
	F1 uint64
	F2 []uint64 `ssz-max:"64"`
}

// SingleViewBase_View1 is a view for SingleViewBase.
type SingleViewBase_View1 struct {
	F1 uint64
}

type SingleCustomHolder struct {
	C noDynStreamCustom `ssz-type:"custom" ssz-size:"4"`
	N uint64
}

// RuntimeProduct sizes a byte matrix from two spec values whose product can
// pass the platform int range.
type RuntimeProduct struct {
	Data [][]byte `ssz-size:"1,1" dynssz-size:"OUTER,INNER"`
}

// negShell delegates every operation to its own methods and reports a
// negative size; NegShellHolder's generated code must refuse it.
type negShell struct{ V uint64 }

func (negShell) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) { return buf, nil }
func (negShell) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, _ []byte) error           { return nil }
func (negShell) SizeSSZDyn(_ sszutils.DynamicSpecs) int                            { return -1 }
func (negShell) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, _ sszutils.HashWalker) error {
	return nil
}

var _ = sszutils.Annotate[negShell](`ssz-static:"true"`)

type NegShellHolder struct {
	S negShell
	N uint64
}

// BadBitsZero, BadCompatNone and EmptyCompat are refused by both front ends:
// a literal bit size of zero on an array, dynssz.None in a compatible union,
// and a compatible union without variants.
type BadBitsZero struct {
	B [4]byte `ssz-type:"bitvector" ssz-bitsize:"0"`
}

type BadCompatNone struct {
	U dynssz.CompatibleUnion[struct {
		N dynssz.None
		A uint64
	}]
}

type EmptyCompat struct {
	U dynssz.CompatibleUnion[struct{}]
}

// shallowBasic delegates every operation to its own methods and is built
// shallow by both front ends; its SSZ shape is the basic width, so a holder
// pads it to a leaf and a list packs it.
type shallowBasic uint16

var _ = sszutils.Annotate[shallowBasic](`ssz-static:"true"`)

func (*shallowBasic) SizeSSZDyn(sszutils.DynamicSpecs) int { return 2 }
func (v *shallowBasic) MarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint16(b, uint16(*v)), nil
}
func (v *shallowBasic) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) error {
	if len(b) != 2 {
		return sszutils.ErrUnexpectedEOF
	}
	*v = shallowBasic(binary.LittleEndian.Uint16(b))
	return nil
}
func (v *shallowBasic) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, h sszutils.HashWalker) error {
	h.AppendUint16(uint16(*v))
	return nil
}

// WideAggregate sums three 1 GiB vectors: the total fits a 64-bit int and
// not a 32-bit one, where no value of the type can exist.
type WideAggregate struct {
	A []byte `ssz-size:"1073741824"`
	B []byte `ssz-size:"1073741824"`
	C []byte `ssz-size:"1073741824"`
}

// The shapes below place a declared size no 32-bit target can hold in every
// position the emitters form a byte offset for: beside a dynamic sibling, in
// a list of variable-size elements, behind an optional, and split across the
// static fields between two dynamic ones. Generated on any host, they must
// compile for a 32-bit target.
type WideBesideDynElem struct {
	X []byte `ssz-size:"3000000000"`
}

type WideBesideDyn struct {
	V []WideBesideDynElem `ssz-size:"1"`
	D []byte              `ssz-max:"8"`
}

type WideDynElem struct {
	X []byte `ssz-size:"3000000000"`
	D []byte `ssz-max:"8"`
}

type WideDynList struct {
	L []WideDynElem `ssz-max:"2"`
}

type WideOptionalInner struct {
	X []byte `ssz-size:"3000000000"`
}

type WideOptional struct {
	O *WideOptionalInner `ssz-type:"optional"`
}

// WideUnionVariants carries a declared size no 32-bit target can hold inside a
// union variant, where the variant's length check and its size are formed from
// that declaration.
type WideUnionVariants struct {
	A WideOptionalInner
	B uint64
}

type WideUnionHolder struct {
	U dynssz.CompatibleUnion[WideUnionVariants] `ssz-type:"compatible-union"`
}

// WideExprAfterStatic puts a spec-sized field behind a wide static one, so the
// fixed section's byte positions are formed from that declaration.
type WideExprAfterStatic struct {
	S []byte `ssz-size:"3000000000"`
	E []byte `ssz-size:"32" dynssz-size:"SPEC"`
}

type WideSplitStatics struct {
	D1 []byte `ssz-max:"8"`
	S1 []byte `ssz-size:"1500000000"`
	S2 []byte `ssz-size:"1500000000"`
	D2 []byte `ssz-max:"8"`
}

// WideListElem carries a declared size no 32-bit target can hold, held in a
// list rather than a vector so the element count is divided by that size.
type WideListElem struct {
	X []byte `ssz-size:"3000000000"`
}

type WideListHolder struct {
	L []WideListElem `ssz-max:"2"`
}

// WideElemInner is the variable-size element of WideElems.
type WideElemInner struct {
	L []byte `ssz-max:"8"`
}

// WideElems places a 3 GB static field behind a vector of variable-size
// elements, so the first offset and the element bounds carry the big size.
type WideElems struct {
	V []WideElemInner `ssz-size:"2"`
	W []byte          `ssz-size:"3000000000"`
}

// wideWrapperDescriptor holds 300 excluded fields before the single wrapped
// value, a position no byte-wide index can address.
type wideWrapperDescriptor struct {
	S000, S001, S002, S003, S004, S005, S006, S007, S008, S009 uint64 `ssz:"-"`
	S010, S011, S012, S013, S014, S015, S016, S017, S018, S019 uint64 `ssz:"-"`
	S020, S021, S022, S023, S024, S025, S026, S027, S028, S029 uint64 `ssz:"-"`
	S030, S031, S032, S033, S034, S035, S036, S037, S038, S039 uint64 `ssz:"-"`
	S040, S041, S042, S043, S044, S045, S046, S047, S048, S049 uint64 `ssz:"-"`
	S050, S051, S052, S053, S054, S055, S056, S057, S058, S059 uint64 `ssz:"-"`
	S060, S061, S062, S063, S064, S065, S066, S067, S068, S069 uint64 `ssz:"-"`
	S070, S071, S072, S073, S074, S075, S076, S077, S078, S079 uint64 `ssz:"-"`
	S080, S081, S082, S083, S084, S085, S086, S087, S088, S089 uint64 `ssz:"-"`
	S090, S091, S092, S093, S094, S095, S096, S097, S098, S099 uint64 `ssz:"-"`
	S100, S101, S102, S103, S104, S105, S106, S107, S108, S109 uint64 `ssz:"-"`
	S110, S111, S112, S113, S114, S115, S116, S117, S118, S119 uint64 `ssz:"-"`
	S120, S121, S122, S123, S124, S125, S126, S127, S128, S129 uint64 `ssz:"-"`
	S130, S131, S132, S133, S134, S135, S136, S137, S138, S139 uint64 `ssz:"-"`
	S140, S141, S142, S143, S144, S145, S146, S147, S148, S149 uint64 `ssz:"-"`
	S150, S151, S152, S153, S154, S155, S156, S157, S158, S159 uint64 `ssz:"-"`
	S160, S161, S162, S163, S164, S165, S166, S167, S168, S169 uint64 `ssz:"-"`
	S170, S171, S172, S173, S174, S175, S176, S177, S178, S179 uint64 `ssz:"-"`
	S180, S181, S182, S183, S184, S185, S186, S187, S188, S189 uint64 `ssz:"-"`
	S190, S191, S192, S193, S194, S195, S196, S197, S198, S199 uint64 `ssz:"-"`
	S200, S201, S202, S203, S204, S205, S206, S207, S208, S209 uint64 `ssz:"-"`
	S210, S211, S212, S213, S214, S215, S216, S217, S218, S219 uint64 `ssz:"-"`
	S220, S221, S222, S223, S224, S225, S226, S227, S228, S229 uint64 `ssz:"-"`
	S230, S231, S232, S233, S234, S235, S236, S237, S238, S239 uint64 `ssz:"-"`
	S240, S241, S242, S243, S244, S245, S246, S247, S248, S249 uint64 `ssz:"-"`
	S250, S251, S252, S253, S254, S255, S256, S257, S258, S259 uint64 `ssz:"-"`
	Data                                                       []byte `ssz-size:"4"`
}

// WideWrapperHolder carries the wrapper struct itself, so both engines
// address its value by field index.
type WideWrapperHolder struct {
	W wideWrapperDescriptor `ssz-type:"wrapper"`
}

// WideWrapperHolderRefl is the same shape without generated methods.
type WideWrapperHolderRefl struct {
	W wideWrapperDescriptor `ssz-type:"wrapper"`
}

// extScalar is a delegated signed basic, which is a basic shape only where
// extended types are enabled.
type extScalar int32

var _ = sszutils.Annotate[extScalar](`ssz-static:"true"`)

func (*extScalar) SizeSSZDyn(sszutils.DynamicSpecs) int { return 4 }
func (v *extScalar) MarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint32(b, uint32(*v)), nil
}
func (v *extScalar) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) error {
	if len(b) != 4 {
		return sszutils.ErrUnexpectedEOF
	}
	*v = extScalar(binary.LittleEndian.Uint32(b))
	return nil
}
func (v *extScalar) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, h sszutils.HashWalker) error {
	h.AppendUint32(uint32(*v))
	return nil
}

type ExtScalarHolder struct {
	A extScalar
	L []extScalar `ssz-max:"8"`
}

// ExtScalarHolderRefl is the same shape without generated methods.
type ExtScalarHolderRefl struct {
	A extScalar
	L []extScalar `ssz-max:"8"`
}

// customPair is a two-byte custom type: reflection packs it in list scope, so
// the generator has to reach the same shape from its annotation.
type customPair [2]byte

var _ = sszutils.Annotate[customPair](`ssz-type:"custom" ssz-size:"2" ssz-static:"true"`)

func (*customPair) SizeSSZDyn(sszutils.DynamicSpecs) int { return 2 }
func (v *customPair) MarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) ([]byte, error) {
	return append(b, v[:]...), nil
}
func (v *customPair) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) error {
	if len(b) != 2 {
		return sszutils.ErrUnexpectedEOF
	}
	copy(v[:], b)
	return nil
}
func (v *customPair) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, h sszutils.HashWalker) error {
	h.Append(v[:])
	return nil
}

type CustomPairList struct {
	L []customPair `ssz-max:"8"`
}

// CustomPairField holds the delegated custom type as a plain field. The field
// reference constrains nothing, so the type keeps the fixed framing its own
// annotation declares and sits inline rather than behind an offset.
type CustomPairField struct {
	A uint64
	C customPair
}

// CustomPairFieldRefl is the same shape without generated methods.
type CustomPairFieldRefl struct {
	A uint64
	C customPair
}

// CustomPairListRefl is the same shape without generated methods.
type CustomPairListRefl struct {
	L []customPair `ssz-max:"8"`
}

// dynWidthCustom is a delegated custom type whose width one spec value
// supplies: two bytes by default, whatever WIDTH says otherwise. A width that
// is not a literal makes the value composite, so it takes a leaf of its own
// rather than packing with its neighbours.
type dynWidthCustom [4]byte

var _ = sszutils.Annotate[dynWidthCustom](`ssz-type:"custom" ssz-static:"true" ssz-size:"2" dynssz-size:"WIDTH"`)

func dynWidthOf(ds sszutils.DynamicSpecs) (int, error) {
	w, err := sszutils.ResolveSpecValueWithDefault(ds, "WIDTH", 2)
	if err != nil {
		return 0, err
	}
	// The width has to fit the four bytes this type holds, which is also what
	// makes the narrowing below safe.
	if w > 4 {
		return 0, sszutils.NewSszErrorf(sszutils.ErrInvalidConstraint, "WIDTH %d exceeds the four bytes of this type", w)
	}
	return int(w), nil
}

func (*dynWidthCustom) SizeSSZDyn(ds sszutils.DynamicSpecs) int {
	w, err := dynWidthOf(ds)
	if err != nil {
		return 0
	}
	return w
}

func (v *dynWidthCustom) MarshalSSZDyn(ds sszutils.DynamicSpecs, b []byte) ([]byte, error) {
	w, err := dynWidthOf(ds)
	if err != nil {
		return nil, err
	}
	return append(b, v[:w]...), nil
}

func (v *dynWidthCustom) UnmarshalSSZDyn(ds sszutils.DynamicSpecs, b []byte) error {
	w, err := dynWidthOf(ds)
	if err != nil {
		return err
	}
	if len(b) != w {
		return sszutils.ErrUnexpectedEOF
	}
	copy(v[:], b)
	return nil
}

func (v *dynWidthCustom) HashTreeRootWithDyn(ds sszutils.DynamicSpecs, h sszutils.HashWalker) error {
	w, err := dynWidthOf(ds)
	if err != nil {
		return err
	}
	h.Append(v[:w])
	return nil
}

type DynWidthList struct {
	L []dynWidthCustom `ssz-max:"17"`
}

// DynWidthListRefl is the same shape without generated methods.
type DynWidthListRefl struct {
	L []dynWidthCustom `ssz-max:"17"`
}

// declaredU64 is a Go array declaring a uint64 shape, a width its Go kind
// does not state; the emitters must keep picking their element paths by the
// Go kind.
type declaredU64 [8]byte

var _ = sszutils.Annotate[declaredU64](`ssz-type:"uint64" ssz-static:"true"`)

func (*declaredU64) SizeSSZDyn(sszutils.DynamicSpecs) int { return 8 }
func (v *declaredU64) MarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) ([]byte, error) {
	return append(b, v[:]...), nil
}
func (v *declaredU64) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) error {
	if len(b) != 8 {
		return sszutils.ErrUnexpectedEOF
	}
	copy(v[:], b)
	return nil
}
func (v *declaredU64) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, h sszutils.HashWalker) error {
	h.Append(v[:])
	return nil
}

type DeclaredU64Holder struct {
	L []declaredU64 `ssz-max:"8"`
}

// DeclaredU64HolderRefl is the same shape without generated methods.
type DeclaredU64HolderRefl struct {
	L []declaredU64 `ssz-max:"8"`
}

// DeclaredU64Field holds the same delegate as a plain field: the declared
// uint64 shape is the type's own, and the field reference neither states it
// nor drops it.
type DeclaredU64Field struct {
	A uint64
	C declaredU64
}

// DeclaredU64FieldRefl is the same shape without generated methods.
type DeclaredU64FieldRefl struct {
	A uint64
	C declaredU64
}

// sizerCustom is a delegated custom type that declares a fixed framing but no
// width: only its own sizer states the three bytes it writes.
type sizerCustom struct{ X uint8 }

var _ = sszutils.Annotate[sizerCustom](`ssz-type:"custom" ssz-static:"true"`)

func (*sizerCustom) SizeSSZDyn(sszutils.DynamicSpecs) int { return 3 }
func (v *sizerCustom) MarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) ([]byte, error) {
	return append(b, v.X, 0, 0), nil
}
func (v *sizerCustom) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) error {
	if len(b) != 3 {
		return sszutils.ErrUnexpectedEOF
	}
	v.X = b[0]
	return nil
}
func (v *sizerCustom) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, h sszutils.HashWalker) error {
	h.PutUint8(v.X)
	return nil
}

// SizerCustomField holds it as a plain field. The reflection engine reads the
// width from the sizer and frames the field inline; the generator has no
// sizer to call and refuses the type instead of guessing.
type SizerCustomField struct {
	A uint64
	C sizerCustom
}

// plainExtScalar is a delegated signed basic in the batch generated without
// extended types: a delegated type is never traversed, so both front ends
// keep its shape whatever that flag says.
type plainExtScalar int32

var _ = sszutils.Annotate[plainExtScalar](`ssz-static:"true"`)

func (*plainExtScalar) SizeSSZDyn(sszutils.DynamicSpecs) int { return 4 }
func (v *plainExtScalar) MarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint32(b, uint32(*v)), nil
}
func (v *plainExtScalar) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) error {
	if len(b) != 4 {
		return sszutils.ErrUnexpectedEOF
	}
	*v = plainExtScalar(binary.LittleEndian.Uint32(b))
	return nil
}
func (v *plainExtScalar) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, h sszutils.HashWalker) error {
	h.AppendUint32(uint32(*v))
	return nil
}

type PlainExtHolder struct {
	L []plainExtScalar `ssz-max:"8"`
}

// PlainExtHolderRefl is the same shape without generated methods.
type PlainExtHolderRefl struct {
	L []plainExtScalar `ssz-max:"8"`
}

// amount declares a 16-byte basic shape by annotation, which no Go kind can
// state. Packed scopes size their capacity by that width in both engines.
type amount [16]byte

var _ = sszutils.Annotate[amount](`ssz-type:"uint128" ssz-static:"true"`)

func (*amount) SizeSSZDyn(sszutils.DynamicSpecs) int { return 16 }
func (v *amount) MarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) ([]byte, error) {
	return append(b, v[:]...), nil
}
func (v *amount) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) error {
	if len(b) != 16 {
		return sszutils.ErrUnexpectedEOF
	}
	copy(v[:], b)
	return nil
}
func (v *amount) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, h sszutils.HashWalker) error {
	h.Append(v[:])
	return nil
}

type AmountList struct {
	L []amount `ssz-max:"8"`
}

// exprWidthCustom is a delegated custom type whose width only a spec value
// names on the reference: WIDTH bytes, two when nothing says otherwise. A
// width dynWidthOf refuses is zero bytes here; the refusal itself is
// dynWidthCustom's to report.
type exprWidthCustom [4]byte

func (*exprWidthCustom) SizeSSZDyn(ds sszutils.DynamicSpecs) int {
	w, _ := dynWidthOf(ds)
	return w
}

func (v *exprWidthCustom) MarshalSSZDyn(ds sszutils.DynamicSpecs, b []byte) ([]byte, error) {
	w, _ := dynWidthOf(ds)
	return append(b, v[:w]...), nil
}

func (v *exprWidthCustom) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) error {
	*v = exprWidthCustom{}
	copy(v[:], b)
	return nil
}

func (v *exprWidthCustom) HashTreeRootWithDyn(ds sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	w, _ := dynWidthOf(ds)
	hh.PutBytes(v[:w])
	return nil
}

// ExprWidthHolder references exprWidthCustom with its width from WIDTH alone,
// as a field and as a list element.
type ExprWidthHolder struct {
	E exprWidthCustom   `ssz-type:"custom" dynssz-size:"WIDTH"`
	L []exprWidthCustom `ssz-type:"?,custom" dynssz-size:"?,WIDTH" ssz-max:"4"`
}

// ExprWidthHolderRefl is the same shape without generated methods.
type ExprWidthHolderRefl struct {
	E exprWidthCustom   `ssz-type:"custom" dynssz-size:"WIDTH"`
	L []exprWidthCustom `ssz-type:"?,custom" dynssz-size:"?,WIDTH" ssz-max:"4"`
}

// annExprWidthCustom is exprWidthCustom with the width named on the type's
// own annotation instead of on each reference.
type annExprWidthCustom [4]byte

var _ = sszutils.Annotate[annExprWidthCustom](`ssz-type:"custom" dynssz-size:"WIDTH"`)

func (*annExprWidthCustom) SizeSSZDyn(ds sszutils.DynamicSpecs) int {
	w, _ := dynWidthOf(ds)
	return w
}

func (v *annExprWidthCustom) MarshalSSZDyn(ds sszutils.DynamicSpecs, b []byte) ([]byte, error) {
	w, _ := dynWidthOf(ds)
	return append(b, v[:w]...), nil
}

func (v *annExprWidthCustom) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) error {
	*v = annExprWidthCustom{}
	copy(v[:], b)
	return nil
}

func (v *annExprWidthCustom) HashTreeRootWithDyn(ds sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	w, _ := dynWidthOf(ds)
	hh.PutBytes(v[:w])
	return nil
}

// AnnExprWidthHolder references annExprWidthCustom without any width of its
// own, as a field and as a list element.
type AnnExprWidthHolder struct {
	E annExprWidthCustom
	L []annExprWidthCustom `ssz-max:"4"`
}

// AnnExprWidthHolderRefl is the same shape without generated methods.
type AnnExprWidthHolderRefl struct {
	E annExprWidthCustom
	L []annExprWidthCustom `ssz-max:"4"`
}

// AmountListRefl is the same shape without generated methods.
type AmountListRefl struct {
	L []amount `ssz-max:"8"`
}

// noAnnDelegate delegates every operation but carries no annotation, so
// neither engine builds it shallow and the cycle it closes with NoAnnParent
// is an ordinary recursive cycle.
type noAnnDelegate struct {
	V uint64
	P []NoAnnParent `ssz-max:"4"`
}

func (noAnnDelegate) SizeSSZDyn(sszutils.DynamicSpecs) int { return 8 }
func (v noAnnDelegate) MarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint64(b, v.V), nil
}
func (v *noAnnDelegate) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) error {
	if len(b) != 8 {
		return sszutils.ErrUnexpectedEOF
	}
	v.V = binary.LittleEndian.Uint64(b)
	return nil
}
func (v noAnnDelegate) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, h sszutils.HashWalker) error {
	h.PutUint64(v.V)
	return nil
}

type NoAnnParent struct {
	A noAnnDelegate
}

type ShallowBasicHolder struct {
	A shallowBasic
	B uint64
}

// ShallowBasicHolderRefl is the same shape without generated methods.
type ShallowBasicHolderRefl struct {
	A shallowBasic
	B uint64
}

type ShallowBasicList struct {
	L []shallowBasic `ssz-max:"65"`
}

type ShallowBasicListRefl struct {
	L []shallowBasic `ssz-max:"65"`
}

// edgeOpaque owns an eight-byte wire format and lies on a cycle with
// edgeCycleA, which has no methods, through a Go field that is not part of
// that format: describing edgeCycleA is refused by both front ends.
type edgeOpaque struct {
	Value    uint64
	Children []edgeCycleA `ssz-max:"4"`
	Bad      map[string]int
}

var _ = sszutils.Annotate[edgeOpaque](`ssz-static:"true"`)

func (v *edgeOpaque) MarshalSSZDyn(_ sszutils.DynamicSpecs, dst []byte) ([]byte, error) {
	if v == nil {
		return binary.LittleEndian.AppendUint64(dst, 0), nil
	}
	return binary.LittleEndian.AppendUint64(dst, v.Value), nil
}
func (v *edgeOpaque) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	if len(buf) != 8 {
		return sszutils.ErrUnexpectedEOF
	}
	v.Value = binary.LittleEndian.Uint64(buf)
	return nil
}
func (v *edgeOpaque) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return 8 }
func (v *edgeOpaque) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, h sszutils.HashWalker) error {
	idx := h.StartTree(sszutils.TreeTypeNone)
	if v == nil {
		h.PutUint64(0)
	} else {
		h.PutUint64(v.Value)
	}
	h.Merkleize(idx)
	return nil
}

type edgeCycleA struct{ Opaque edgeOpaque }

type EdgeCycleParent struct{ A edgeCycleA }

// BadHugeVector declares 2^32 bytes, one past the SSZ size limit.
type BadHugeVector struct {
	V []uint64 `ssz-size:"536870912"`
}

// BadHugeContainer's fixed section sums to 2^32 bytes.
type BadHugeContainer struct {
	A []byte `ssz-size:"2147483648"`
	B []byte `ssz-size:"2147483648"`
}

// BadHugeDynVector declares 2^61 variable-size elements: a length the
// vector byte-size check never sees, since the element has no static size.
type BadHugeDynVector struct {
	V []DynVecElem `ssz-size:"2305843009213693952"`
}

// BadOffsetTable declares 2^30 variable-size elements, whose offset table
// alone fills the fixed section.
type BadOffsetTable struct {
	V []DynVecElem `ssz-size:"1073741824"`
}

// OffsetTableSpec sizes a vector of variable-size elements from a spec value.
type OffsetTableSpec struct {
	V []DynVecElem `ssz-size:"1" dynssz-size:"COUNT"`
}

// specSumInner is sized by two spec values; SpecSumInline inlines it, so the
// holder's generated prelude sums the two sizes itself. SpecSumInner is its
// generated twin, whose sizer SpecSumDelegated calls instead.
type specSumInner struct {
	A []byte `ssz-size:"1" dynssz-size:"SIZE_A"`
	B []byte `ssz-size:"1" dynssz-size:"SIZE_B"`
}

type SpecSumInner struct {
	A []byte `ssz-size:"1" dynssz-size:"SIZE_A"`
	B []byte `ssz-size:"1" dynssz-size:"SIZE_B"`
}

type SpecSumInline struct {
	V []specSumInner `ssz-size:"1" dynssz-size:"COUNT"`
}

type SpecSumDelegated struct {
	V []SpecSumInner `ssz-size:"1" dynssz-size:"COUNT"`
}

// partialComposite is a composite type whose hash method leaves a partial
// chunk, eight raw bytes, instead of one root; goodComposite honours the
// contract. Both walkers refuse the first and agree on the second.
type partialComposite struct{ A, B uint64 }

func (p *partialComposite) HashTreeRootWith(hh sszutils.HashWalker) error {
	hh.Append([]byte{1, 2, 3, 4, 5, 6, 7, 8})
	return nil
}
func (p *partialComposite) HashTreeRoot() ([32]byte, error) { return [32]byte{9}, nil }

// flushedComposite leaves a partial chunk and then adds a leaf, which flushes
// the partial bytes into a padded leaf of their own.
type flushedComposite struct{ A, B uint64 }

func (p *flushedComposite) HashTreeRootWith(hh sszutils.HashWalker) error {
	hh.Append([]byte{1, 2, 3, 4, 5, 6, 7, 8})
	hh.PutUint64(p.B)
	return nil
}
func (p *flushedComposite) HashTreeRoot() ([32]byte, error) { return [32]byte{9}, nil }

type FlushedHolder struct {
	N uint64
	P flushedComposite
	M uint64
}

type FlushedHolderRefl struct {
	N uint64
	P flushedComposite
	M uint64
}

// A delegate that leaves a partial chunk is followed here by each shape that
// opens a region right on it: a byte vector, a bitlist and a container. Both
// walkers have to lay those out the same way, whatever the delegate left.
type PartialVecHolder struct {
	P partialComposite
	V [48]byte
}

// PartialVecHolderRefl is the same shape without generated methods.
type PartialVecHolderRefl struct {
	P partialComposite
	V [48]byte
}

type PartialBitlistHolder struct {
	P partialComposite
	B []byte `ssz-type:"bitlist" ssz-max:"64"`
}

// PartialBitlistHolderRefl is the same shape without generated methods.
type PartialBitlistHolderRefl struct {
	P partialComposite
	B []byte `ssz-type:"bitlist" ssz-max:"64"`
}

// plainPair is an ordinary container, so the field after the delegate opens a
// scope rather than writing a value.
type plainPair struct{ A, B uint64 }

type PartialScopeHolder struct {
	P partialComposite
	C plainPair
}

// PartialScopeHolderRefl is the same shape without generated methods.
type PartialScopeHolderRefl struct {
	P partialComposite
	C plainPair
}

type goodComposite struct{ A, B uint64 }

func (g *goodComposite) HashTreeRootWith(hh sszutils.HashWalker) error {
	idx := hh.StartTree(sszutils.TreeTypeNone)
	hh.PutUint64(g.A)
	hh.PutUint64(g.B)
	hh.Merkleize(idx)
	return nil
}
func (g *goodComposite) HashTreeRoot() ([32]byte, error) { return [32]byte{}, nil }

type PartialHolder struct {
	N uint64
	P partialComposite
	M uint64
}

type PartialHolderRefl struct {
	N uint64
	P partialComposite
	M uint64
}

type GoodHolder struct {
	N uint64
	G goodComposite
	M uint64
}

type GoodHolderRefl struct {
	N uint64
	G goodComposite
	M uint64
}

// fixedOctets is a named slice with its own eight-byte fixed codec: it lies
// on no cycle and must keep its shallow static descriptor.
type fixedOctets []byte

var _ = sszutils.Annotate[fixedOctets](`ssz-static:"true"`)

func (v *fixedOctets) MarshalSSZDyn(_ sszutils.DynamicSpecs, dst []byte) ([]byte, error) {
	var data [8]byte
	if v != nil {
		copy(data[:], *v)
	}
	return append(dst, data[:]...), nil
}
func (v *fixedOctets) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	if len(buf) != 8 {
		return sszutils.ErrUnexpectedEOF
	}
	*v = append((*v)[:0], buf...)
	return nil
}
func (v *fixedOctets) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return 8 }
func (v *fixedOctets) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, h sszutils.HashWalker) error {
	var data [8]byte
	if v != nil {
		copy(data[:], *v)
	}
	h.PutBytes(data[:])
	return nil
}

type OctetParent struct{ Data fixedOctets }

type OctetParentRefl struct{ Data fixedOctets }

// KnownSizeLists carries one fixed-element list and one list of lists large
// enough that a stream decode seeded from the read buffer would grow them.
type KnownSizeLists struct {
	L  []uint32   `ssz-max:"1048576"`
	LL [][]uint16 `ssz-max:"16384,64"`
}

var EOFMatrix_Payload = EOFMatrix{LL: [][]uint16{{1, 2}, {3}}, BL: [][]byte{{1, 2}, {3}}, X: 7, D: EOFMatrixInner{A: 1, L: []uint64{3, 4}, C: 5}}

// CountedNum is a named uint64 whose hash method counts its calls and puts
// the value; CountedNumErr makes it fail instead.
type CountedNum uint64

var (
	CountedNumCalls int
	CountedNumErr   error
)

func (c *CountedNum) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	CountedNumCalls++
	if CountedNumErr != nil {
		return CountedNumErr
	}
	hh.PutUint64(uint64(*c))
	return nil
}

// CountedNumHolder lists CountedNum under a limit and progressively.
type CountedNumHolder struct {
	L []CountedNum `ssz-max:"8"`
	P []CountedNum `ssz-type:"progressive-list"`
}

// CountedNumReflection is the twin outside the generation set.
type CountedNumReflection struct {
	L []CountedNum `ssz-max:"8"`
	P []CountedNum `ssz-type:"progressive-list"`
}

// CountedNumPlain is the twin built from plain uint64 values.
type CountedNumPlain struct {
	L []uint64 `ssz-max:"8"`
	P []uint64 `ssz-type:"progressive-list"`
}

var CountedNumHolder_Payload = CountedNumHolder{L: []CountedNum{1, 2, 3}, P: []CountedNum{4, 5, 6, 7, 8}}

var CountedNumReflection_Payload = CountedNumReflection{L: []CountedNum{1, 2, 3}, P: []CountedNum{4, 5, 6, 7, 8}}

var CountedNumPlain_Payload = CountedNumPlain{L: []uint64{1, 2, 3}, P: []uint64{4, 5, 6, 7, 8}}

// ViewNum64 is a uint64 whose view hash method puts the value plus one
// through a uint64 view.
type ViewNum64 uint64

func (v *ViewNum64) HashTreeRootWithDynView(view any) func(sszutils.DynamicSpecs, sszutils.HashWalker) error {
	if _, ok := view.(*uint64); !ok {
		return nil
	}
	return func(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
		hh.PutUint64(uint64(*v) + 1)
		return nil
	}
}

// ViewNum64Types_Base lists ViewNum64; its layout lives in the view.
type ViewNum64Types_Base struct {
	V []ViewNum64
}

// ViewNum64Types_View1 is the schema: a packed list of uint64.
type ViewNum64Types_View1 struct {
	V []uint64 `ssz-max:"4"`
}

// ViewNum64Types_Reflection is the twin outside the generation set.
type ViewNum64Types_Reflection struct {
	V []ViewNum64
}

// ViewNum64Types_Plain is the twin built from the values the view method puts.
type ViewNum64Types_Plain struct {
	V []uint64 `ssz-max:"4"`
}

var ViewNum64Types_Payload = ViewNum64Types_Base{V: []ViewNum64{1, 2, 3}}

var ViewNum64Types_Reflection_Payload = ViewNum64Types_Reflection{V: []ViewNum64{1, 2, 3}}

var ViewNum64Types_Plain_Payload = ViewNum64Types_Plain{V: []uint64{2, 3, 4}}

// PromotedViewInner gets generated view methods for PromotedViewSchema.
type PromotedViewInner struct{ B uint64 }

// PromotedViewSchema is its view schema.
type PromotedViewSchema struct{ B uint64 }

// PromotedViewOuter embeds the generated type and shadows its field; it is
// not generated, so the promoted view methods are all it offers.
type PromotedViewOuter struct {
	PromotedViewInner
	B uint64
}

// UnionSpecVariants has a variant whose width comes from a spec value.
type UnionSpecVariants struct {
	Bytes [8]byte `ssz-size:"4" dynssz-size:"UNION_WIDTH"`
}

// UnionSpecChild and CompatUnionSpecChild hold the union; UnionSpecParent and
// CompatUnionSpecParent hold the child, so the parent's choice of child method
// decides whether the width follows the instance's specs.
type UnionSpecChild struct {
	Choice dynssz.Union[UnionSpecVariants]
}

type UnionSpecParent struct {
	Child UnionSpecChild
	Tail  uint8
}

type CompatUnionSpecChild struct {
	Choice dynssz.CompatibleUnion[UnionSpecVariants]
}

type CompatUnionSpecParent struct {
	Child CompatUnionSpecChild
	Tail  uint8
}

var UnionSpecParent_Payload = UnionSpecParent{
	Child: UnionSpecChild{Choice: dynssz.Union[UnionSpecVariants]{Variant: 0, Data: [8]byte{1, 2, 3, 4, 5, 6, 7, 8}}},
	Tail:  9,
}

var CompatUnionSpecParent_Payload = CompatUnionSpecParent{
	Child: CompatUnionSpecChild{Choice: dynssz.CompatibleUnion[UnionSpecVariants]{Variant: 1, Data: [8]byte{1, 2, 3, 4, 5, 6, 7, 8}}},
	Tail:  9,
}

var UnionSpec_Specs = map[string]any{"UNION_WIDTH": uint64(8)}

// RecursiveOverlapA lies on two cycles that share RecursiveOverlapB, so every
// one of the three types is a cycle member and charges a nesting level.
type RecursiveOverlapA struct {
	B []RecursiveOverlapB `ssz-max:"1"`
	C []RecursiveOverlapC `ssz-max:"1"`
}

type RecursiveOverlapB struct {
	A []RecursiveOverlapA `ssz-max:"1"`
}

type RecursiveOverlapC struct {
	B []RecursiveOverlapB `ssz-max:"1"`
}

var RecursiveOverlapA_Payload = RecursiveOverlapA{
	B: []RecursiveOverlapB{{A: []RecursiveOverlapA{{}}}},
	C: []RecursiveOverlapC{{B: []RecursiveOverlapB{{A: []RecursiveOverlapA{{C: []RecursiveOverlapC{{}}}}}}}},
}

// OptSpecInner is a fixed-size container whose width comes from a spec value.
type OptSpecInner struct {
	Y []byte `ssz-size:"4" dynssz-size:"OPT_INNER_LEN"`
	Z uint32
}

// OptSpecBytes is a byte vector whose width comes from a spec value.
type OptSpecBytes []byte

var _ = sszutils.Annotate[OptSpecBytes](`ssz-size:"4" dynssz-size:"OPT_INNER_LEN"`)

// OptSpecHolder holds both as optional values, so a present value occupies
// the presence byte plus the width the instance's specs resolve.
type OptSpecHolder struct {
	A     uint8
	Opt   *OptSpecInner `ssz-type:"optional"`
	Bytes *OptSpecBytes `ssz-type:"optional"`
	Tail  uint8
}

func optSpecHolderPayload(width int) OptSpecHolder {
	y := make([]byte, width)
	b := make(OptSpecBytes, width)
	for i := range width {
		y[i], b[i] = byte(i+1), byte(0x10+i)
	}
	return OptSpecHolder{A: 1, Opt: &OptSpecInner{Y: y, Z: 7}, Bytes: &b, Tail: 9}
}

var OptSpecHolder_Payload = optSpecHolderPayload(6)

var OptSpecHolder_Specs = map[string]any{"OPT_INNER_LEN": uint64(6)}

// WidthCustom is a custom type whose fastssz methods bake the default width of
// two bytes while its dynssz buffer methods take the width from CUSTOM_WIDTH.
type WidthCustom struct{ Data []byte }

func (c *WidthCustom) SizeSSZ() int { return 2 }

func (c *WidthCustom) MarshalSSZ() ([]byte, error) { return c.MarshalSSZTo(nil) }

func (c *WidthCustom) MarshalSSZTo(buf []byte) ([]byte, error) {
	if len(c.Data) != 2 {
		return nil, sszutils.ErrVectorLengthFn(len(c.Data), 2)
	}
	return append(buf, c.Data...), nil
}

func (c *WidthCustom) UnmarshalSSZ(buf []byte) error {
	if len(buf) != 2 {
		return sszutils.ErrVectorLengthFn(len(buf), 2)
	}
	c.Data = append([]byte(nil), buf...)
	return nil
}

func (c *WidthCustom) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	copy(root[:], c.Data)
	return root, nil
}

func (c *WidthCustom) SizeSSZDyn(ds sszutils.DynamicSpecs) int {
	return sszutils.CapToInt(widthCustomWidth(ds))
}

func (c *WidthCustom) MarshalSSZDyn(ds sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	if uint64(len(c.Data)) != widthCustomWidth(ds) {
		return nil, sszutils.ErrVectorLengthFn(len(c.Data), widthCustomWidth(ds))
	}
	return append(buf, c.Data...), nil
}

func (c *WidthCustom) UnmarshalSSZDyn(ds sszutils.DynamicSpecs, buf []byte) error {
	if uint64(len(buf)) != widthCustomWidth(ds) {
		return sszutils.ErrVectorLengthFn(len(buf), widthCustomWidth(ds))
	}
	c.Data = append([]byte(nil), buf...)
	return nil
}

func (c *WidthCustom) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutBytes(c.Data)
	return nil
}

func widthCustomWidth(ds sszutils.DynamicSpecs) uint64 {
	width, _ := sszutils.ResolveSpecValueWithDefault(ds, "CUSTOM_WIDTH", 2)
	return width
}

// WidthCustomHolder nests the custom type as a dynamic field.
type WidthCustomHolder struct {
	Item WidthCustom `ssz-type:"custom"`
	Tail uint8
}

func widthCustomHolderPayload(width int) WidthCustomHolder {
	data := make([]byte, width)
	for i := range data {
		data[i] = byte(0x20 + i)
	}
	return WidthCustomHolder{Item: WidthCustom{Data: data}, Tail: 9}
}

var WidthCustomHolder_Payload = widthCustomHolderPayload(3)

var WidthCustomHolder_Specs = map[string]any{"CUSTOM_WIDTH": uint64(3)}

// ZeroSizeShell serializes to no bytes through its own static methods.
type ZeroSizeShell struct{}

var _ = sszutils.Annotate[ZeroSizeShell](`ssz-static:"true"`)

func (z *ZeroSizeShell) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return 0 }

func (z *ZeroSizeShell) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return buf, nil
}

func (z *ZeroSizeShell) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	if len(buf) != 0 {
		return sszutils.ErrTrailingDataFn(len(buf))
	}
	return nil
}

func (z *ZeroSizeShell) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint64(0)
	return nil
}

// ZeroSizeShellList lists a zero-size element; its count cannot be derived
// from a region, so decoding fails instead of dividing by zero.
type ZeroSizeShellList struct {
	L []ZeroSizeShell `ssz-max:"4"`
}

// ZeroSizeShellOptional holds a zero-size element as an optional-list; a
// present value would leave the region as empty as an absent one, so decoding
// fails instead of losing presence.
type ZeroSizeShellOptional struct {
	Item *ZeroSizeShell `ssz-type:"optional-list"`
}

// WideByteCustom is a custom type stored in a uint8 whose SSZ width is four
// bytes.
type WideByteCustom uint8

func (c *WideByteCustom) SizeSSZ() int { return 4 }

func (c *WideByteCustom) MarshalSSZ() ([]byte, error) { return c.MarshalSSZTo(nil) }

func (c *WideByteCustom) MarshalSSZTo(buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint32(buf, uint32(*c)), nil
}

func (c *WideByteCustom) UnmarshalSSZ(buf []byte) error {
	if len(buf) != 4 {
		return sszutils.ErrUnexpectedEOF
	}
	*c = WideByteCustom(binary.LittleEndian.Uint32(buf))
	return nil
}

func (c *WideByteCustom) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	binary.LittleEndian.PutUint32(root[:], uint32(*c))
	return root, nil
}

func (c *WideByteCustom) HashTreeRootWith(hh sszutils.HashWalker) error {
	hh.PutUint32(uint32(*c))
	return nil
}

// WideByteCustomHolder places the custom type in a list and a vector, where
// each element takes its declared width.
type WideByteCustomHolder struct {
	L []WideByteCustom  `ssz-type:"?,custom" ssz-size:"?,4" ssz-max:"8"`
	V [3]WideByteCustom `ssz-type:"?,custom" ssz-size:"3,4"`
	T uint8
}

var WideByteCustomHolder_Payload = WideByteCustomHolder{
	L: []WideByteCustom{1, 2},
	V: [3]WideByteCustom{3, 4, 5},
	T: 6,
}

// CoverageTypes6 wraps MarshalerOnlyType as a field to trigger the
// DynamicMarshaler/DynamicUnmarshaler dispatch branches.
type CoverageTypes6 struct {
	F1 uint64
	M1 MarshalerOnlyType
}

var CoverageTypes6_Payload = CoverageTypes6{
	F1: 99,
	M1: MarshalerOnlyType{Val: 67890},
}

// ViewTypes4_Base is generated in a SEPARATE go:generate command from
// ViewTypes1_Base. This forces the parser to discover ViewTypes1_Base's
// view methods via method set detection rather than the internal compat
// flag map. It also includes CompatibleUnion and TypeWrapper fields with
// view-dependent schemas to exercise the view descriptor paths in
// buildCompatibleUnionDescriptor and buildTypeWrapperDescriptor.
type ViewTypes4_Base struct {
	F1    uint64
	Child *ViewTypes1_Base
	U1    dynssz.CompatibleUnion[struct {
		F1 uint32
		F2 uint64
	}]
	W1 dynssz.TypeWrapper[struct {
		Data []byte `ssz-size:"32"`
	}, []byte] `ssz-type:"wrapper"`
}

// ViewTypes4_View1 uses different union variants and wrapper sizes.
type ViewTypes4_View1 struct {
	F1    uint64
	Child *ViewTypes1_View1
	U1    dynssz.CompatibleUnion[struct {
		F1 uint32
	}]
	W1 dynssz.TypeWrapper[struct {
		Data []byte `ssz-size:"16"`
	}, []byte] `ssz-type:"wrapper"`
}

var ViewTypes4_Payload = ViewTypes4_Base{
	F1: 42,
	Child: &ViewTypes1_Base{
		F1: 12345,
		F2: []uint64{12345, 67890},
		F3: [2][]uint64{{12345, 67890}, {12345, 67890}},
		C1: &ViewTypes1_C1{
			F1: 12345,
			F2: []uint64{12345, 67890},
		},
	},
	U1: dynssz.CompatibleUnion[struct {
		F1 uint32
		F2 uint64
	}]{
		Variant: 1,
		Data:    uint32(0x12345678),
	},
	W1: dynssz.TypeWrapper[struct {
		Data []byte `ssz-size:"32"`
	}, []byte]{
		Data: []byte{1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16},
	},
}

// CoverageTypes4 covers: dynamic vector of extended types with size expressions,
// union with multiple variants, additional optional type patterns.
type CoverageTypes4 struct {
	U1 dynssz.CompatibleUnion[struct {
		F1 uint32
		F2 uint64
		F3 []uint16 `ssz-size:"4"`
	}]
	U1V1 dynssz.CompatibleUnion[struct {
		F1 uint32
		F2 uint64
		F3 []uint16 `ssz-size:"4"`
	}]
	U1V2 dynssz.CompatibleUnion[struct {
		F1 uint32
		F2 uint64
		F3 []uint16 `ssz-size:"4"`
	}]
	Opt3 *uint16 `ssz-type:"optional"`
	Opt4 *bool   `ssz-type:"optional"`
}

var (
	covU16 = uint16(42)
	covB2  = true
)

var CoverageTypes4_Payload = CoverageTypes4{
	U1: dynssz.CompatibleUnion[struct {
		F1 uint32
		F2 uint64
		F3 []uint16 `ssz-size:"4"`
	}]{
		Variant: 1,
		Data:    uint32(0x12345678),
	},
	U1V1: dynssz.CompatibleUnion[struct {
		F1 uint32
		F2 uint64
		F3 []uint16 `ssz-size:"4"`
	}]{
		Variant: 2,
		Data:    uint64(0xdeadbeef),
	},
	U1V2: dynssz.CompatibleUnion[struct {
		F1 uint32
		F2 uint64
		F3 []uint16 `ssz-size:"4"`
	}]{
		Variant: 3,
		Data:    []uint16{1, 2, 3, 4},
	},
	Opt3: &covU16,
	Opt4: &covB2,
}

// nestedDelegatedInner is a hand-written, fully-delegated SSZ type carrying a
// structurally-invalid innard (a zero-length array). When it is referenced by a
// generated type the parser must shallow-build it via its ssz-static annotation
// and never traverse into Bad, which the spec validations would otherwise reject.
type nestedDelegatedInner struct {
	Bad   [0]uint64 // illegal Vector[uint64, 0] if ever traversed
	Value uint32
}

var _ = sszutils.Annotate[nestedDelegatedInner](`ssz-static:"true"`)

func (n *nestedDelegatedInner) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return 4 }

func (n *nestedDelegatedInner) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint32(buf, n.Value), nil
}

func (n *nestedDelegatedInner) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	// The caller (a fixed 4-byte static field) always slices exactly 4 bytes.
	n.Value = binary.LittleEndian.Uint32(buf)
	return nil
}

func (n *nestedDelegatedInner) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint32(n.Value)
	return nil
}

// NestedDelegatedContainer is generated and references the fully-delegated inner
// type as a static field. Generating it succeeds only because the parser
// shallow-builds the inner type instead of traversing its illegal innard.
type NestedDelegatedContainer struct {
	A uint64
	N nestedDelegatedInner
}

var NestedDelegatedContainer_Payload = NestedDelegatedContainer{
	A: 7,
	N: nestedDelegatedInner{Value: 0x11223344},
}

// nestedDelegatedDyn is the variable-size counterpart of nestedDelegatedInner: a
// fully-delegated type declaring ssz-static:"false". It also carries an illegal
// innard that the parser must not traverse.
type nestedDelegatedDyn struct {
	Bad   [0]uint64 // illegal Vector[uint64, 0] if ever traversed
	Items []uint32  `ssz-max:"64"`
}

var _ = sszutils.Annotate[nestedDelegatedDyn](`ssz-static:"false"`)

func (n *nestedDelegatedDyn) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return len(n.Items) * 4 }

func (n *nestedDelegatedDyn) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	for _, v := range n.Items {
		buf = binary.LittleEndian.AppendUint32(buf, v)
	}
	return buf, nil
}

func (n *nestedDelegatedDyn) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	n.Items = make([]uint32, len(buf)/4)
	for i := range n.Items {
		n.Items[i] = binary.LittleEndian.Uint32(buf[i*4:])
	}
	return nil
}

func (n *nestedDelegatedDyn) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	idx := hh.Index()
	for _, v := range n.Items {
		hh.AppendUint32(v)
	}
	hh.FillUpTo32()
	hh.MerkleizeWithMixin(idx, uint64(len(n.Items)), 1024)
	return nil
}

// ReflectDelegatedDynList holds a fully delegated variable-size type as a
// list element, which the reflect front end describes without its fields.
type ReflectDelegatedDynList struct {
	L []nestedDelegatedDyn `ssz-max:"3"`
}

// NestedDelegatedDynContainer references the variable-size fully-delegated type
// as a dynamic field, exercising the parser gate's ssz-static:"false" branch.
type NestedDelegatedDynContainer struct {
	A uint64
	N nestedDelegatedDyn
}

var NestedDelegatedDynContainer_Payload = NestedDelegatedDynContainer{
	A: 9,
	N: nestedDelegatedDyn{Items: []uint32{1, 2, 3}},
}

// Types below exercise codegen-vs-reflection layout/root agreement for
// tricky descriptor shapes (multi-dim spec sizes, bitlists without limits,
// name-detected bitlists, bitvector edge cases).

// MultiDimSpecVec has a fixed-size multi-dim vector with spec expressions;
// SizeSSZ must equal len(MarshalSSZ) even for a fully-empty value (the
// missing rows are zero-padded on the wire).
type MultiDimSpecVec struct {
	M [][]byte `ssz-size:"2,4" dynssz-size:"SPEC_OUTER,SPEC_INNER"`
}

// NoMaxBitlist has a limit far above its payload, so it exercises the
// bit-limit merkleization path; codegen and reflection must agree on the root.
// A bitlist with no limit at all has no root and lives in UnboundedBitlist.
type NoMaxBitlist struct {
	B1 []byte `ssz-type:"bitlist" ssz-max:"512"`
}

// NamedBitlistT must be detected as a bitlist by its type name, matching
// the reflection typecache heuristic.
type NamedBitlistT []byte

// NamedBitlistContainer references the name-detected bitlist with a limit.
type NamedBitlistContainer struct {
	B NamedBitlistT `ssz-max:"100"`
}

// BitvecEdge covers bitvector edge cases: empty values, byte-aligned
// dynamic bit sizes, and short values for a bit-aligned size.
type BitvecEdge struct {
	BV1 []byte `ssz-type:"bitvector" ssz-bitsize:"16"`
	BV2 []byte `ssz-type:"bitvector" ssz-bitsize:"16" dynssz-bitsize:"BIT_SPEC"`
	BV3 []byte `ssz-type:"bitvector" ssz-bitsize:"12"`
}

// nestedDelegatedInner8 is a second fully-delegated static type with a
// DIFFERENT size (8 bytes) than nestedDelegatedInner (4 bytes). Two shallow
// delegated descriptors must never share a size variable in generated code.
type nestedDelegatedInner8 struct {
	Bad   [0]uint64 // illegal Vector[uint64, 0] if ever traversed
	Value uint64
}

var _ = sszutils.Annotate[nestedDelegatedInner8](`ssz-static:"true"`)

func (n *nestedDelegatedInner8) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return 8 }

func (n *nestedDelegatedInner8) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint64(buf, n.Value), nil
}

func (n *nestedDelegatedInner8) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	n.Value = binary.LittleEndian.Uint64(buf)
	return nil
}

func (n *nestedDelegatedInner8) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint64(n.Value)
	return nil
}

// MixedDelegatedContainer places delegated static fields around a dynamic
// field; each delegated field's region must be sized from its OWN type.
type MixedDelegatedContainer struct {
	A uint64
	B [3]nestedDelegatedInner
	C []uint16 `ssz-max:"8"`
	D nestedDelegatedInner8
	E []byte `ssz-max:"8"`
}

var MixedDelegatedContainer_Payload = MixedDelegatedContainer{
	A: 1,
	B: [3]nestedDelegatedInner{{Value: 2}, {Value: 3}, {Value: 4}},
	C: []uint16{5, 6, 7},
	D: nestedDelegatedInner8{Value: 8},
	E: []byte{9, 10},
}

// UnionDynVariant has a union with a variable-size variant followed by
// another dynamic field; a truncated union region must fail cleanly on the
// stream path (the selector read must not cross into the next region).
type UnionDynVariant struct {
	U dynssz.CompatibleUnion[struct {
		F1 uint32
		F2 []byte `ssz-max:"16"`
	}]
	L []byte `ssz-max:"16"`
}

var UnionDynVariant_Payload = UnionDynVariant{
	U: dynssz.CompatibleUnion[struct {
		F1 uint32
		F2 []byte `ssz-max:"16"`
	}]{Variant: 2, Data: []byte{1, 2, 3}},
	L: []byte{1, 4, 5},
}

// ClassicUnionDynVariant has a classic union (None declared first) with a
// variable-size variant followed by another dynamic field: the None region
// must be exactly the bare selector byte, and a truncated union region must
// fail cleanly on the stream path.
type ClassicUnionDynVariant struct {
	U dynssz.Union[struct {
		N  dynssz.None
		F1 uint32
		F2 []byte `ssz-max:"16"`
	}]
	L []byte `ssz-max:"16"`
}

var ClassicUnionDynVariant_Payload = ClassicUnionDynVariant{
	U: dynssz.Union[struct {
		N  dynssz.None
		F1 uint32
		F2 []byte `ssz-max:"16"`
	}]{Variant: 2, Data: []byte{1, 2, 3}},
	L: []byte{1, 4, 5},
}

// ClassicUnionPtrVariant covers a classic union with a pointer variant — the
// generated decoder must allocate the pointer before writing through it.
type ClassicUnionPtrVariant struct {
	U dynssz.Union[struct {
		V1 uint64
		V2 *uint64
	}]
}

var ClassicUnionPtrVariant_Payload = func() ClassicUnionPtrVariant {
	p := ClassicUnionPtrVariant{}
	p.U.Variant = 1
	p.U.Data = &ptrUnionVal
	return p
}()

// PromotedDelegInner declares a full set of dynamic SSZ methods. A type that
// embeds it inherits those methods by promotion; the codegen parser must treat
// only declared methods as delegation, so PromotedDelegOuter is walked as a
// container (encoding Label) rather than delegating to the promoted methods
// (which would drop Label).
type PromotedDelegInner struct{ Seconds uint16 }

func (p *PromotedDelegInner) SizeSSZDyn(sszutils.DynamicSpecs) int { return 2 }

func (p *PromotedDelegInner) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return append(buf, byte(p.Seconds), byte(p.Seconds>>8)), nil
}

func (p *PromotedDelegInner) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, b []byte) error {
	if len(b) >= 2 {
		p.Seconds = uint16(b[0]) | uint16(b[1])<<8
	}
	return nil
}

func (p *PromotedDelegInner) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint16(p.Seconds)
	return nil
}

type PromotedDelegOuter struct {
	PromotedDelegInner
	Label uint64
}

// GenericBoxFixture is a generic struct used only as a codegen test fixture
// (not listed in any gen_*.yaml, so never generated): an instantiation of it
// must be rejected as a top-level generation target.
type GenericBoxFixture[T any] struct {
	V T
}

// AliasedVecPair holds two short-paddable byte vectors; hashing must pad into
// library-owned buffers so the root stays independent of whether the two
// fields alias one backing array.
type AliasedVecPair struct {
	V []byte `ssz-size:"8"`
	W []byte `ssz-size:"8"`
}

// ShortLargeUintVec uses slice-typed large-uints so the Go value can be
// shorter than the declared width, exercising the zero-padding parity between
// the generated and reflection hash tree roots.
type ShortLargeUintVec struct {
	A []byte   `ssz-type:"uint128" ssz-size:"16"`
	B []uint64 `ssz-type:"uint256" ssz-size:"4"`
}

// UnionTaggedSelectors assigns explicit 1-based selector values via ssz-index
// tags on the union variant fields (EIP-8016 conformant numbering).
type UnionTaggedSelectors struct {
	U dynssz.CompatibleUnion[struct {
		F1 uint32 `ssz-index:"1"`
		F2 []byte `ssz-max:"16" ssz-index:"2"`
	}]
}

var UnionTaggedSelectors_Payload = UnionTaggedSelectors{
	U: dynssz.CompatibleUnion[struct {
		F1 uint32 `ssz-index:"1"`
		F2 []byte `ssz-max:"16" ssz-index:"2"`
	}]{Variant: 1, Data: uint32(7)},
}

// Top-level standalone named composite types generated as -types entries.
// Their generated methods receive the pointer receiver directly, so every
// generator path must dereference it correctly.

type TopLevelBitlist []byte

var _ = sszutils.Annotate[TopLevelBitlist](`ssz-type:"bitlist" ssz-max:"128"`)

type TopLevelProgBitlist []byte

var _ = sszutils.Annotate[TopLevelProgBitlist](`ssz-type:"progressive-bitlist"`)

type TopLevelString string

var _ = sszutils.Annotate[TopLevelString](`ssz-max:"64"`)

type TopLevelCtrList []SimpleTypes1_C1

var _ = sszutils.Annotate[TopLevelCtrList](`ssz-max:"16"`)

type TopLevelCtrVec []SimpleTypes1_C1

var _ = sszutils.Annotate[TopLevelCtrVec](`ssz-size:"4"`)

type TopLevelVarList []OptionalListTypes_Inner

var _ = sszutils.Annotate[TopLevelVarList](`ssz-max:"16"`)

type TopLevelListOfList [][]byte

var _ = sszutils.Annotate[TopLevelListOfList](`ssz-max:"8,32"`)

// TopLevelStructWrapper is a user-declared struct that carries type-wrapper
// semantics through a type-level annotation. A top-level entry has no field
// tag, so the annotation is the only channel available for it.
//
// Wrapper semantics must not be confused with the library's generic
// TypeWrapper/Union, which are nameable only through a transparent alias and
// therefore genuinely cannot receive generated methods. This is an ordinary
// named type and can, so it must generate like any other -types entry.
type TopLevelStructWrapper struct {
	Items []*TopLevelStructWrapperItem `ssz-max:"72"`
}

type TopLevelStructWrapperItem struct {
	Val  uint64
	Tail []byte `ssz-max:"8"`
}

var _ = sszutils.Annotate[TopLevelStructWrapper](`ssz-type:"wrapper"`)

var TopLevelStructWrapper_Payload = TopLevelStructWrapper{
	Items: []*TopLevelStructWrapperItem{
		{Val: 1, Tail: []byte{1, 2, 3}},
		{Val: 2, Tail: []byte{}},
		{Val: 3, Tail: []byte{9}},
	},
}

// TopLevelWrapVarList wraps a variable-element list in a TypeWrapper; the
// streaming size closure must not collide with the wrapper unwrap local.
type TopLevelWrapVarList struct {
	V dynssz.TypeWrapper[struct {
		X []OptionalListTypes_Inner `ssz-max:"8"`
	}, []OptionalListTypes_Inner] `ssz-type:"wrapper"`
}

// PtrUnionVariant covers a CompatibleUnion with a pointer variant, and a
// TypeWrapper whose Data is a pointer — the generated decoder must allocate
// the pointer before writing through it.
type PtrUnionVariant struct {
	U dynssz.CompatibleUnion[struct {
		V1 uint64
		V2 *uint64
	}]
	W dynssz.TypeWrapper[struct{ Data *uint64 }, *uint64] `ssz-type:"wrapper"`
}

var ptrUnionVal = uint64(0xdeadbeef)

var PtrUnionVariant_Payload = func() PtrUnionVariant {
	p := PtrUnionVariant{}
	p.U.Variant = 2
	p.U.Data = &ptrUnionVal
	p.W.Data = &ptrUnionVal
	return p
}()

// --- codegen compile-correctness shapes (pointer-receiver deref, localized
// value naming, pointer-element fast-path guard, zero-padding item typing) ---

// TopVecOfVar is a top-level named vector of variable-size elements; its
// pointer receiver must be parenthesized before indexing in SizeSSZ.
type TopVecOfVar [3][]uint16

var _ = sszutils.Annotate[TopVecOfVar](`ssz-size:"3" ssz-max:"?,8"`)

// UnionSamePkgVariant uses a same-package named type as a union variant.
type UnionSamePkgVariant struct {
	U dynssz.CompatibleUnion[struct {
		V1 uint64
		V2 SimpleTypes1_C1
	}]
}

// ClassicUnionSamePkgVariant uses a same-package named type as a classic
// union variant.
type ClassicUnionSamePkgVariant struct {
	U dynssz.Union[struct {
		V1 uint64
		V2 SimpleTypes1_C1
	}]
}

// PtrPrimitiveList is a list of pointer-to-primitive; the bulk uint64
// fast-path must not fire for pointer elements.
type PtrPrimitiveList struct {
	F []*uint64 `ssz-max:"3"`
}

// FixedVecPtrStr / FixedVecPtrList / FixedVecStr exercise the under-fill
// zero-padding item for pointer, string and list elements.
type FixedVecPtrStr struct {
	F []*string `ssz-size:"2" ssz-max:"?,8"`
}
type FixedVecPtrList struct {
	F []*[]uint16 `ssz-size:"2" ssz-max:"?,4"`
}
type FixedVecStr struct {
	F []string `ssz-size:"2" ssz-max:"?,8"`
}

// PtrDynCollectionField is a pointer to a dynamic collection; its SizeSSZ
// must not double-declare the localized value.
type PtrDynCollectionField struct {
	F *[][]byte `ssz-max:"3,10" ssz-type:"?,bitlist"`
}

// WrapUnionField wraps a CompatibleUnion; the streaming size closure must
// not collide with its parameter name.
type WrapUnionField struct {
	W dynssz.TypeWrapper[struct {
		Data dynssz.CompatibleUnion[struct {
			A uint32
			B []byte `ssz-max:"4"`
		}]
	}, dynssz.CompatibleUnion[struct {
		A uint32
		B []byte `ssz-max:"4"`
	}]] `ssz-type:"wrapper"`
}

// WrapClassicUnionField wraps a classic Union; the streaming size closure
// must not collide with its parameter name.
type WrapClassicUnionField struct {
	W dynssz.TypeWrapper[struct {
		Data dynssz.Union[struct {
			N dynssz.None
			A uint32
		}]
	}, dynssz.Union[struct {
		N dynssz.None
		A uint32
	}]] `ssz-type:"wrapper"`
}

// ExcludedFields exercises ssz-type:"-": excluded fields are omitted from the
// SSZ layout entirely (not encoded, decoded, sized or hashed) and may hold
// non-SSZ types.
type ExcludedFields struct {
	A     uint32
	Cache [32]byte `ssz-type:"-"`
	B     uint64
	Meta  map[string]int `ssz-type:"-"`
	L     []uint16       `ssz-max:"8"`
}

var ExcludedFields_Payload = ExcludedFields{
	A:     1,
	Cache: [32]byte{9, 9, 9},
	B:     2,
	Meta:  map[string]int{"x": 1},
	L:     []uint16{3, 4},
}

// PtrSvecOfList is a pointer to a fixed vector of variable-size elements; the
// streaming encoder's under-fill zero-padding item must be the element type,
// not new(element) (which would be a pointer to it).
type PtrSvecOfList struct {
	F *[][]uint16 `ssz-size:"2" ssz-max:"?,4"`
}

// WrapPtrList wraps a pointer type; the size closure's nil-pointer guard must
// localize into a fresh variable instead of shadowing the closure's own
// parameter.
type WrapPtrList struct {
	W dynssz.TypeWrapper[struct {
		Data *[]uint16 `ssz-max:"8"`
	}, *[]uint16] `ssz-type:"wrapper"`
}

// WideDynamicElement makes eager allocation from an offset-table count visible:
// its SSZ body is dynamic, while every Go value contains substantial inline
// storage. WideDynamicList is used to pin byte-bounded preallocation in the
// generated streaming decoder.
type WideDynamicElement struct {
	Fixed [64 << 10]byte
	Tail  []byte `ssz-max:"1"`
}

type WideDynamicList struct {
	Items []WideDynamicElement `ssz-max:"512"`
}

// RecursiveNode is a self-referential container: recursion through a bounded
// list is a legal, finite SSZ shape. The generated code must call the type's
// own methods for the recursive reference so emission and encoding terminate.
type RecursiveNode struct {
	Val      uint64
	Children []*RecursiveNode `ssz-max:"4"`
}

var RecursiveNode_Payload = RecursiveNode{
	Val: 1,
	Children: []*RecursiveNode{
		{Val: 2},
		{Val: 3, Children: []*RecursiveNode{{Val: 4}}},
	},
}

// RecursiveTree and RecursiveTreeBranch form a cycle that closes through a
// container field (Branch.Leaf) rather than a list element, with a
// spec-dependent limit inside the cycle. Both members generate methods, so the
// recursive references delegate; the spec-dependence must reach every cycle
// member so neither engine falls back to preset-baking fastssz paths.
type RecursiveTree struct {
	Depth    uint64
	Branches []RecursiveTreeBranch `ssz-max:"4" dynssz-max:"RECURSIVE_BRANCH_LIMIT"`
}

type RecursiveTreeBranch struct {
	Leaf *RecursiveTree
}

var RecursiveTree_Specs = map[string]any{
	"RECURSIVE_BRANCH_LIMIT": uint64(8),
}

// RecursiveViewNode is a recursive type generated with a view. A view builds
// the data type against a schema type, which is not a cacheable build, so it
// exercises the cycle detection on the hinted build path -- without it the
// generator recursed until the stack was gone.
//
// The view methods have to carry the nesting depth like the base ones: a view
// of a cyclic type is still cyclic, and a view method entering at depth zero
// would restart the count halfway round the cycle.
type RecursiveViewNode struct {
	Val      uint64
	Children []*RecursiveViewNode `ssz-max:"4"`
}

// RecursiveViewNode_View1 views the same shape with a tighter child limit, so
// the view has its own descriptor graph and its own cycle.
type RecursiveViewNode_View1 struct {
	Val      uint64
	Children []*RecursiveViewNode_View1 `ssz-max:"2"`
}

var RecursiveViewNode_Payload = RecursiveViewNode{
	Val: 1,
	Children: []*RecursiveViewNode{
		{Val: 2, Children: []*RecursiveViewNode{{Val: 3}}},
	},
}

var RecursiveTree_Payload = RecursiveTree{
	Depth: 1,
	Branches: []RecursiveTreeBranch{
		{Leaf: nil},
		{Leaf: &RecursiveTree{
			Depth:    2,
			Branches: []RecursiveTreeBranch{{Leaf: nil}},
		}},
	},
}

// StreamVecDynSize is a fixed-size vector (slice with ssz-size + dynssz-size) of
// variable-size elements. With -with-streaming the decoder emits a first-offset
// check `startOffset != <limit>*4`; when the limit is a dynssz expression the
// limit renders as a typed int(expr), so the comparison against the uint32
// startOffset must be uint32-converted or the generated code fails to compile.
type StreamVecDynSize struct {
	V []StreamVecElem `ssz-size:"2" dynssz-size:"STREAMVEC_LEN"`
}

type StreamVecElem struct {
	X []byte `ssz-max:"8"`
}

// OversizedArrayDynVec holds Go arrays longer than their declared vector
// length whose elements are variable-size: only the declared length is
// encoded, sized and hashed, and both engines must agree on that.
type OversizedArrayDynVec struct {
	P [8]*StreamVecElem `ssz-size:"4"`
	V [8]StreamVecElem  `ssz-size:"4"`
}

var OversizedArrayDynVec_Payload = func() OversizedArrayDynVec {
	var v OversizedArrayDynVec
	for i := range v.P {
		v.P[i] = &StreamVecElem{X: []byte{byte(i), byte(i)}}
		v.V[i] = StreamVecElem{X: []byte{byte(i)}}
	}
	return v
}()

var StreamVecDynSize_Specs = map[string]any{
	"STREAMVEC_LEN": uint64(2),
}

var StreamVecDynSize_Payload = StreamVecDynSize{
	V: []StreamVecElem{
		{X: []byte{1, 2, 3}},
		{X: []byte{4, 5}},
	},
}

// SizeUnionExprVariant has a compatible-union whose second variant is an inline
// container sized entirely by a size expression (a fixed-size string with a
// dynssz-size). The SizeSSZ generator asserts the variant value but the
// expression-only size never reads it, which must not leave the asserted
// variable declared-and-unused in the generated code.
type SizeUnionExprVariant struct {
	U dynssz.CompatibleUnion[struct {
		A uint32
		B struct {
			S string `ssz-size:"8" dynssz-size:"SUEV_LEN"`
		}
	}]
}

var SizeUnionExprVariant_Specs = map[string]any{
	"SUEV_LEN": uint64(8),
}

var SizeUnionExprVariant_Payload = SizeUnionExprVariant{
	U: dynssz.CompatibleUnion[struct {
		A uint32
		B struct {
			S string `ssz-size:"8" dynssz-size:"SUEV_LEN"`
		}
	}]{
		Variant: 2,
		Data: struct {
			S string `ssz-size:"8" dynssz-size:"SUEV_LEN"`
		}{S: "abcdefgh"},
	},
}

// DynSizeVectorNoStatic covers slices whose length is fixed purely by a
// dynssz-size expression, with no static ssz-size fallback. The reflection
// typecache resolves the expression to a concrete size and classifies the slice
// as a Vector; the codegen parser has no spec values at generation time and must
// reach the same classification from the presence of the expression alone.
// Previously the generator saw a static size of 0 and mis-encoded the field as a
// variable List (a 4-byte offset plus contents), diverging from reflection and
// the SSZ spec on size, serialization and hash tree root. AV additionally nests
// the dynssz-only inner vector under a fixed outer array whose dimension is the
// '?' placeholder.
type DynSizeVectorNoStatic struct {
	V  []uint16    `dynssz-size:"DSV_LEN"`
	AV [2][]uint16 `dynssz-size:"?,DSV_LEN"`
}

var DynSizeVectorNoStatic_Specs = map[string]any{
	"DSV_LEN": uint64(3),
}

func DynSizeVectorNoStaticPayload(n int) DynSizeVectorNoStatic {
	v := make([]uint16, n)
	for i := range v {
		v[i] = uint16(i + 1)
	}
	var av [2][]uint16
	for r := range av {
		row := make([]uint16, n)
		for i := range row {
			row[i] = uint16(r*100 + i + 1)
		}
		av[r] = row
	}
	return DynSizeVectorNoStatic{V: v, AV: av}
}

// ---------------------------------------------------------------------------
// Attack shapes for the without-dynamic-expressions static/inlining path.
// All generated with -with-streaming -without-fastssz -without-dynamic-expressions
// -with-extended-types (gen_atknest.yaml). Every parent must reach nested
// generated children through their static methods (never a *Dyn buffer call)
// and must round-trip byte/size/root-identical to reflection.
// ---------------------------------------------------------------------------

// AtkNestLeaf is a variable-size leaf container nested at several depths.
type AtkNestLeaf struct {
	A []byte `ssz-max:"8"`
	B uint8
}

// AtkNestD3/D2/D1 build a depth-4 chain of variable-size containers-of-containers
// mixing list, vector, and progressive-list nesting.
type AtkNestD3 struct {
	L AtkNestLeaf
	V [2]AtkNestLeaf
	X uint16
}
type AtkNestD2 struct {
	N AtkNestD3
	L []AtkNestD3 `ssz-max:"4"`
}
type AtkNestD1 struct {
	N AtkNestD2
	P []AtkNestD2 `ssz-type:"progressive-list" ssz-max:"8"`
	Z uint64
}

// AtkNestUnion nests generated containers as union variants.
type AtkNestUnion struct {
	U dynssz.CompatibleUnion[struct {
		F1 AtkNestLeaf
		F2 AtkNestD2
	}]
}

// AtkNestWrapper wraps a nested generated container in a TypeWrapper.
type AtkNestWrapper struct {
	W dynssz.TypeWrapper[struct {
		Data AtkNestD2 `ssz-size:"?"`
	}, AtkNestD2]
}

// AtkNestOpt / AtkNestOptList nest a generated container behind an optional and
// an optional-list pointer.
type AtkNestOpt struct {
	Opt *AtkNestD2 `ssz-type:"optional"`
	N   uint16
}
type AtkNestOptList struct {
	Opt *AtkNestD2 `ssz-type:"optional-list"`
}

var (
	atkNestLeafA = AtkNestLeaf{A: []byte{1, 2, 3}, B: 7}
	atkNestLeafB = AtkNestLeaf{A: nil, B: 0}
	atkNestD3v   = AtkNestD3{L: atkNestLeafA, V: [2]AtkNestLeaf{atkNestLeafA, atkNestLeafB}, X: 9}
	atkNestD2v   = AtkNestD2{N: atkNestD3v, L: []AtkNestD3{atkNestD3v, atkNestD3v}}

	AtkNestD1_Payload = AtkNestD1{
		N: atkNestD2v,
		P: []AtkNestD2{atkNestD2v, atkNestD2v},
		Z: 0xdeadbeef,
	}
	AtkNestUnion_Payload = AtkNestUnion{U: dynssz.CompatibleUnion[struct {
		F1 AtkNestLeaf
		F2 AtkNestD2
	}]{Variant: 1, Data: atkNestLeafA}}
	AtkNestWrapper_Payload = AtkNestWrapper{W: dynssz.TypeWrapper[struct {
		Data AtkNestD2 `ssz-size:"?"`
	}, AtkNestD2]{Data: atkNestD2v}}
	AtkNestOpt_Payload     = AtkNestOpt{Opt: &atkNestD2v, N: 4321}
	AtkNestOptList_Payload = AtkNestOptList{Opt: &atkNestD2v}
)

// atkWellDelegated is an external fully-delegated type whose Go struct layout
// matches its wire form exactly (a single uint64 field). Under
// without-dynamic-expressions the parser (NoDelegation) traverses it and the
// static generators inline its structure. The inlined static encoding must be
// byte/root-identical to what its own Dynamic* methods produce.
type atkWellDelegated struct {
	V uint64
}

var _ = sszutils.Annotate[atkWellDelegated](`ssz-static:"true"`)

func (n *atkWellDelegated) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return 8 }
func (n *atkWellDelegated) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint64(buf, n.V), nil
}
func (n *atkWellDelegated) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	n.V = binary.LittleEndian.Uint64(buf)
	return nil
}
func (n *atkWellDelegated) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint64(n.V)
	return nil
}

// AtkWellHolder nests the well-behaved delegated type as a static field and a
// vector; generated statically it inlines the delegated type's structure.
type AtkWellHolder struct {
	A uint64
	N atkWellDelegated
	V [2]atkWellDelegated
}

var AtkWellHolder_Payload = AtkWellHolder{
	A: 0x1122334455667788,
	N: atkWellDelegated{V: 0x99},
	V: [2]atkWellDelegated{{V: 0xaa}, {V: 0xbb}},
}

// RecursiveInlineHolder closes a cycle through RecursiveInlineMember, which is
// deliberately left out of the generation set: the member's structure is
// inlined into the holder's generated methods, so the level it counts against
// the nesting bound has to be charged inline rather than at a method boundary.
type RecursiveInlineHolder struct {
	Val  uint64
	Next RecursiveInlineMember
}

// RecursiveInlineMember carries the cycle back to the holder. It has no
// generated methods of its own by design (see RecursiveInlineHolder).
type RecursiveInlineMember struct {
	Links []*RecursiveInlineHolder `ssz-max:"4"`
}

var RecursiveInlineHolder_Payload = RecursiveInlineHolder{
	Val: 7,
	Next: RecursiveInlineMember{
		Links: []*RecursiveInlineHolder{
			{Val: 8},
			{Val: 9, Next: RecursiveInlineMember{Links: []*RecursiveInlineHolder{{Val: 10}}}},
		},
	},
}

// NoDynRecursiveNode closes a cycle under the static-only combination: its
// walk body carries depth charges and twin calls, so the static
// HashTreeRootWith has to be a depth twin like its marshal siblings — the
// combination that once emitted references to a twin nothing generated.
type NoDynRecursiveNode struct {
	Val      uint64
	Children []*NoDynRecursiveNode `ssz-max:"4"`
}

// NoDynRecursiveHolder threads the depth through a type that is not on the
// cycle itself, still without dynamic expressions.
type NoDynRecursiveHolder struct {
	Tag  uint32
	Node NoDynRecursiveNode
}

var NoDynRecursiveHolder_Payload = NoDynRecursiveHolder{
	Tag: 3,
	Node: NoDynRecursiveNode{
		Val: 1,
		Children: []*NoDynRecursiveNode{
			{Val: 2},
			{Val: 3, Children: []*NoDynRecursiveNode{{Val: 4}}},
		},
	},
}

// RecursiveOptNode closes a cycle through an optional edge. Both engines
// charge the same levels per trip, so a chain rejected by one engine at a
// given depth is rejected by the other at that depth.
type RecursiveOptNode struct {
	Val  uint64
	Next *RecursiveOptNode `ssz-type:"optional"`
}

var RecursiveOptNode_Payload = RecursiveOptNode{
	Val: 1,
	Next: &RecursiveOptNode{
		Val:  2,
		Next: &RecursiveOptNode{Val: 3},
	},
}

// ReflectOptProbe carries every optional shape through the reflect front-end:
// optional of a basic type, of a container, and a recursive optional edge.
// It is deliberately in no generation batch; a test generates it through
// WithReflectType and type-checks the output.
type ReflectOptProbe struct {
	A *uint64          `ssz-type:"optional"`
	B *ReflectOptSub   `ssz-type:"optional"`
	C *ReflectOptProbe `ssz-type:"optional"`
	D *ReflectOptSub   `ssz-type:"optional-list"`
}

// ReflectOptSub is the container variant ReflectOptProbe wraps.
type ReflectOptSub struct {
	V uint64
}

// RecursiveValNode closes a cycle through a list whose element is the
// recursive struct by value. Both engines charge the same levels per trip,
// whichever way the element is held.
type RecursiveValNode struct {
	Val  uint64
	Kids []RecursiveValNode `ssz-max:"4"`
}

var RecursiveValNode_Payload = RecursiveValNode{
	Val: 1,
	Kids: []RecursiveValNode{
		{Val: 2},
		{Val: 3, Kids: []RecursiveValNode{{Val: 4}}},
	},
}

// TaggedWrapperType is a named wrapper used to pin that a size tag on the
// field holding it is rejected.
type TaggedWrapperType = dynssz.TypeWrapper[struct {
	Data []uint16 `ssz-max:"16"`
}, []uint16]

// WrapperFieldTagHolder tags the field holding a wrapper; the tag is rejected
// because the wrapper's descriptor struct declares its constraints.
type WrapperFieldTagHolder struct {
	W TaggedWrapperType `ssz-size:"4"`
}

// Descriptor-hash parity fixtures: intentionally not covered by any generation
// preset, so both descriptor front-ends traverse the full graph instead of
// shallow-building a delegated type.
type HashParityNode struct {
	Val      uint64
	Children []*HashParityNode `ssz-max:"4"`
}

type HashParityShapes struct {
	Num    uint64
	List   []uint32    `ssz-max:"64" dynssz-max:"PARITY_LIMIT"`
	VecDyn [3][]uint16 `ssz-max:"?,64"`
	Opt    *uint64
	Union  dynssz.CompatibleUnion[struct {
		A uint32
		B []byte `ssz-max:"4"`
	}]
	Classic dynssz.Union[struct {
		N dynssz.None
		A uint32
	}]
	Node HashParityNode
}

type HashParityProg struct {
	A uint8  `ssz-index:"0"`
	B uint64 `ssz-index:"3"`
}

type HashParityWrap struct {
	W dynssz.TypeWrapper[struct {
		Data []uint8 `ssz-max:"8"`
	}, []uint8] `ssz-type:"wrapper"`
}

// GenCovBranches exercises generator branches no other fixture reaches: bulk
// fixed-byte collections, limits past the int32 range, spec-sized strings and
// bit sizes, duplicate hinted shapes, wrapper-borne static sizes, and a
// fastssz-only child in the streaming decoder.
type GenCovBranches struct {
	RootsVec  [][32]byte `ssz-size:"4"`
	RootsList [][32]byte `ssz-max:"64"`
	HugeLimit []uint64   `ssz-max:"1099511627776"`
	SpecStr   string     `dynssz-size:"TEST_SPEC"`
	Bits2     []byte     `ssz-type:"bitvector" ssz-bitsize:"30"`
	BitsArr   [4]byte    `ssz-type:"bitvector" ssz-bitsize:"30"`
	HintA     []byte     `ssz-size:"32" dynssz-size:"SPEC_A"`
	HintB     []byte     `ssz-size:"32" dynssz-size:"SPEC_B"`
	Fast      CustomType1
	WrapSpec  dynssz.TypeWrapper[struct {
		Data []byte `ssz-size:"32" dynssz-size:"TEST_SPEC"`
	}, []byte] `ssz-type:"wrapper"`
	UnionList []dynssz.CompatibleUnion[struct {
		V1 uint64
		V2 []byte `ssz-max:"8"`
	}] `ssz-max:"8"`
	SpecVecList [][2]genCovSpecInner `ssz-max:"8"`
	VecOfList   [][2][]uint8         `ssz-max:"8,?,4"`
	Dyn         []byte               `ssz-max:"32"`
}

// genCovSpecInner is a dynamic container with a spec-sized static part, so
// the list region bound over vectors of it groups a compound minimum.
type genCovSpecInner struct {
	A []byte `ssz-size:"4" dynssz-size:"TEST_SPEC"`
	B []byte `ssz-max:"4"`
}

// GenCovCustomHolder pairs a fastssz-only custom field with a dynamic
// sibling; generated without fastssz, every generator emits its custom-type
// return.
type GenCovCustomHolder struct {
	C CustomType1 `ssz-type:"custom"`
	D []byte      `ssz-max:"8"`
}

// GenCovWideOffsets carries enough consecutive dynamic fields that the
// grouped offset reservation exceeds the bulk-padding threshold.
type GenCovWideOffsets struct {
	F000 []byte `ssz-max:"4"`
	F001 []byte `ssz-max:"4"`
	F002 []byte `ssz-max:"4"`
	F003 []byte `ssz-max:"4"`
	F004 []byte `ssz-max:"4"`
	F005 []byte `ssz-max:"4"`
	F006 []byte `ssz-max:"4"`
	F007 []byte `ssz-max:"4"`
	F008 []byte `ssz-max:"4"`
	F009 []byte `ssz-max:"4"`
	F010 []byte `ssz-max:"4"`
	F011 []byte `ssz-max:"4"`
	F012 []byte `ssz-max:"4"`
	F013 []byte `ssz-max:"4"`
	F014 []byte `ssz-max:"4"`
	F015 []byte `ssz-max:"4"`
	F016 []byte `ssz-max:"4"`
	F017 []byte `ssz-max:"4"`
	F018 []byte `ssz-max:"4"`
	F019 []byte `ssz-max:"4"`
	F020 []byte `ssz-max:"4"`
	F021 []byte `ssz-max:"4"`
	F022 []byte `ssz-max:"4"`
	F023 []byte `ssz-max:"4"`
	F024 []byte `ssz-max:"4"`
	F025 []byte `ssz-max:"4"`
	F026 []byte `ssz-max:"4"`
	F027 []byte `ssz-max:"4"`
	F028 []byte `ssz-max:"4"`
	F029 []byte `ssz-max:"4"`
	F030 []byte `ssz-max:"4"`
	F031 []byte `ssz-max:"4"`
	F032 []byte `ssz-max:"4"`
	F033 []byte `ssz-max:"4"`
	F034 []byte `ssz-max:"4"`
	F035 []byte `ssz-max:"4"`
	F036 []byte `ssz-max:"4"`
	F037 []byte `ssz-max:"4"`
	F038 []byte `ssz-max:"4"`
	F039 []byte `ssz-max:"4"`
	F040 []byte `ssz-max:"4"`
	F041 []byte `ssz-max:"4"`
	F042 []byte `ssz-max:"4"`
	F043 []byte `ssz-max:"4"`
	F044 []byte `ssz-max:"4"`
	F045 []byte `ssz-max:"4"`
	F046 []byte `ssz-max:"4"`
	F047 []byte `ssz-max:"4"`
	F048 []byte `ssz-max:"4"`
	F049 []byte `ssz-max:"4"`
	F050 []byte `ssz-max:"4"`
	F051 []byte `ssz-max:"4"`
	F052 []byte `ssz-max:"4"`
	F053 []byte `ssz-max:"4"`
	F054 []byte `ssz-max:"4"`
	F055 []byte `ssz-max:"4"`
	F056 []byte `ssz-max:"4"`
	F057 []byte `ssz-max:"4"`
	F058 []byte `ssz-max:"4"`
	F059 []byte `ssz-max:"4"`
	F060 []byte `ssz-max:"4"`
	F061 []byte `ssz-max:"4"`
	F062 []byte `ssz-max:"4"`
	F063 []byte `ssz-max:"4"`
	F064 []byte `ssz-max:"4"`
	F065 []byte `ssz-max:"4"`
	F066 []byte `ssz-max:"4"`
	F067 []byte `ssz-max:"4"`
	F068 []byte `ssz-max:"4"`
	F069 []byte `ssz-max:"4"`
	F070 []byte `ssz-max:"4"`
	F071 []byte `ssz-max:"4"`
	F072 []byte `ssz-max:"4"`
	F073 []byte `ssz-max:"4"`
	F074 []byte `ssz-max:"4"`
	F075 []byte `ssz-max:"4"`
	F076 []byte `ssz-max:"4"`
	F077 []byte `ssz-max:"4"`
	F078 []byte `ssz-max:"4"`
	F079 []byte `ssz-max:"4"`
	F080 []byte `ssz-max:"4"`
	F081 []byte `ssz-max:"4"`
	F082 []byte `ssz-max:"4"`
	F083 []byte `ssz-max:"4"`
	F084 []byte `ssz-max:"4"`
	F085 []byte `ssz-max:"4"`
	F086 []byte `ssz-max:"4"`
	F087 []byte `ssz-max:"4"`
	F088 []byte `ssz-max:"4"`
	F089 []byte `ssz-max:"4"`
	F090 []byte `ssz-max:"4"`
	F091 []byte `ssz-max:"4"`
	F092 []byte `ssz-max:"4"`
	F093 []byte `ssz-max:"4"`
	F094 []byte `ssz-max:"4"`
	F095 []byte `ssz-max:"4"`
	F096 []byte `ssz-max:"4"`
	F097 []byte `ssz-max:"4"`
	F098 []byte `ssz-max:"4"`
	F099 []byte `ssz-max:"4"`
	F100 []byte `ssz-max:"4"`
	F101 []byte `ssz-max:"4"`
	F102 []byte `ssz-max:"4"`
	F103 []byte `ssz-max:"4"`
	F104 []byte `ssz-max:"4"`
	F105 []byte `ssz-max:"4"`
	F106 []byte `ssz-max:"4"`
	F107 []byte `ssz-max:"4"`
	F108 []byte `ssz-max:"4"`
	F109 []byte `ssz-max:"4"`
	F110 []byte `ssz-max:"4"`
	F111 []byte `ssz-max:"4"`
	F112 []byte `ssz-max:"4"`
	F113 []byte `ssz-max:"4"`
	F114 []byte `ssz-max:"4"`
	F115 []byte `ssz-max:"4"`
	F116 []byte `ssz-max:"4"`
	F117 []byte `ssz-max:"4"`
	F118 []byte `ssz-max:"4"`
	F119 []byte `ssz-max:"4"`
	F120 []byte `ssz-max:"4"`
	F121 []byte `ssz-max:"4"`
	F122 []byte `ssz-max:"4"`
	F123 []byte `ssz-max:"4"`
	F124 []byte `ssz-max:"4"`
	F125 []byte `ssz-max:"4"`
	F126 []byte `ssz-max:"4"`
	F127 []byte `ssz-max:"4"`
	F128 []byte `ssz-max:"4"`
	F129 []byte `ssz-max:"4"`
	F130 []byte `ssz-max:"4"`
	F131 []byte `ssz-max:"4"`
	F132 []byte `ssz-max:"4"`
	F133 []byte `ssz-max:"4"`
	F134 []byte `ssz-max:"4"`
	F135 []byte `ssz-max:"4"`
	F136 []byte `ssz-max:"4"`
	F137 []byte `ssz-max:"4"`
	F138 []byte `ssz-max:"4"`
	F139 []byte `ssz-max:"4"`
	F140 []byte `ssz-max:"4"`
	F141 []byte `ssz-max:"4"`
	F142 []byte `ssz-max:"4"`
	F143 []byte `ssz-max:"4"`
	F144 []byte `ssz-max:"4"`
	F145 []byte `ssz-max:"4"`
	F146 []byte `ssz-max:"4"`
	F147 []byte `ssz-max:"4"`
	F148 []byte `ssz-max:"4"`
	F149 []byte `ssz-max:"4"`
	F150 []byte `ssz-max:"4"`
	F151 []byte `ssz-max:"4"`
	F152 []byte `ssz-max:"4"`
	F153 []byte `ssz-max:"4"`
	F154 []byte `ssz-max:"4"`
	F155 []byte `ssz-max:"4"`
	F156 []byte `ssz-max:"4"`
	F157 []byte `ssz-max:"4"`
	F158 []byte `ssz-max:"4"`
	F159 []byte `ssz-max:"4"`
	F160 []byte `ssz-max:"4"`
	F161 []byte `ssz-max:"4"`
	F162 []byte `ssz-max:"4"`
	F163 []byte `ssz-max:"4"`
	F164 []byte `ssz-max:"4"`
	F165 []byte `ssz-max:"4"`
	F166 []byte `ssz-max:"4"`
	F167 []byte `ssz-max:"4"`
	F168 []byte `ssz-max:"4"`
	F169 []byte `ssz-max:"4"`
	F170 []byte `ssz-max:"4"`
	F171 []byte `ssz-max:"4"`
	F172 []byte `ssz-max:"4"`
	F173 []byte `ssz-max:"4"`
	F174 []byte `ssz-max:"4"`
	F175 []byte `ssz-max:"4"`
	F176 []byte `ssz-max:"4"`
	F177 []byte `ssz-max:"4"`
	F178 []byte `ssz-max:"4"`
	F179 []byte `ssz-max:"4"`
	F180 []byte `ssz-max:"4"`
	F181 []byte `ssz-max:"4"`
	F182 []byte `ssz-max:"4"`
	F183 []byte `ssz-max:"4"`
	F184 []byte `ssz-max:"4"`
	F185 []byte `ssz-max:"4"`
	F186 []byte `ssz-max:"4"`
	F187 []byte `ssz-max:"4"`
	F188 []byte `ssz-max:"4"`
	F189 []byte `ssz-max:"4"`
	F190 []byte `ssz-max:"4"`
	F191 []byte `ssz-max:"4"`
	F192 []byte `ssz-max:"4"`
	F193 []byte `ssz-max:"4"`
	F194 []byte `ssz-max:"4"`
	F195 []byte `ssz-max:"4"`
	F196 []byte `ssz-max:"4"`
	F197 []byte `ssz-max:"4"`
	F198 []byte `ssz-max:"4"`
	F199 []byte `ssz-max:"4"`
	F200 []byte `ssz-max:"4"`
	F201 []byte `ssz-max:"4"`
	F202 []byte `ssz-max:"4"`
	F203 []byte `ssz-max:"4"`
	F204 []byte `ssz-max:"4"`
	F205 []byte `ssz-max:"4"`
	F206 []byte `ssz-max:"4"`
	F207 []byte `ssz-max:"4"`
	F208 []byte `ssz-max:"4"`
	F209 []byte `ssz-max:"4"`
	F210 []byte `ssz-max:"4"`
	F211 []byte `ssz-max:"4"`
	F212 []byte `ssz-max:"4"`
	F213 []byte `ssz-max:"4"`
	F214 []byte `ssz-max:"4"`
	F215 []byte `ssz-max:"4"`
	F216 []byte `ssz-max:"4"`
	F217 []byte `ssz-max:"4"`
	F218 []byte `ssz-max:"4"`
	F219 []byte `ssz-max:"4"`
	F220 []byte `ssz-max:"4"`
	F221 []byte `ssz-max:"4"`
	F222 []byte `ssz-max:"4"`
	F223 []byte `ssz-max:"4"`
	F224 []byte `ssz-max:"4"`
	F225 []byte `ssz-max:"4"`
	F226 []byte `ssz-max:"4"`
	F227 []byte `ssz-max:"4"`
	F228 []byte `ssz-max:"4"`
	F229 []byte `ssz-max:"4"`
	F230 []byte `ssz-max:"4"`
	F231 []byte `ssz-max:"4"`
	F232 []byte `ssz-max:"4"`
	F233 []byte `ssz-max:"4"`
	F234 []byte `ssz-max:"4"`
	F235 []byte `ssz-max:"4"`
	F236 []byte `ssz-max:"4"`
	F237 []byte `ssz-max:"4"`
	F238 []byte `ssz-max:"4"`
	F239 []byte `ssz-max:"4"`
	F240 []byte `ssz-max:"4"`
	F241 []byte `ssz-max:"4"`
	F242 []byte `ssz-max:"4"`
	F243 []byte `ssz-max:"4"`
	F244 []byte `ssz-max:"4"`
	F245 []byte `ssz-max:"4"`
	F246 []byte `ssz-max:"4"`
	F247 []byte `ssz-max:"4"`
	F248 []byte `ssz-max:"4"`
	F249 []byte `ssz-max:"4"`
	F250 []byte `ssz-max:"4"`
	F251 []byte `ssz-max:"4"`
	F252 []byte `ssz-max:"4"`
	F253 []byte `ssz-max:"4"`
	F254 []byte `ssz-max:"4"`
	F255 []byte `ssz-max:"4"`
	F256 []byte `ssz-max:"4"`
}

// streamOnlyCustom carries the fastssz set plus only the streaming-flavored
// dynamic methods: the dynamic flags unforce the fastssz delegation, so the
// buffer generators fall through to their custom-type returns while the
// streaming generators delegate.
type streamOnlyCustom struct{ A uint32 }

func (e *streamOnlyCustom) MarshalSSZ() ([]byte, error) {
	return e.MarshalSSZTo(nil)
}

func (e *streamOnlyCustom) MarshalSSZTo(buf []byte) ([]byte, error) {
	return sszutils.MarshalUint32(buf, e.A), nil
}

func (e *streamOnlyCustom) SizeSSZ() int { return 4 }

func (e *streamOnlyCustom) UnmarshalSSZ(data []byte) error {
	e.A = sszutils.UnmarshallUint32(data)
	return nil
}

func (e *streamOnlyCustom) HashTreeRoot() ([32]byte, error) {
	return [32]byte{}, nil
}

func (e *streamOnlyCustom) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return 4 }

func (e *streamOnlyCustom) MarshalSSZEncoder(_ sszutils.DynamicSpecs, enc sszutils.Encoder) error {
	enc.EncodeUint32(e.A)
	return nil
}

func (e *streamOnlyCustom) UnmarshalSSZDecoder(_ sszutils.DynamicSpecs, dec sszutils.Decoder) error {
	v, err := dec.DecodeUint32()
	e.A = v
	return err
}

func (e *streamOnlyCustom) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, _ sszutils.HashWalker) error {
	return nil
}

// bufOnlyCustom mirrors streamOnlyCustom with only the buffer-flavored
// dynamic methods, so the streaming generators fall through instead.
type bufOnlyCustom struct{ A uint32 }

func (e *bufOnlyCustom) MarshalSSZ() ([]byte, error) {
	return e.MarshalSSZTo(nil)
}

func (e *bufOnlyCustom) MarshalSSZTo(buf []byte) ([]byte, error) {
	return sszutils.MarshalUint32(buf, e.A), nil
}

func (e *bufOnlyCustom) SizeSSZ() int { return 4 }

func (e *bufOnlyCustom) UnmarshalSSZ(data []byte) error {
	e.A = sszutils.UnmarshallUint32(data)
	return nil
}

func (e *bufOnlyCustom) HashTreeRoot() ([32]byte, error) {
	return [32]byte{}, nil
}

func (e *bufOnlyCustom) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return 4 }

func (e *bufOnlyCustom) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return sszutils.MarshalUint32(buf, e.A), nil
}

func (e *bufOnlyCustom) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, data []byte) error {
	e.A = sszutils.UnmarshallUint32(data)
	return nil
}

func (e *bufOnlyCustom) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, _ sszutils.HashWalker) error {
	return nil
}

// GenCovCustomHolder2 pairs stream-only, buffer-only and statically sized
// fastssz-only custom fields with a dynamic sibling, driving each generator
// through its delegation fallbacks.
type GenCovCustomHolder2 struct {
	C  streamOnlyCustom `ssz-type:"custom"`
	CB bufOnlyCustom    `ssz-type:"custom"`
	CS CustomType1      `ssz-type:"custom" ssz-size:"8"`
	D  []byte           `ssz-max:"8"`
}

// namedCovBytes is unwrapped against the plain view schema field.
type namedCovBytes []byte

// aliasCovBytes is unaliased against the plain view schema field.
type aliasCovBytes = []byte

// View-mix bases: ChildA keeps only the buffer-flavored view methods, ChildB
// only the streaming-flavored ones, so the holder generators exercise the
// cross-flavored delegation branches.
type ViewMixChildA struct {
	X []byte `ssz-max:"8"`
	Y uint32
}

type ViewMixChildB struct {
	X []byte `ssz-max:"8"`
	Z uint64
}

type ViewMixHolder struct {
	A ViewMixChildA
	B ViewMixChildB
	C ViewMixChildC
	E ViewMixChildD
	N namedCovBytes `ssz-max:"8"`
	L aliasCovBytes `ssz-max:"8"`
	U dynssz.CompatibleUnion[struct {
		V1 uint64
		V2 ViewMixChildA
	}]
	D []byte `ssz-max:"8"`
}

type ViewMixChildA_View struct {
	X []byte `ssz-max:"8"`
	Y uint32
}

type ViewMixChildB_View struct {
	X []byte `ssz-max:"8"`
	Z uint64
}

// ViewMixChildC is fully static, so the sized delegate-buffer branches run
// for its buffer-only view methods.
type ViewMixChildC struct {
	Y uint32
	Z uint64
}

type ViewMixChildC_View struct {
	Y uint32
	Z uint64
}

// ViewMixChildD is static with a spec-sized field, so its buffer-only view
// delegate is framed at the runtime-resolved size.
type ViewMixChildD struct {
	Y []byte `ssz-size:"4" dynssz-size:"VIEWMIX_D_SIZE"`
	Z uint64
}

type ViewMixChildD_View struct {
	Y []byte `ssz-size:"4" dynssz-size:"VIEWMIX_D_SIZE"`
	Z uint64
}

type ViewMixHolder_View struct {
	A ViewMixChildA_View
	B ViewMixChildB_View
	C ViewMixChildC_View
	E ViewMixChildD_View
	N []byte `ssz-max:"8"`
	L []byte `ssz-max:"8"`
	U dynssz.CompatibleUnion[struct {
		V1 uint64
		V2 ViewMixChildA_View
	}]
	D []byte `ssz-max:"8"`
}

var GenCovBranches_Payload = GenCovBranches{
	RootsVec:  [][32]byte{{1}, {2}},
	RootsList: [][32]byte{{3}, {4}},
	HugeLimit: []uint64{7, 8},
	SpecStr:   "abc",
	BitsArr:   [4]byte{0xaa, 0xbb, 0xcc, 0x2d},
	Bits2:     []byte{0xff, 0xee, 0xdd, 0x2c},
	HintA:     []byte{1, 2, 3},
	HintB:     []byte{4, 5, 6},
	Fast:      CustomType1(0x1122),
	WrapSpec: dynssz.TypeWrapper[struct {
		Data []byte `ssz-size:"32" dynssz-size:"TEST_SPEC"`
	}, []byte]{
		Data: []byte{1, 2, 3, 4, 5, 6, 7, 8},
	},
	UnionList: []dynssz.CompatibleUnion[struct {
		V1 uint64
		V2 []byte `ssz-max:"8"`
	}]{
		{Variant: 1, Data: uint64(5)},
		{Variant: 2, Data: []byte{1, 2}},
	},
	SpecVecList: [][2]genCovSpecInner{{
		{A: []byte{1, 2, 3, 4, 5, 6, 7, 8}, B: []byte{1}},
		{A: []byte{8, 7, 6, 5, 4, 3, 2, 1}},
	}},
	VecOfList: [][2][]uint8{{{1}, {2, 3}}},
	Dyn:       []byte{9},
}

var GenCovBranches_Specs = map[string]any{
	"TEST_SPEC": uint64(8),
	"SPEC_A":    uint64(32),
	"SPEC_B":    uint64(32),
}

var GenCovCustomHolder_Payload = GenCovCustomHolder{
	C: CustomType1(0x33445566),
	D: []byte{1, 2, 3},
}

var GenCovCustomHolder2_Payload = GenCovCustomHolder2{
	C:  streamOnlyCustom{A: 3},
	CB: bufOnlyCustom{A: 4},
	CS: CustomType1(9),
	D:  []byte{7},
}

var GenCovWideOffsets_Payload = GenCovWideOffsets{
	F000: []byte{1},
	F128: []byte{2, 3},
	F256: []byte{4},
}

var ViewMixHolder_Payload = ViewMixHolder{
	A: ViewMixChildA{X: []byte{1}, Y: 2},
	B: ViewMixChildB{X: []byte{3}, Z: 4},
	C: ViewMixChildC{Y: 5, Z: 6},
	E: ViewMixChildD{Y: []byte{1, 2, 3, 4}, Z: 12},
	N: namedCovBytes{7},
	L: aliasCovBytes{8},
	U: dynssz.CompatibleUnion[struct {
		V1 uint64
		V2 ViewMixChildA
	}]{Variant: 2, Data: ViewMixChildA{X: []byte{9}, Y: 10}},
	D: []byte{11},
}

// ViewMixHolder_Specs supplies the spec value ViewMixChildD.Y is sized from.
var ViewMixHolder_Specs = map[string]any{
	"VIEWMIX_D_SIZE": uint64(6),
}

// ViewMixHolder_SpecsPayload sizes ViewMixChildD.Y from ViewMixHolder_Specs
// instead of the static default.
var ViewMixHolder_SpecsPayload = ViewMixHolder{
	A: ViewMixChildA{X: []byte{1}, Y: 2},
	B: ViewMixChildB{X: []byte{3}, Z: 4},
	C: ViewMixChildC{Y: 5, Z: 6},
	E: ViewMixChildD{Y: []byte{1, 2, 3, 4, 5, 6}, Z: 12},
	N: namedCovBytes{7},
	L: aliasCovBytes{8},
	U: dynssz.CompatibleUnion[struct {
		V1 uint64
		V2 ViewMixChildA
	}]{Variant: 2, Data: ViewMixChildA{X: []byte{9}, Y: 10}},
	D: []byte{11},
}

// genCovPtrWrapInner is the wrapped shape of GenCovPtrWrapper: a pointer
// value inside a pointer wrapper field localizes twice in one size-walk
// scope, so the bound names must differ.
type genCovPtrWrapInner struct {
	Data *[]uint8 `ssz-max:"32"`
}

type GenCovPtrWrapper struct {
	W *dynssz.TypeWrapper[genCovPtrWrapInner, *[]uint8] `ssz-type:"wrapper"`
}

var genCovPtrWrapData = []uint8{1, 2, 3}

var GenCovPtrWrapper_Payload = GenCovPtrWrapper{
	W: &dynssz.TypeWrapper[genCovPtrWrapInner, *[]uint8]{
		Data: &genCovPtrWrapData,
	},
}

// mixedOpaqueDelegated is an external fully-delegated type whose structure the
// engines cannot traverse: it is usable only through its Dynamic* methods.
type mixedOpaqueDelegated struct {
	V    uint64
	Note any
}

var _ = sszutils.Annotate[mixedOpaqueDelegated](`ssz-static:"true"`)

func (n *mixedOpaqueDelegated) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return 8 }
func (n *mixedOpaqueDelegated) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint64(buf, n.V), nil
}
func (n *mixedOpaqueDelegated) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	n.V = binary.LittleEndian.Uint64(buf)
	return nil
}
func (n *mixedOpaqueDelegated) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint64(n.V)
	return nil
}

// MixedOpaqueHolder is generated in default mode next to a static type; its
// opaque child must still be delegated to, not traversed.
type MixedOpaqueHolder struct {
	N mixedOpaqueDelegated
	A uint64
}

// MixedStatic is generated without dynamic expressions in the same batch.
type MixedStatic struct {
	A uint64
	B []uint64 `ssz-max:"4"`
}

// MixedExt needs extended types; the neighbouring default-mode types must not
// inherit that.
type MixedExt struct {
	S int8
	L []uint64 `ssz-max:"4"`
}

var (
	MixedOpaqueHolder_Payload = MixedOpaqueHolder{N: mixedOpaqueDelegated{V: 0x1122}, A: 7}
	MixedStatic_Payload       = MixedStatic{A: 9, B: []uint64{1, 2, 3}}
	MixedExt_Payload          = MixedExt{S: -3, L: []uint64{4, 5}}
)

// mixedDynOnlyCustom is served by its dynssz methods alone.
type mixedDynOnlyCustom struct{ V uint32 }

func (c *mixedDynOnlyCustom) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return 4 }
func (c *mixedDynOnlyCustom) MarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) ([]byte, error) {
	return binary.LittleEndian.AppendUint32(buf, c.V), nil
}
func (c *mixedDynOnlyCustom) UnmarshalSSZDyn(_ sszutils.DynamicSpecs, buf []byte) error {
	c.V = binary.LittleEndian.Uint32(buf)
	return nil
}
func (c *mixedDynOnlyCustom) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, hh sszutils.HashWalker) error {
	hh.PutUint32(c.V)
	return nil
}

// MixedDynCustomHolder holds a custom type without any fastssz method.
type MixedDynCustomHolder struct {
	C mixedDynOnlyCustom `ssz-type:"custom" ssz-size:"4"`
	N uint64
}

var MixedDynCustomHolder_Payload = MixedDynCustomHolder{C: mixedDynOnlyCustom{V: 0x0a0b0c0d}, N: 3}

// mixedNegSizeCustom reports a negative size.
type mixedNegSizeCustom struct{}

func (n *mixedNegSizeCustom) SizeSSZDyn(_ sszutils.DynamicSpecs) int { return -1 }
func (n *mixedNegSizeCustom) MarshalSSZEncoder(_ sszutils.DynamicSpecs, _ sszutils.Encoder) error {
	return nil
}
func (n *mixedNegSizeCustom) UnmarshalSSZDecoder(_ sszutils.DynamicSpecs, _ sszutils.Decoder) error {
	return nil
}
func (n *mixedNegSizeCustom) HashTreeRootWithDyn(_ sszutils.DynamicSpecs, _ sszutils.HashWalker) error {
	return nil
}

// MixedNegSizeHolder places the negative-size custom type where the encoder
// takes its size for an offset.
type MixedNegSizeHolder struct {
	A uint64
	C mixedNegSizeCustom   `ssz-type:"custom"`
	L []mixedNegSizeCustom `ssz-max:"4" ssz-type:"?,custom"`
}

// BigVecFixed declares a vector past the 32-bit int range; the generated
// file must still build there and refuse the shape.
type BigVecFixed struct {
	V []byte `ssz-size:"3000000000"`
}

// DynVecElem is the variable-size element of DynVecDeclared.
type DynVecElem struct {
	B []byte `ssz-max:"64"`
}

// DynVecDeclared is a vector of variable-size elements whose declared length
// is a claim the decoders must not allocate for before the bytes arrive.
type DynVecDeclared struct {
	V []DynVecElem `ssz-size:"65536"`
}

// BigIntLimit carries a bigint limit past the 32-bit int range.
type BigIntLimit struct {
	B *big.Int `ssz-type:"bigint" ssz-max:"4294967296"`
}

// BigIntSpecLimit states its bigint limit through the spec, with the static
// value as the fallback the generator bakes when no spec resolves it.
type BigIntSpecLimit struct {
	B *big.Int `ssz-type:"bigint" ssz-max:"5" dynssz-max:"BIGINT_SPEC_MAX"`
}

// The probe fixtures carry different subsets of the fastssz-style methods, so a
// test can tell which method each engine reaches for. Every method encodes what
// walking the type would encode, so delegation is invisible in the output and
// only the counters below distinguish the paths.
var (
	ProbeMarshalSSZCalls   atomic.Int64
	ProbeMarshalSSZToCalls atomic.Int64
	ProbeSizeSSZCalls      atomic.Int64
	ProbeUnmarshalSSZCalls atomic.Int64
	ProbeHashTreeRootCalls atomic.Int64
)

// ResetProbeCounts clears the probe call counters.
func ResetProbeCounts() {
	ProbeMarshalSSZCalls.Store(0)
	ProbeMarshalSSZToCalls.Store(0)
	ProbeSizeSSZCalls.Store(0)
	ProbeUnmarshalSSZCalls.Store(0)
	ProbeHashTreeRootCalls.Store(0)
}

// ProbeMarshalOnly carries MarshalSSZ and nothing else, so marshalling reaches
// it only through the buffer-returning fallback.
type ProbeMarshalOnly struct {
	V uint64
}

func (t *ProbeMarshalOnly) MarshalSSZ() ([]byte, error) {
	ProbeMarshalSSZCalls.Add(1)
	return binary.LittleEndian.AppendUint64(nil, t.V), nil
}

// ProbeStaticSurface carries the three methods generated code calls, without
// MarshalSSZ.
type ProbeStaticSurface struct {
	V uint64
}

func (t *ProbeStaticSurface) MarshalSSZTo(dst []byte) ([]byte, error) {
	ProbeMarshalSSZToCalls.Add(1)
	return binary.LittleEndian.AppendUint64(dst, t.V), nil
}

func (t *ProbeStaticSurface) SizeSSZ() int {
	ProbeSizeSSZCalls.Add(1)
	return 8
}

func (t *ProbeStaticSurface) UnmarshalSSZ(buf []byte) error {
	ProbeUnmarshalSSZCalls.Add(1)
	if len(buf) != 8 {
		return sszutils.ErrUnexpectedEOF
	}
	t.V = binary.LittleEndian.Uint64(buf)
	return nil
}

// ProbeNoSizer marshals and unmarshals through its own methods and leaves
// sizing to the walk.
type ProbeNoSizer struct {
	V uint64
}

func (t *ProbeNoSizer) MarshalSSZTo(dst []byte) ([]byte, error) {
	ProbeMarshalSSZToCalls.Add(1)
	return binary.LittleEndian.AppendUint64(dst, t.V), nil
}

func (t *ProbeNoSizer) UnmarshalSSZ(buf []byte) error {
	ProbeUnmarshalSSZCalls.Add(1)
	if len(buf) != 8 {
		return sszutils.ErrUnexpectedEOF
	}
	t.V = binary.LittleEndian.Uint64(buf)
	return nil
}

// ProbeFullFastssz carries the whole fastssz surface, as a fastssz-generated
// type does.
type ProbeFullFastssz struct {
	V uint64
}

func (t *ProbeFullFastssz) MarshalSSZ() ([]byte, error) {
	ProbeMarshalSSZCalls.Add(1)
	return binary.LittleEndian.AppendUint64(nil, t.V), nil
}

func (t *ProbeFullFastssz) MarshalSSZTo(dst []byte) ([]byte, error) {
	ProbeMarshalSSZToCalls.Add(1)
	return binary.LittleEndian.AppendUint64(dst, t.V), nil
}

func (t *ProbeFullFastssz) SizeSSZ() int {
	ProbeSizeSSZCalls.Add(1)
	return 8
}

func (t *ProbeFullFastssz) UnmarshalSSZ(buf []byte) error {
	ProbeUnmarshalSSZCalls.Add(1)
	if len(buf) != 8 {
		return sszutils.ErrUnexpectedEOF
	}
	t.V = binary.LittleEndian.Uint64(buf)
	return nil
}

func (t *ProbeFullFastssz) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	binary.LittleEndian.PutUint64(root[:8], t.V)
	return root, nil
}

// ProbePromotedInner provides the static surface to whatever embeds it.
type ProbePromotedInner struct {
	V uint64
}

func (t *ProbePromotedInner) MarshalSSZTo(dst []byte) ([]byte, error) {
	ProbeMarshalSSZToCalls.Add(1)
	return binary.LittleEndian.AppendUint64(dst, t.V), nil
}

func (t *ProbePromotedInner) SizeSSZ() int {
	ProbeSizeSSZCalls.Add(1)
	return 8
}

func (t *ProbePromotedInner) UnmarshalSSZ(buf []byte) error {
	ProbeUnmarshalSSZCalls.Add(1)
	if len(buf) != 8 {
		return sszutils.ErrUnexpectedEOF
	}
	t.V = binary.LittleEndian.Uint64(buf)
	return nil
}

// ProbePromoted reaches the inner type's methods by promotion, so they answer
// for the embedded value and not for this one.
type ProbePromoted struct {
	ProbePromotedInner
	W uint64
}

// ProbeDynamicSizer is variable-size, so its width is known only by asking it.
type ProbeDynamicSizer struct {
	V []byte `ssz-max:"32"`
}

func (t *ProbeDynamicSizer) MarshalSSZTo(dst []byte) ([]byte, error) {
	ProbeMarshalSSZToCalls.Add(1)
	dst = binary.LittleEndian.AppendUint32(dst, 4)
	return append(dst, t.V...), nil
}

func (t *ProbeDynamicSizer) SizeSSZ() int {
	ProbeSizeSSZCalls.Add(1)
	return 4 + len(t.V)
}

func (t *ProbeDynamicSizer) UnmarshalSSZ(buf []byte) error {
	ProbeUnmarshalSSZCalls.Add(1)
	if len(buf) < 4 {
		return sszutils.ErrUnexpectedEOF
	}
	t.V = append([]byte(nil), buf[4:]...)
	return nil
}

// ErrProbeMarshal is what ProbeMarshalFails reports.
var ErrProbeMarshal = errors.New("probe marshal failed")

// ProbeMarshalFails fails in the only marshalling method it has, so the error
// travels back through the buffer-returning fallback.
type ProbeMarshalFails struct {
	V uint64
}

func (t *ProbeMarshalFails) MarshalSSZ() ([]byte, error) {
	ProbeMarshalSSZCalls.Add(1)
	return nil, ErrProbeMarshal
}

// ProbeFailHolder reaches the failing probe through generated code.
type ProbeFailHolder struct {
	A ProbeMarshalFails
}

// ProbeFailWalkHolder reaches it through the reflection walk.
type ProbeFailWalkHolder struct {
	A ProbeMarshalFails
}

// ProbePromotedValueInner gives whatever embeds it a MarshalSSZ and nothing
// else, the shape that reaches the promotion rule through a single method.
type ProbePromotedValueInner struct {
	V uint64
}

func (t *ProbePromotedValueInner) MarshalSSZ() ([]byte, error) {
	ProbeMarshalSSZCalls.Add(1)
	return binary.LittleEndian.AppendUint64(nil, t.V), nil
}

// ProbePromotedValue reaches MarshalSSZ by promotion, so it must be walked:
// the promoted method answers for the embedded value and would drop W.
type ProbePromotedValue struct {
	ProbePromotedValueInner
	W uint64
}

// ProbeMixedPromotionInner contributes a promoted sizer.
type ProbeMixedPromotionInner struct {
	V uint64
}

func (t *ProbeMixedPromotionInner) SizeSSZ() int {
	ProbeSizeSSZCalls.Add(1)
	return 8
}

// ProbeMixedPromotion declares one static method itself and reaches another by
// promotion. Mixing them would measure the embedded value and marshal this one,
// so neither may be used.
type ProbeMixedPromotion struct {
	ProbeMixedPromotionInner
	W uint64
}

func (t *ProbeMixedPromotion) MarshalSSZTo(dst []byte) ([]byte, error) {
	ProbeMarshalSSZToCalls.Add(1)
	dst = binary.LittleEndian.AppendUint64(dst, t.V)
	return binary.LittleEndian.AppendUint64(dst, t.W), nil
}

// ProbePromotionHolder carries both promotion shapes as fields.
type ProbePromotionHolder struct {
	A ProbePromotedValue
	B ProbeMixedPromotion
}

// ProbeWalkHolder holds the same shapes as ProbeHolder and stays out of the
// generation set, so it has no methods of its own for either engine to reach:
// it is always walked, and each probe is met as a field.
type ProbeWalkHolder struct {
	A ProbeMarshalOnly
	B ProbeStaticSurface
	C ProbeNoSizer
	D ProbeFullFastssz
	E ProbePromoted
	F []byte `ssz-max:"32"`
	G ProbeDynamicSizer
}

// ProbeHolder places each probe shape where an engine has to choose a path. The
// trailing list makes the container variable-size, so sizing walks its fields
// instead of reading one static width.
type ProbeHolder struct {
	A ProbeMarshalOnly
	B ProbeStaticSurface
	C ProbeNoSizer
	D ProbeFullFastssz
	E ProbePromoted
	F []byte `ssz-max:"32"`
	G ProbeDynamicSizer
}

// GiBElem declares a width a 32-bit int holds comfortably, so no per-width
// guard refuses it; only the product with a list length passes the domain.
type GiBElem struct {
	X []byte `ssz-size:"1073741824"`
}

// GiBList holds enough of them that the product wraps a 32-bit int while
// staying inside a 64-bit one, which is where the two targets disagree.
type GiBList struct {
	L []GiBElem `ssz-max:"8"`
}

// SpecLimitChild carries a limit a preset may resolve away from its static
// tag. It is generated with -legacy, so it also exposes the static method set
// a parent could reach it through.
type SpecLimitChild struct {
	Items []uint64 `ssz-max:"4" dynssz-max:"SPEC_LIMIT_MAX"`
}

// SpecLimitParent nests SpecLimitChild as a field and as a list element.
type SpecLimitParent struct {
	X uint32
	C SpecLimitChild
	L []SpecLimitChild `ssz-max:"2"`
}

// TypeHintInner is a plain container generated in the same run as the holder
// below, which references it with an SSZ type the generated annotation does
// not declare.
type TypeHintInner struct {
	A uint64
	B uint32
}

// TypeHintOverride reaches TypeHintInner as a progressive container, so the
// field is described inline rather than through the type's own methods.
type TypeHintOverride struct {
	X TypeHintInner `ssz-type:"progressive-container"`
	Y uint64
}

var TypeHintOverride_Payload = TypeHintOverride{X: TypeHintInner{A: 1, B: 2}, Y: 3}

// SpecWidthInner is generated in the same run as its holder, which declares it
// custom; its width is a spec value with a static fallback.
type SpecWidthInner struct {
	X []byte `ssz-size:"8" dynssz-size:"SPEC_WIDTH"`
}

// SpecWidthHolder reaches SpecWidthInner as a custom field with and without a
// declared width, and as list and vector elements.
type SpecWidthHolder struct {
	F SpecWidthInner    `ssz-type:"custom"`
	G SpecWidthInner    `ssz-type:"custom" ssz-size:"8" dynssz-size:"SPEC_WIDTH"`
	L []SpecWidthInner  `ssz-max:"4" ssz-type:"?,custom"`
	V [2]SpecWidthInner `ssz-type:"?,custom"`
}

func specWidthHolderPayload(width int) SpecWidthHolder {
	fill := func(b byte) []byte {
		data := make([]byte, width)
		for i := range data {
			data[i] = b
		}
		return data
	}
	return SpecWidthHolder{
		F: SpecWidthInner{X: fill(1)},
		G: SpecWidthInner{X: fill(6)},
		L: []SpecWidthInner{{X: fill(2)}, {X: fill(3)}},
		V: [2]SpecWidthInner{{X: fill(4)}, {X: fill(5)}},
	}
}

// fsWidthCustom is static by annotation, declares no width, and carries the
// fastssz surface only: its width is read from SizeSSZ on a zero value.
type fsWidthCustom struct{ X uint8 }

var _ = sszutils.Annotate[fsWidthCustom](`ssz-type:"custom" ssz-static:"true"`)

func (*fsWidthCustom) SizeSSZ() int                  { return 3 }
func (v *fsWidthCustom) MarshalSSZ() ([]byte, error) { return v.MarshalSSZTo(nil) }
func (v *fsWidthCustom) MarshalSSZTo(b []byte) ([]byte, error) {
	return append(b, v.X, 0, 0), nil
}
func (v *fsWidthCustom) UnmarshalSSZ(b []byte) error {
	if len(b) != 3 {
		return sszutils.ErrUnexpectedEOF
	}
	v.X = b[0]
	return nil
}
func (v *fsWidthCustom) HashTreeRoot() ([32]byte, error) {
	var root [32]byte
	root[0] = v.X
	return root, nil
}

// FsWidthHolder reaches fsWidthCustom as a field and as list elements.
type FsWidthHolder struct {
	A uint64
	C fsWidthCustom
	L []fsWidthCustom `ssz-max:"4"`
}

var FsWidthHolder_Payload = FsWidthHolder{A: 7, C: fsWidthCustom{X: 1}, L: []fsWidthCustom{{X: 2}, {X: 3}}}

// zeroWidthCustom is static by annotation and reports a width of zero.
type zeroWidthCustom struct{}

var _ = sszutils.Annotate[zeroWidthCustom](`ssz-type:"custom" ssz-static:"true"`)

func (*zeroWidthCustom) SizeSSZ() int                          { return 0 }
func (*zeroWidthCustom) MarshalSSZ() ([]byte, error)           { return nil, nil }
func (*zeroWidthCustom) MarshalSSZTo(b []byte) ([]byte, error) { return b, nil }
func (*zeroWidthCustom) UnmarshalSSZ([]byte) error             { return nil }
func (*zeroWidthCustom) HashTreeRoot() ([32]byte, error)       { return [32]byte{}, nil }

// ZeroWidthList holds a list of zero-width elements: no length has a wire
// form of its own, so the type is refused wherever it is used.
type ZeroWidthList struct {
	L []zeroWidthCustom `ssz-max:"4"`
}

// ZeroWidthShell is a static container whose only field has a zero width.
type ZeroWidthShell struct{ Z zeroWidthCustom }

// ZeroWidthWrapperList, ZeroWidthShellList and ZeroWidthOptionalList reach a
// zero-width custom type through a wrapper element, a container element and
// an optional-list; each shape is refused wherever it is used.
type ZeroWidthWrapperList struct {
	W []dynssz.TypeWrapper[struct {
		Data zeroWidthCustom
	}, zeroWidthCustom] `ssz-max:"4" ssz-type:"?,wrapper"`
}

type ZeroWidthShellList struct {
	S []ZeroWidthShell `ssz-max:"4"`
}

type ZeroWidthOptionalList struct {
	O *zeroWidthCustom `ssz-type:"optional-list"`
}

// ZeroWidthOptional holds a zero-width custom type in a regular optional,
// whose presence byte keeps the encoding unambiguous.
type ZeroWidthOptional struct {
	A uint8
	O *zeroWidthCustom `ssz-type:"optional"`
}

var ZeroWidthOptional_Payload = ZeroWidthOptional{A: 1, O: &zeroWidthCustom{}}

// SpecViewIsolation_Base serves two views whose expressions differ: view A
// keeps a static fallback, view B is spec-only. A spec set lacking ONLY_B
// must leave view A working.
type SpecViewIsolation_Base struct {
	V []uint16 `ssz-size:"4"`
}

type SpecViewIsolation_ViewA struct {
	V []uint16 `ssz-size:"4" dynssz-size:"ONLY_A"`
}

type SpecViewIsolation_ViewB struct {
	V []uint16 `dynssz-size:"ONLY_B"`
}

// SpecViewShared_View is served by two data types: SpecViewShared_T1 holds a
// child the view's methods inline, SpecViewShared_T2 a generated child they
// delegate to, so the two builders of the view number its expressions in
// opposite order and must not share a cached set.
type SpecViewShared_ChildView struct {
	W []uint16 `ssz-size:"2" dynssz-size:"SHARED_W"`
}

type SpecViewShared_ChildPlain struct {
	W []uint16 `ssz-size:"2"`
}

type SpecViewShared_ChildGen struct {
	W []uint16 `ssz-size:"2"`
}

type SpecViewShared_View struct {
	Child *SpecViewShared_ChildView
	V     []uint16 `ssz-size:"4" dynssz-size:"SHARED_V"`
}

type SpecViewShared_T1 struct {
	Child *SpecViewShared_ChildPlain
	V     []uint16 `ssz-size:"4"`
}

type SpecViewShared_T2 struct {
	Child *SpecViewShared_ChildGen
	V     []uint16 `ssz-size:"4"`
}

// UnionSpecOnlyVariants holds variants whose width is fixed purely by a spec
// expression with no literal fallback: a uint16 vector, a bitvector and a byte
// vector. Each has a static size of 0 at generation time, and the generated
// decoders must still frame the variant at its resolved width.
type UnionSpecOnlyVariants struct {
	V  []uint16 `dynssz-size:"USO_LEN"`
	BV []byte   `ssz-type:"bitvector" dynssz-bitsize:"USO_BITS"`
	B  []byte   `dynssz-size:"USO_LEN"`
}

type UnionSpecOnlyCompat struct {
	U dynssz.CompatibleUnion[UnionSpecOnlyVariants]
}

type UnionSpecOnlyClassic struct {
	U dynssz.Union[UnionSpecOnlyVariants]
}

var UnionSpecOnly_Specs = map[string]any{
	"USO_LEN":  uint64(4),
	"USO_BITS": uint64(12),
}

// UnionSpecOnly_Values lists one value per variant with its serialized width
// under UnionSpecOnly_Specs.
var UnionSpecOnly_Values = []struct {
	Data any
	Size int
}{
	{Data: []uint16{1, 2, 3, 4}, Size: 8},
	{Data: []byte{0xff, 0x0f}, Size: 2},
	{Data: []byte{1, 2, 3, 4}, Size: 4},
}

// GenU128 is a uint128 held as two words with generated methods. As a list
// or vector element its root method must leave the packed 16 bytes, and as a
// field or standalone root a whole chunk.
type GenU128 [2]uint64

var _ = sszutils.Annotate[GenU128](`ssz-type:"uint128"`)

// GenU128Wrap is a generated wrapper around a word-form uint128.
type GenU128Wrap struct {
	Data [2]uint64 `ssz-type:"uint128"`
}

var _ = sszutils.Annotate[GenU128Wrap](`ssz-type:"wrapper"`)

type GenU128Holder struct {
	L []GenU128 `ssz-max:"8"`
	V [2]GenU128
	F GenU128
	W []GenU128Wrap `ssz-max:"8" ssz-type:"?,wrapper"`
}

// GenU128HolderRef is the same shape with inline element types and no
// generated methods.
type GenU128HolderRef struct {
	L [][2]uint64  `ssz-type:"?,uint128" ssz-max:"8"`
	V [2][2]uint64 `ssz-type:"?,uint128"`
	F [2]uint64    `ssz-type:"uint128"`
	W [][2]uint64  `ssz-type:"?,uint128" ssz-max:"8"`
}

var GenU128Holder_Payload = GenU128Holder{
	L: []GenU128{{1, 0}, {2, 0}, {3, 4}, {5, 6}, {7, 8}, {9, 10}},
	V: [2]GenU128{{3, 0}, {4, 0}},
	F: GenU128{11, 12},
	W: []GenU128Wrap{{Data: [2]uint64{13, 0}}, {Data: [2]uint64{14, 15}}, {Data: [2]uint64{16, 0}}, {Data: [2]uint64{17, 0}}, {Data: [2]uint64{18, 0}}, {Data: [2]uint64{19, 20}}},
}

var GenU128HolderRef_Payload = GenU128HolderRef{
	L: [][2]uint64{{1, 0}, {2, 0}, {3, 4}, {5, 6}, {7, 8}, {9, 10}},
	V: [2][2]uint64{{3, 0}, {4, 0}},
	F: [2]uint64{11, 12},
	W: [][2]uint64{{13, 0}, {14, 15}, {16, 0}, {17, 0}, {18, 0}, {19, 20}},
}

// ProbeHinted has a partial fastssz surface and no annotation; it resolves to
// a vector on its own, so a field hint naming a vector keeps its methods and
// one naming another SSZ type drops them.
type ProbeHinted [4]uint64

func (t *ProbeHinted) MarshalSSZ() ([]byte, error) {
	ProbeMarshalSSZCalls.Add(1)
	return sszutils.MarshalUint64Slice(nil, (*t)[:]), nil
}

func (t *ProbeHinted) UnmarshalSSZ(buf []byte) error {
	ProbeUnmarshalSSZCalls.Add(1)
	if len(buf) != 32 {
		return sszutils.ErrUnexpectedEOF
	}
	sszutils.UnmarshalUint64Slice((*t)[:], buf)
	return nil
}

func (t *ProbeHinted) HashTreeRoot() ([32]byte, error) {
	ProbeHashTreeRootCalls.Add(1)
	var root [32]byte
	sszutils.MarshalUint64Slice(root[:0], (*t)[:])
	return root, nil
}

// ProbeHintedGrid nests two vectors; a hint on its element dimension decides
// like one on the type itself.
type ProbeHintedGrid [2][4]uint64

func (t *ProbeHintedGrid) MarshalSSZ() ([]byte, error) {
	ProbeMarshalSSZCalls.Add(1)
	buf := make([]byte, 0, 64)
	for i := range t {
		buf = sszutils.MarshalUint64Slice(buf, t[i][:])
	}
	return buf, nil
}

func (t *ProbeHintedGrid) UnmarshalSSZ(buf []byte) error {
	ProbeUnmarshalSSZCalls.Add(1)
	if len(buf) != 64 {
		return sszutils.ErrUnexpectedEOF
	}
	for i := range t {
		sszutils.UnmarshalUint64Slice(t[i][:], buf[i*32:])
	}
	return nil
}

func (t *ProbeHintedGrid) HashTreeRoot() ([32]byte, error) {
	ProbeHashTreeRootCalls.Add(1)
	return dynssz.NewDynSsz(nil, dynssz.WithNoFastSsz(), dynssz.WithNoDelegation()).HashTreeRoot(t)
}

// ProbeHintedElem declares its shape through an annotation; ProbeHintedOuter
// carries the methods, so a hint on the element dimension is compared with
// the annotation.
type ProbeHintedElem []uint64

var _ = sszutils.Annotate[ProbeHintedElem](`ssz-size:"4"`)

type ProbeHintedOuter [2]ProbeHintedElem

func (t *ProbeHintedOuter) MarshalSSZ() ([]byte, error) {
	ProbeMarshalSSZCalls.Add(1)
	buf := make([]byte, 0, 64)
	for i := range t {
		buf = sszutils.MarshalUint64Slice(buf, t[i])
	}
	return buf, nil
}

func (t *ProbeHintedOuter) UnmarshalSSZ(buf []byte) error {
	ProbeUnmarshalSSZCalls.Add(1)
	if len(buf) != 64 {
		return sszutils.ErrUnexpectedEOF
	}
	for i := range t {
		t[i] = make(ProbeHintedElem, 4)
		sszutils.UnmarshalUint64Slice(t[i], buf[i*32:])
	}
	return nil
}

func (t *ProbeHintedOuter) HashTreeRoot() ([32]byte, error) {
	ProbeHashTreeRootCalls.Add(1)
	return dynssz.NewDynSsz(nil, dynssz.WithNoFastSsz(), dynssz.WithNoDelegation()).HashTreeRoot(t)
}

// ProbeHintedOuterAnn declares its element dimension as a list, which takes
// the place of ProbeHintedElem's own vector declaration below it.
type ProbeHintedOuterAnn [2]ProbeHintedElem

var _ = sszutils.Annotate[ProbeHintedOuterAnn](`ssz-type:"vector,list" ssz-max:"?,4"`)

func (t *ProbeHintedOuterAnn) MarshalSSZ() ([]byte, error) {
	ProbeMarshalSSZCalls.Add(1)
	return dynssz.NewDynSsz(nil, dynssz.WithNoFastSsz(), dynssz.WithNoDelegation()).MarshalSSZ(t)
}

func (t *ProbeHintedOuterAnn) UnmarshalSSZ(buf []byte) error {
	ProbeUnmarshalSSZCalls.Add(1)
	return dynssz.NewDynSsz(nil, dynssz.WithNoFastSsz(), dynssz.WithNoDelegation()).UnmarshalSSZ(t, buf)
}

func (t *ProbeHintedOuterAnn) HashTreeRoot() ([32]byte, error) {
	ProbeHashTreeRootCalls.Add(1)
	return dynssz.NewDynSsz(nil, dynssz.WithNoFastSsz(), dynssz.WithNoDelegation()).HashTreeRoot(t)
}

// ProbeHintedLimited declares its limit through its annotation, which a
// field's tag carries along with its own type hint.
type ProbeHintedLimited []ProbeHinted

var _ = sszutils.Annotate[ProbeHintedLimited](`ssz-max:"4"`)

func (t *ProbeHintedLimited) MarshalSSZ() ([]byte, error) {
	ProbeMarshalSSZCalls.Add(1)
	return dynssz.NewDynSsz(nil, dynssz.WithNoFastSsz(), dynssz.WithNoDelegation()).MarshalSSZ(t)
}

func (t *ProbeHintedLimited) UnmarshalSSZ(buf []byte) error {
	ProbeUnmarshalSSZCalls.Add(1)
	return dynssz.NewDynSsz(nil, dynssz.WithNoFastSsz(), dynssz.WithNoDelegation()).UnmarshalSSZ(t, buf)
}

func (t *ProbeHintedLimited) HashTreeRoot() ([32]byte, error) {
	ProbeHashTreeRootCalls.Add(1)
	return dynssz.NewDynSsz(nil, dynssz.WithNoFastSsz(), dynssz.WithNoDelegation()).HashTreeRoot(t)
}

// ProbeHintedHolder is generated; ProbeHintedWalked is walked by reflection.
type ProbeHintedHolder struct {
	Plain     ProbeHinted
	Same      ProbeHinted         `ssz-type:"vector"`
	Other     ProbeHinted         `ssz-type:"uint256"`
	GridSame  ProbeHintedGrid     `ssz-type:"vector,vector"`
	GridElem  ProbeHintedGrid     `ssz-type:"vector,uint256"`
	GridOpen  ProbeHintedGrid     `ssz-type:"?,uint256"`
	OuterSame ProbeHintedOuter    `ssz-type:"vector,vector"`
	OuterOpen ProbeHintedOuter    `ssz-type:"vector,?"`
	AnnList   ProbeHintedOuterAnn `ssz-type:"vector,list"`
	LimSame   ProbeHintedLimited  `ssz-type:"list"`
	LimOther  ProbeHintedLimited  `ssz-type:"list,uint256"`
}

type ProbeHintedWalked struct {
	Plain     ProbeHinted
	Same      ProbeHinted         `ssz-type:"vector"`
	Other     ProbeHinted         `ssz-type:"uint256"`
	GridSame  ProbeHintedGrid     `ssz-type:"vector,vector"`
	GridElem  ProbeHintedGrid     `ssz-type:"vector,uint256"`
	GridOpen  ProbeHintedGrid     `ssz-type:"?,uint256"`
	OuterSame ProbeHintedOuter    `ssz-type:"vector,vector"`
	OuterOpen ProbeHintedOuter    `ssz-type:"vector,?"`
	AnnList   ProbeHintedOuterAnn `ssz-type:"vector,list"`
	LimSame   ProbeHintedLimited  `ssz-type:"list"`
	LimOther  ProbeHintedLimited  `ssz-type:"list,uint256"`
}

// ProbeHintedOverride re-declares the annotated element as a list; it is only
// described, never hashed.
type ProbeHintedOverride struct {
	OuterList ProbeHintedOuter `ssz-type:"vector,list"`
}
